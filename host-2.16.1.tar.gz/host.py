#!/usr/bin/env python3
"""VerCode Bot Manager 2.13"""

import webview
import subprocess
import threading
import json
import os
import sys
import shutil
import time
import re
import tarfile
import ast
import tempfile
import base64
import urllib.request
import urllib.error
import hashlib
import zipfile
import uuid
from collections import deque
from datetime import datetime

sys.setrecursionlimit(10000)

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

APP_VERSION = "2.16.0"
UPDATE_MANIFEST_URL = "https://vern0xx.github.io/vercode-bot-manager/manifest.json"
PAGES_BASE = "https://vern0xx.github.io/vercode-bot-manager/"
CATALOG_URL = PAGES_BASE + "bots/catalog.json"
PACK_META = ".vercode_pack.json"
PRESERVE_NAMES = {".env", "data", "logs", "config.json", PACK_META}
PRESERVE_EXT = (".db", ".sqlite", ".sqlite3", ".log")
MAX_PACK_BYTES = 60 * 1024 * 1024
UPDATE_MANIFEST_BETA_URL = "https://vern0xx.github.io/vercode-bot-manager/manifest-beta.json"
DISCORD_INVITE = "https://discord.gg/vern0xx"
FEEDBACK_INTERVAL_HOURS = 72
WINDOW_TITLE = "VerCode Bot Manager"

def app_icon():
    for cand in (
        resource_path(os.path.join("web", "static", "logo.png")),
        os.path.join(APP_DIR, "web", "static", "logo.png"),
        resource_path("logo.png"),
    ):
        if os.path.isfile(cand):
            return cand
    return None

CONFIG_VERSION = 3

def app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def resource_path(rel):
    if getattr(sys, "frozen", False):
        return os.path.join(sys._MEIPASS, rel)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), rel)

def data_dir():
    if os.name == "nt":
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        path = os.path.join(base, "VerCode Bot Manager")
    else:
        path = os.path.join(os.path.expanduser("~"), ".vercode-bot-manager")
    os.makedirs(path, exist_ok=True)
    return path

APP_DIR = app_dir()
DATA_DIR = data_dir()
BOTS_DIR = os.path.join(DATA_DIR, "bots")
CONFIG = os.path.join(DATA_DIR, "config.json")
CONFIG_BACKUP = os.path.join(DATA_DIR, "config.backup.json")
LOG_DIR = os.path.join(DATA_DIR, "logs")
AVATARS_DIR = os.path.join(DATA_DIR, "avatars")

os.makedirs(BOTS_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(AVATARS_DIR, exist_ok=True)

# migracja ze starej lokalizacji (obok exe / skryptu)
def _migrate_legacy():
    try:
        for name in ("config.json", "config.backup.json"):
            old = os.path.join(APP_DIR, name)
            new = os.path.join(DATA_DIR, name)
            if os.path.isfile(old) and not os.path.isfile(new):
                import shutil
                shutil.copy2(old, new)
        old_bots = os.path.join(APP_DIR, "bots")
        if os.path.isdir(old_bots):
            for item in os.listdir(old_bots):
                src = os.path.join(old_bots, item)
                dst = os.path.join(BOTS_DIR, item)
                if not os.path.exists(dst):
                    import shutil
                    if os.path.isdir(src):
                        shutil.copytree(src, dst)
                    else:
                        shutil.copy2(src, dst)
    except Exception:
        pass
_migrate_legacy()

BOT_REGISTRY = {}
REGISTRY_LOCK = threading.RLock()

DEFAULT_SETTINGS = {
    "theme": "dark",
    "webhook_url": "",
    "webhook_events": {
        "start": True,
        "stop": True,
        "crash": True,
        "error": False,
        "create": False,
    },
    "auto_start_on_launch": False,
    "poll_interval_ms": 450,
    "log_max_lines": 15000,
    "show_system_stats": True,
    "confirm_delete": True,
    "sound_on_crash": False,
    "compact_sidebar": False,
    "default_priority": "normal",
    "default_auto_restart": False,
    "update_channel": "stable",
    "auto_update": True,
    "auto_update_bots": False,
    "skipped_version": "",
    "client_id": "",
    "last_update_check": 0,
    "first_run_done": False,
    "last_feedback_at": 0,
    "feedback_dismissed": 0,
}

TEMPLATES = {
    "basic": '''import discord
import os
from dotenv import load_dotenv
load_dotenv()
intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f"Zalogowano jako {client.user} (ID: {client.user.id})")

@client.event
async def on_message(message):
    if message.author.bot:
        return
    if message.content == "!ping":
        await message.channel.send("pong")

client.run(os.getenv("DISCORD_TOKEN"))
''',
    "slash": '''import discord
import os
from discord import app_commands
from dotenv import load_dotenv
load_dotenv()
intents = discord.Intents.default()
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)

@tree.command(name="ping", description="Sprawdź opóźnienie")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message(f"Pong! {round(client.latency * 1000)}ms")

@client.event
async def on_ready():
    await tree.sync()
    print(f"Zalogowano jako {client.user}")

client.run(os.getenv("DISCORD_TOKEN"))
''',
    "mod": '''import discord
import os
from discord.ext import commands
from dotenv import load_dotenv
load_dotenv()
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"Zalogowano jako {bot.user}")

@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason="Brak powodu"):
    await member.kick(reason=reason)
    await ctx.send(f"Wyrzucono {member.mention}")

@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason="Brak powodu"):
    await member.ban(reason=reason)
    await ctx.send(f"Zbanowano {member.mention}")

bot.run(os.getenv("DISCORD_TOKEN"))
''',
    "empty": '''import discord
import os
from dotenv import load_dotenv
load_dotenv()
intents = discord.Intents.default()
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f"Zalogowano jako {client.user}")

client.run(os.getenv("DISCORD_TOKEN"))
''',
    "sentron": '''"""Sentron – gotowy szkielet (użyj cogs/ z bots/sentron)"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import discord
from discord.ext import commands
from dotenv import load_dotenv
from datetime import datetime, timezone
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True
intents.moderation = True

class Bot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents, help_command=None,
            activity=discord.Activity(type=discord.ActivityType.watching, name="your servers ✨"))
        self.start_time = datetime.now(timezone.utc)
        self.raid_tracker = {}
        self.raid_settings = {}

    async def setup_hook(self):
        for cog in ["moderation", "antiraid", "utility", "admin", "components", "welcome", "verification", "tickets"]:
            try:
                await self.load_extension(f"cogs.{cog}")
                print(f"[OK] Loaded: {cog}")
            except Exception as e:
                print(f"[ERR] {cog}: {e}")
        try:
            synced = await self.tree.sync()
            print(f"Synced {len(synced)} commands")
        except Exception as e:
            print(f"Sync error: {e}")

    async def on_ready(self):
        print("Logged in as %s (ID: %s)" % (self.user, self.user.id))
        print("Guilds: %d" % len(self.guilds))

bot = Bot()

@bot.tree.command(name="ping", description="Check latency")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message(f"🏓 Pong! **{round(bot.latency * 1000)}ms**")

if __name__ == "__main__":
    if not TOKEN:
        print("DISCORD_TOKEN not set")
        raise SystemExit(1)
    bot.run(TOKEN)
''',
}

PRIORITIES = ["idle", "below", "normal", "above", "high"]
LEVEL_RE = re.compile(r"\b(ERROR|WARN|WARNING|FATAL|CRITICAL|DEBUG|TRACE|INFO)\b", re.IGNORECASE)


def detect_level(line):
    s = line or ""
    low = s.lower()
    if s.startswith(">>>") or s.startswith("[stdin]"):
        return "cmd"
    if "[HOST]" in s or s.startswith("[HOST]"):
        if "zatrzym" in low or "stop" in low or "zako" in low:
            return "host"
        if "uruchom" in low or "start" in low or "PID=" in s:
            return "success"
        return "host"
    if "[WATCHDOG]" in s:
        return "warn"
    if "traceback" in low or "exception" in low:
        return "error"
    m = LEVEL_RE.search(s)
    if m:
        lvl = m.group(1).upper()
        if lvl in ("ERROR", "FATAL", "CRITICAL"):
            return "error"
        if lvl in ("WARN", "WARNING"):
            return "warn"
        if lvl == "DEBUG":
            return "debug"
        if lvl == "TRACE":
            return "trace"
        if lvl == "INFO":
            return "info"
    if "error" in low or "failed" in low or "fatal" in low:
        return "error"
    if "warn" in low:
        return "warn"
    if "success" in low or "ready" in low or "zalogowano" in low or "logged in" in low or "synced" in low:
        return "success"
    return "info"


def safe_name(name):
    return bool(name and re.fullmatch(r"[\w\-]+", name) and len(name) <= 64)


def safe_extract(path, dest):
    """Rozpakowuje .zip/.tar(.gz) bez path-traversal i linków."""
    os.makedirs(dest, exist_ok=True)
    base = os.path.realpath(dest)

    def check(name):
        t = os.path.realpath(os.path.join(dest, name))
        if t != base and not t.startswith(base + os.sep):
            raise ValueError("Niebezpieczna ścieżka w paczce: " + name)

    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            total = 0
            for i in z.infolist():
                check(i.filename)
                total += i.file_size
                if total > 400 * 1024 * 1024:
                    raise ValueError("Paczka po rozpakowaniu jest za duża")
            z.extractall(dest)
    else:
        with tarfile.open(path, "r:*") as tar:
            for m in tar.getmembers():
                if m.issym() or m.islnk() or m.isdev():
                    raise ValueError("Linki/urządzenia w paczce niedozwolone: " + m.name)
                check(m.name)
            tar.extractall(dest)


def ts():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def apply_dwm():
    if os.name != "nt":
        return
    try:
        import ctypes
        user32 = ctypes.windll.user32
        dwmapi = ctypes.windll.dwmapi
        hwnd = user32.FindWindowW(None, WINDOW_TITLE)
        if not hwnd:
            return
        val = ctypes.c_int(2)
        dwmapi.DwmSetWindowAttribute(hwnd, 33, ctypes.byref(val), ctypes.sizeof(val))
        dark = ctypes.c_int(1)
        dwmapi.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(dark), ctypes.sizeof(dark))
    except Exception:
        pass


def schedule_dwm():
    for delay in (0.1, 0.4, 1.0):
        threading.Timer(delay, apply_dwm).start()


def _webhook_post(url, payload):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json", "User-Agent": "VerCode/" + APP_VERSION},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        return getattr(resp, "status", 204)


def send_webhook(url, content=None, embeds=None, v2_title=None, v2_body=None, accent=None):
    if not url or not url.startswith("http"):
        return
    title = (v2_title or "").strip()
    body = (v2_body or "").strip()
    if not title and embeds:
        title = str(embeds[0].get("title") or "VerCode")
        body = str(embeds[0].get("description") or "")
        fields = embeds[0].get("fields") or []
        if fields:
            extra = "\n".join("**%s:** %s" % (f.get("name", ""), f.get("value", "")) for f in fields)
            body = (body + "\n\n" + extra) if body else extra
        if accent is None:
            accent = embeds[0].get("color")
    if content and not body:
        body = content
    accent = int(accent or 0x38BDF8)
    try:
        text = (("## " + title + "\n") if title else "") + (body or "")
        text = text[:3800]
        v2 = {
            "username": "VerCode Bot Manager",
            "flags": 32768,
            "components": [{
                "type": 17,
                "accent_color": accent,
                "components": [
                    {"type": 10, "content": text},
                    {"type": 14, "divider": True, "spacing": 1},
                    {"type": 10, "content": "-# VerCode Bot Manager · v%s" % APP_VERSION},
                ],
            }],
        }
        _webhook_post(url, v2)
        return
    except Exception:
        pass
    try:
        payload = {"username": "VerCode Bot Manager"}
        if content:
            payload["content"] = content[:1900]
        if embeds:
            payload["embeds"] = embeds
        elif title or body:
            payload["embeds"] = [{
                "title": title or "VerCode",
                "description": (body or "")[:1800],
                "color": accent,
            }]
        _webhook_post(url, payload)
    except Exception:
        pass


def fetch_discord_avatar(token):
    if not token or len(token) < 20:
        return None
    try:
        req = urllib.request.Request(
            "https://discord.com/api/v10/users/@me",
            headers={"Authorization": f"Bot {token}", "User-Agent": "VerCode/" + APP_VERSION},
        )
        with urllib.request.urlopen(req, timeout=6) as resp:
            data = json.loads(resp.read().decode())
            uid = data.get("id")
            av = data.get("avatar")
            name = data.get("username") or data.get("global_name")
            if uid and av:
                url = f"https://cdn.discordapp.com/avatars/{uid}/{av}.png?size=128"
                return {"url": url, "username": name, "id": uid}
            if uid:
                disc = int(uid) % 5
                url = f"https://cdn.discordapp.com/embed/avatars/{disc}.png"
                return {"url": url, "username": name, "id": uid}
    except Exception:
        pass
    return None


def download_avatar(url, bot_name):
    try:
        path = os.path.join(AVATARS_DIR, f"{bot_name}.png")
        req = urllib.request.Request(url, headers={"User-Agent": "VerCode/" + APP_VERSION})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = resp.read()
        with open(path, "wb") as f:
            f.write(data)
        return path
    except Exception:
        return None


class BotProcess:
    def __init__(self, name, entry, priority="normal", tags=None, avatar=None, note="", webhook_url=""):
        self.name = name
        self.entry = entry
        self.priority = priority if priority in PRIORITIES else "normal"
        self.tags = list(tags or [])
        self.avatar = avatar
        self.note = note or ""
        self.webhook_url = webhook_url or ""
        self.proc = None
        self.logs = deque(maxlen=15000)
        self._seq = 0
        self.lock = threading.Lock()
        self.auto_restart = False
        self.auto_start = False
        self._stop = False
        self.started_at = None
        self.total_restarts = 0
        self.last_exit_code = None
        self._log_file = None
        self.discord_username = None
        self.discord_id = None

    def _open_log_file(self):
        try:
            path = os.path.join(LOG_DIR, f"{self.name}.log")
            self._log_file = open(path, "a", encoding="utf-8", buffering=1)
        except Exception:
            self._log_file = None

    def log(self, line, level=None):
        if level is None:
            level = detect_level(line)
        with self.lock:
            self._seq += 1
            self.logs.append((self._seq, line, level))
            if self._log_file:
                try:
                    self._log_file.write(f"[{ts()}] [{level.upper()}] {line}\n")
                except Exception:
                    pass

    def get_since(self, since, level_filter=None):
        with self.lock:
            result = []
            for s, l, lv in self.logs:
                if s <= since:
                    continue
                if level_filter and level_filter not in ("all", "", None) and lv != level_filter:
                    continue
                result.append([s, l, lv])
            return result, self._seq

    def search(self, query, since=0):
        with self.lock:
            result = []
            q = (query or "").lower()
            for s, l, lv in self.logs:
                if s <= since:
                    continue
                if q in l.lower():
                    result.append([s, l, lv])
            return result, self._seq

    def clear(self):
        with self.lock:
            self.logs.clear()
            self._seq = 0

    def get_level_counts(self):
        with self.lock:
            counts = {"info": 0, "warn": 0, "error": 0, "debug": 0, "trace": 0}
            for _, _, lv in self.logs:
                counts[lv] = counts.get(lv, 0) + 1
            return counts

    def start(self, notify_fn=None):
        if self.is_running():
            return
        self._stop = False
        self._open_log_file()
        cmd = [sys.executable, "-u", self.entry]
        creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        env = os.environ.copy()
        env["PYTHONUTF8"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        bot_dir = os.path.dirname(self.entry)
        env["PYTHONPATH"] = bot_dir + os.pathsep + env.get("PYTHONPATH", "")
        try:
            self.proc = subprocess.Popen(
                cmd,
                cwd=bot_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.PIPE,
                text=True,
                bufsize=1,
                encoding="utf-8",
                errors="replace",
                creationflags=creationflags,
                env=env,
            )
            self.started_at = time.time()
            self.log(f"[HOST] uruchomiono PID={self.proc.pid} ({ts()})")
            self._apply_priority()
            if notify_fn:
                notify_fn(self, "start")
        except Exception as e:
            self.log(f"[ERROR] Nie można uruchomić: {e}", "error")
            if notify_fn:
                notify_fn(self, "error", str(e))
            return
        threading.Thread(target=self._reader, args=(notify_fn,), daemon=True, name=f"reader-{self.name}").start()

    def _apply_priority(self):
        if not HAS_PSUTIL or not self.proc:
            return
        try:
            p = psutil.Process(self.proc.pid)
            prio_map = {
                "idle": psutil.IDLE_PRIORITY_CLASS,
                "below": psutil.BELOW_NORMAL_PRIORITY_CLASS,
                "normal": psutil.NORMAL_PRIORITY_CLASS,
                "above": psutil.ABOVE_NORMAL_PRIORITY_CLASS,
                "high": psutil.HIGH_PRIORITY_CLASS,
            }
            if self.priority in prio_map:
                p.nice(prio_map[self.priority])
        except Exception:
            pass

    def _reader(self, notify_fn=None):
        try:
            for line in self.proc.stdout:
                self.log(line.rstrip())
        except Exception:
            pass
        try:
            self.proc.wait()
        except Exception:
            pass
        code = self.proc.returncode if self.proc else None
        self.last_exit_code = code
        crashed = code is not None and code != 0
        if self.auto_restart and not self._stop:
            self.total_restarts += 1
            delay = min(2 * self.total_restarts, 20)
            self.log(f"[WATCHDOG] restart #{self.total_restarts} za {delay}s", "warn")
            if notify_fn and crashed:
                notify_fn(self, "crash", f"kod={code}, restart za {delay}s")
            time.sleep(delay)
            if not self._stop:
                self.start(notify_fn)
        else:
            lvl = "error" if crashed else "info"
            self.log(f"[HOST] zakończony kod={code}", lvl)
            if notify_fn:
                if crashed:
                    notify_fn(self, "crash", f"kod wyjścia: {code}")
                else:
                    notify_fn(self, "stop")
        self.started_at = None
        if self._log_file:
            try:
                self._log_file.close()
            except Exception:
                pass
            self._log_file = None

    def send_input(self, text):
        if self.proc and self.proc.poll() is None and self.proc.stdin:
            try:
                self.proc.stdin.write(text + "\n")
                self.proc.stdin.flush()
                self.log(f">>> {text}")
                return True
            except Exception:
                return False
        return False

    def _kill_tree(self):
        if not self.proc or self.proc.poll() is not None:
            return
        if os.name == "nt":
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(self.proc.pid), "/T", "/F"],
                    capture_output=True, timeout=5,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                )
                return
            except Exception:
                pass
        try:
            self.proc.terminate()
        except Exception:
            pass

    def stop(self):
        self._stop = True
        if self.proc and self.proc.poll() is None:
            self._kill_tree()
            try:
                self.proc.wait(timeout=6)
            except subprocess.TimeoutExpired:
                try:
                    self.proc.kill()
                except Exception:
                    pass
            self.log("[HOST] zatrzymano")

    def is_running(self):
        return self.proc is not None and self.proc.poll() is None

    def pid(self):
        return self.proc.pid if self.is_running() else None

    def uptime(self):
        if self.is_running() and self.started_at:
            return int(time.time() - self.started_at)
        return None

    def get_stats(self):
        if not HAS_PSUTIL:
            return {"cpu": None, "memory": None, "threads": None}
        if not self.is_running():
            return {"cpu": 0, "memory": 0, "threads": 0}
        try:
            p = psutil.Process(self.proc.pid)
            with p.oneshot():
                cpu = p.cpu_percent(interval=None)
                mem = p.memory_info().rss
                threads = p.num_threads()
            return {"cpu": round(cpu, 1), "memory": mem, "threads": threads}
        except Exception:
            return {"cpu": None, "memory": None, "threads": None}


class Api:
    def __init__(self):
        self._window = None
        self._drag_pos = None
        self._start_time = time.time()
        self._config = {}
        self._settings = dict(DEFAULT_SETTINGS)
        self._load_config()

    def set_window(self, w):
        self._window = w
        self._maximized = False

    def _notify(self, bot, event, detail=""):
        settings = self._settings
        events = settings.get("webhook_events", {})
        if not events.get(event, False):
            return
        url = bot.webhook_url or settings.get("webhook_url", "")
        if not url:
            return
        colors = {
            "start": 0x34D399,
            "stop": 0x64748B,
            "crash": 0xFB7185,
            "error": 0xF43F5E,
            "create": 0x38BDF8,
            "update": 0xA78BFA,
        }
        titles = {
            "start": f"▶  {bot.name}",
            "stop": f"■  {bot.name}",
            "crash": f"⚠  {bot.name}",
            "error": f"✗  {bot.name}",
            "create": f"+  {bot.name}",
            "update": f"⬆  {bot.name}",
        }
        sub = {
            "start": "Bot uruchomiony",
            "stop": "Bot zatrzymany",
            "crash": "Awaria procesu",
            "error": "Błąd",
            "create": "Utworzono bota",
            "update": "Aktualizacja",
        }
        embed = {
            "author": {"name": "VerCode Bot Manager"},
            "title": titles.get(event, event),
            "description": (sub.get(event, event) + (("\n" + detail) if detail else ""))[:1800],
            "color": colors.get(event, 0x38BDF8),
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
            "footer": {"text": f"v{APP_VERSION} · {bot.name}"},
        }
        if bot.avatar and str(bot.avatar).startswith("http"):
            embed["thumbnail"] = {"url": bot.avatar}
        fields = []
        if bot.pid():
            fields.append({"name": "PID", "value": f"`{bot.pid()}`", "inline": True})
        up = bot.uptime()
        if up is not None:
            fields.append({"name": "Uptime", "value": f"`{up}s`", "inline": True})
        if bot.discord_username:
            fields.append({"name": "Discord", "value": f"`@{bot.discord_username}`", "inline": True})
        fields.append({"name": "Event", "value": f"`{event}`", "inline": True})
        embed["fields"] = fields
        v2_body = (sub.get(event, event) + (("\n" + detail) if detail else ""))[:1500]
        if fields:
            v2_body += "\n\n" + "\n".join("**%s:** %s" % (f["name"], f["value"]) for f in fields)
        threading.Thread(
            target=send_webhook,
            kwargs={
                "url": url,
                "embeds": [embed],
                "v2_title": titles.get(event, event),
                "v2_body": v2_body,
                "accent": colors.get(event, 0x38BDF8),
            },
            daemon=True,
        ).start()

    def window_minimize(self):
        try:
            self._window.minimize()
        except Exception:
            pass

    def window_toggle_maximize(self):
        try:
            w = self._window
            if not w:
                return {"ok": False}
            maximized = bool(getattr(self, "_maximized", False))
            if maximized:
                try:
                    w.restore()
                except Exception:
                    try:
                        w.toggle_fullscreen()
                    except Exception:
                        pass
                self._maximized = False
            else:
                try:
                    w.maximize()
                except Exception:
                    try:
                        w.toggle_fullscreen()
                    except Exception:
                        pass
                self._maximized = True
            return {"ok": True, "maximized": bool(getattr(self, "_maximized", False))}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def window_close(self):
        self._save_window_state()
        try:
            self._window.destroy()
        except Exception:
            pass

    def window_drag_start(self):
        try:
            self._drag_pos = (int(self._window.x), int(self._window.y))
        except Exception:
            self._drag_pos = (0, 0)
        return {"ok": True}

    def window_drag_to(self, offset_x, offset_y):
        if not self._drag_pos:
            return {"ok": False}
        try:
            self._window.move(self._drag_pos[0] + int(offset_x), self._drag_pos[1] + int(offset_y))
            return {"ok": True}
        except Exception:
            return {"ok": False}

    def window_get_bounds(self):
        try:
            w = self._window
            return {
                "ok": True,
                "x": int(w.x),
                "y": int(w.y),
                "width": int(w.width),
                "height": int(w.height),
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def window_set_bounds(self, x, y, width, height):
        try:
            w = self._window
            width = max(720, int(width))
            height = max(520, int(height))
            x, y = int(x), int(y)
            try:
                w.move(x, y)
            except Exception:
                pass
            try:
                w.resize(width, height)
            except Exception:
                pass
            return {"ok": True, "x": x, "y": y, "width": width, "height": height}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def list_fs_roots(self):
        roots = []
        try:
            home = os.path.expanduser("~")
            roots.append({"name": "Home", "path": home})
            for label, part in (("Desktop", "Desktop"), ("Documents", "Documents"), ("Downloads", "Downloads")):
                p = os.path.join(home, part)
                if os.path.isdir(p):
                    roots.append({"name": label, "path": p})
            if os.name == "nt":
                import string
                for letter in string.ascii_uppercase:
                    p = letter + ":\\"
                    if os.path.isdir(p):
                        roots.append({"name": letter + ":", "path": p})
            else:
                roots.append({"name": "/", "path": "/"})
        except Exception:
            pass
        return {"ok": True, "roots": roots}

    def browse_dir(self, path=None):
        try:
            if not path:
                path = os.path.expanduser("~")
            path = os.path.abspath(path)
            if not os.path.isdir(path):
                return {"ok": False, "error": "To nie jest folder", "path": path}
            dirs, files = [], []
            try:
                names = os.listdir(path)
            except PermissionError:
                return {"ok": False, "error": "Brak dostępu", "path": path}
            for name in sorted(names, key=lambda s: s.lower()):
                if name.startswith("."):
                    continue
                full = os.path.join(path, name)
                try:
                    if os.path.isdir(full):
                        dirs.append({"name": name, "path": full, "type": "dir"})
                    elif os.path.isfile(full):
                        ext = os.path.splitext(name)[1].lower()
                        size = os.path.getsize(full)
                        files.append({"name": name, "path": full, "type": "file", "ext": ext, "size": size})
                except Exception:
                    continue
            parent = os.path.dirname(path.rstrip("\\/"))
            if os.name == "nt" and len(path) <= 3:
                parent = path
            return {
                "ok": True,
                "path": path,
                "parent": parent if parent != path else "",
                "dirs": dirs,
                "files": files,
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def get_window_state(self):
        return self._config.get("window", {})

    def set_window_state(self, state):
        try:
            self._config["window"] = {
                "x": int(state.get("x", 100)),
                "y": int(state.get("y", 100)),
                "width": int(state.get("width", 1280)),
                "height": int(state.get("height", 840)),
            }
            self._save_config()
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _save_window_state(self):
        if not self._window:
            return
        try:
            self._config["window"] = {
                "x": int(self._window.x),
                "y": int(self._window.y),
                "width": int(self._window.width),
                "height": int(self._window.height),
            }
            self._save_config()
        except Exception:
            pass

    def ping(self):
        return {"ok": True, "ts": time.time()}

    def get_version(self):
        return {"version": APP_VERSION, "config_version": CONFIG_VERSION}

    def get_startup_info(self):
        return {
            "startup_ms": int((time.time() - self._start_time) * 1000),
            "bots_loaded": len(BOT_REGISTRY),
            "python": sys.version.split()[0],
            "platform": sys.platform,
            "version": APP_VERSION,
        }

    def get_system_info(self):
        cpu = mem = None
        if HAS_PSUTIL:
            try:
                cpu = psutil.cpu_percent(interval=None)
                mem = psutil.virtual_memory().percent
            except Exception:
                pass
        return {
            "python": sys.version.split()[0],
            "platform": sys.platform,
            "bots_dir": BOTS_DIR,
            "cpu": cpu,
            "memory": mem,
            "psutil": HAS_PSUTIL,
        }

    def get_environment(self):
        in_venv = hasattr(sys, "real_prefix") or (
            hasattr(sys, "base_prefix") and sys.base_prefix != sys.prefix
        )
        return {
            "python": sys.executable,
            "version": sys.version.split()[0],
            "venv": in_venv,
            "frozen": getattr(sys, "frozen", False),
            "platform": sys.platform,
        }

    def get_templates(self):
        names = {
            "basic": "Podstawowy (prefix)",
            "slash": "Slash commands",
            "mod": "Moderacja",
            "empty": "Pusty szkielet",
            "sentron": "Sentron (pełny)",
        }
        return [{"id": k, "name": names.get(k, k.capitalize())} for k in TEMPLATES]

    def get_settings(self):
        return dict(self._settings)

    def save_settings(self, data):
        try:
            for k, v in data.items():
                if k in DEFAULT_SETTINGS:
                    self._settings[k] = v
            self._save_config()
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def test_webhook(self, url=None):
        u = url or self._settings.get("webhook_url", "")
        if not u:
            return {"ok": False, "error": "Brak URL webhooka"}
        try:
            send_webhook(
                u,
                v2_title="Test webhooka",
                v2_body="Połączenie z VerCode Bot Manager działa.\nComponents V2 · v%s" % APP_VERSION,
                accent=0x38BDF8,
                embeds=[{
                    "title": "Test webhooka",
                    "description": "Połączenie OK · VerCode v%s" % APP_VERSION,
                    "color": 0x38BDF8,
                }],
            )
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}


    def list_bots(self):
        with REGISTRY_LOCK:
            return [{
                "name": b.name,
                "running": b.is_running(),
                "auto_restart": b.auto_restart,
                "auto_start": b.auto_start,
                "entry": os.path.basename(b.entry),
                "priority": b.priority,
                "tags": b.tags,
                "avatar": b.avatar,
                "note": b.note,
                "discord_username": b.discord_username,
            } for b in BOT_REGISTRY.values()]

    def get_bot_info(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {}
        return {
            "name": b.name,
            "running": b.is_running(),
            "auto_restart": b.auto_restart,
            "auto_start": b.auto_start,
            "pid": b.pid(),
            "uptime": b.uptime(),
            "restarts": b.total_restarts,
            "entry": os.path.basename(b.entry),
            "full_entry": b.entry,
            "priority": b.priority,
            "tags": b.tags,
            "avatar": b.avatar,
            "note": b.note,
            "webhook_url": b.webhook_url,
            "discord_username": b.discord_username,
            "discord_id": b.discord_id,
            "stats": b.get_stats(),
            "level_counts": b.get_level_counts(),
            "last_exit_code": b.last_exit_code,
        }

    def get_all_stats(self):
        with REGISTRY_LOCK:
            return {
                "bots": {b.name: b.get_stats() for b in BOT_REGISTRY.values()},
                "total": len(BOT_REGISTRY),
                "running": sum(1 for b in BOT_REGISTRY.values() if b.is_running()),
            }

    def create_bot(self, name):
        return self.create_from_template(name, "basic")

    def create_from_template(self, name, template="basic"):
        if not safe_name(name):
            return {"ok": False, "error": "Nazwa może zawierać tylko litery, cyfry, _ i -"}
        if name in BOT_REGISTRY:
            return {"ok": False, "error": "Bot o tej nazwie już istnieje"}
        if template not in TEMPLATES:
            return {"ok": False, "error": "Nieznany szablon"}
        dst = os.path.join(BOTS_DIR, name)
        os.makedirs(dst, exist_ok=True)
        entry = os.path.join(dst, "main.py")
        with open(entry, "w", encoding="utf-8") as f:
            f.write(TEMPLATES[template])
        with open(os.path.join(dst, "requirements.txt"), "w", encoding="utf-8") as f:
            f.write("discord.py>=2.4.0\npython-dotenv>=1.0\n")
        with open(os.path.join(dst, ".env"), "w", encoding="utf-8") as f:
            f.write("DISCORD_TOKEN=\nOWNER_IDS=\n")
        prio = self._settings.get("default_priority", "normal")
        with REGISTRY_LOCK:
            b = BotProcess(name, entry, prio)
            b.auto_restart = self._settings.get("default_auto_restart", False)
            BOT_REGISTRY[name] = b
        self._save_config()
        self._notify(b, "create")
        return {"ok": True}

    def pick_file(self):
        if not self._window:
            return None
        r = self._window.create_file_dialog(
            webview.OPEN_DIALOG, allow_multiple=False,
            file_types=("Python (*.py)", "Obrazy (*.png;*.jpg;*.jpeg;*.webp)", "Wszystkie (*.*)"),
        )
        return r[0] if r else None

    def pick_folder(self):
        if not self._window:
            return None
        r = self._window.create_file_dialog(webview.FOLDER_DIALOG)
        return r[0] if r else None

    def import_file(self, path, name):
        if not path or not os.path.isfile(path):
            return {"ok": False, "error": "Nie znaleziono pliku"}
        if not safe_name(name):
            return {"ok": False, "error": "Nieprawidłowa nazwa"}
        if name in BOT_REGISTRY:
            return {"ok": False, "error": "Bot już istnieje"}
        dst = os.path.join(BOTS_DIR, name)
        os.makedirs(dst, exist_ok=True)
        target = os.path.join(dst, os.path.basename(path))
        shutil.copy2(path, target)
        with REGISTRY_LOCK:
            BOT_REGISTRY[name] = BotProcess(name, target)
        self._save_config()
        return {"ok": True}

    def import_folder(self, path, name):
        if not path or not os.path.isdir(path):
            return {"ok": False, "error": "Nie znaleziono folderu"}
        if not safe_name(name):
            return {"ok": False, "error": "Nieprawidłowa nazwa"}
        if name in BOT_REGISTRY:
            return {"ok": False, "error": "Bot już istnieje"}
        dst = os.path.join(BOTS_DIR, name)
        try:
            shutil.copytree(path, dst)
        except Exception as e:
            return {"ok": False, "error": str(e)}
        entry = self._find_entry(dst)
        if not entry:
            shutil.rmtree(dst, ignore_errors=True)
            return {"ok": False, "error": "Brak main.py / bot.py / index.py"}
        with REGISTRY_LOCK:
            BOT_REGISTRY[name] = BotProcess(name, entry)
        self._save_config()
        return {"ok": True}

    def _find_entry(self, folder):
        for c in ("main.py", "bot.py", "index.py", "app.py", "index.js", "bot.js"):
            p = os.path.join(folder, c)
            if os.path.isfile(p):
                return p
        return None

    def delete_bot(self, name):
        with REGISTRY_LOCK:
            b = BOT_REGISTRY.pop(name, None)
        if not b:
            return {"ok": False}
        b.stop()
        shutil.rmtree(os.path.dirname(b.entry), ignore_errors=True)
        av = os.path.join(AVATARS_DIR, f"{name}.png")
        if os.path.isfile(av):
            try:
                os.remove(av)
            except Exception:
                pass
        self._save_config()
        return {"ok": True}

    def rename_bot(self, old, new):
        b = BOT_REGISTRY.get(old)
        if not b:
            return {"ok": False, "error": "Nie ma bota"}
        if not safe_name(new):
            return {"ok": False, "error": "Nieprawidłowa nazwa"}
        if new in BOT_REGISTRY:
            return {"ok": False, "error": "Nazwa zajęta"}
        b.stop()
        old_dir = os.path.dirname(b.entry)
        new_dir = os.path.join(BOTS_DIR, new)
        try:
            os.rename(old_dir, new_dir)
        except Exception as e:
            return {"ok": False, "error": str(e)}
        entry_rel = os.path.relpath(b.entry, old_dir)
        new_entry = os.path.join(new_dir, entry_rel)
        with REGISTRY_LOCK:
            del BOT_REGISTRY[old]
            nb = BotProcess(new, new_entry, b.priority, b.tags, b.avatar, b.note, b.webhook_url)
            nb.auto_restart = b.auto_restart
            nb.auto_start = b.auto_start
            nb.discord_username = b.discord_username
            nb.discord_id = b.discord_id
            BOT_REGISTRY[new] = nb
        old_av = os.path.join(AVATARS_DIR, f"{old}.png")
        new_av = os.path.join(AVATARS_DIR, f"{new}.png")
        if os.path.isfile(old_av):
            try:
                os.rename(old_av, new_av)
                if nb.avatar and not nb.avatar.startswith("http"):
                    nb.avatar = new_av
            except Exception:
                pass
        self._save_config()
        return {"ok": True}

    def duplicate_bot(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        new_name = f"{name}_copy"
        i = 1
        while new_name in BOT_REGISTRY:
            i += 1
            new_name = f"{name}_copy{i}"
        src = os.path.dirname(b.entry)
        dst = os.path.join(BOTS_DIR, new_name)
        try:
            shutil.copytree(src, dst)
        except Exception as e:
            return {"ok": False, "error": str(e)}
        entry = self._find_entry(dst)
        if not entry:
            shutil.rmtree(dst, ignore_errors=True)
            return {"ok": False}
        with REGISTRY_LOCK:
            BOT_REGISTRY[new_name] = BotProcess(new_name, entry, b.priority, b.tags, None, b.note)
        self._save_config()
        return {"ok": True, "name": new_name}

    def start_bot(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        b.start(self._notify)
        return {"ok": True}

    def stop_bot(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        b.stop()
        return {"ok": True}

    def restart_bot(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        b.stop()
        threading.Timer(0.5, lambda: b.start(self._notify)).start()
        return {"ok": True}

    def start_all(self):
        for b in list(BOT_REGISTRY.values()):
            b.start(self._notify)
        return {"ok": True}

    def stop_all(self):
        for b in list(BOT_REGISTRY.values()):
            b.stop()
        return {"ok": True}

    def restart_all(self):
        for b in list(BOT_REGISTRY.values()):
            b.stop()

        def _do():
            time.sleep(0.5)
            for b in list(BOT_REGISTRY.values()):
                b.start(self._notify)

        threading.Thread(target=_do, daemon=True).start()
        return {"ok": True}

    def set_auto_restart(self, name, val):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        b.auto_restart = bool(val)
        self._save_config()
        return {"ok": True}

    def set_auto_start(self, name, val):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        b.auto_start = bool(val)
        self._save_config()
        return {"ok": True}

    def set_priority(self, name, priority):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        if priority not in PRIORITIES:
            return {"ok": False, "error": "Nieprawidłowy priorytet"}
        b.priority = priority
        b._apply_priority()
        self._save_config()
        return {"ok": True}

    def set_tags(self, name, tags):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        b.tags = [t.strip() for t in tags if t.strip()][:10]
        self._save_config()
        return {"ok": True}

    def set_note(self, name, note):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        b.note = (note or "")[:500]
        self._save_config()
        return {"ok": True}

    def set_bot_webhook(self, name, url):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        b.webhook_url = (url or "").strip()
        self._save_config()
        return {"ok": True}

    def refresh_avatar(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False, "error": "Brak bota"}
        token = self.get_token(name)
        if not token:
            return {"ok": False, "error": "Brak tokena w .env — ustaw DISCORD_TOKEN"}
        info = fetch_discord_avatar(token)
        if not info:
            return {"ok": False, "error": "Nie udało się pobrać awatara (sprawdź token)"}
        local = download_avatar(info["url"], name)
        b.avatar = local or info["url"]
        b.discord_username = info.get("username")
        b.discord_id = info.get("id")
        self._save_config()
        return {"ok": True, "avatar": b.avatar, "username": b.discord_username}

    def set_avatar_file(self, name):
        b = BOT_REGISTRY.get(name)
        if not b or not self._window:
            return {"ok": False}
        r = self._window.create_file_dialog(
            webview.OPEN_DIALOG, allow_multiple=False,
            file_types=("Obrazy (*.png;*.jpg;*.jpeg;*.webp;*.gif)", "Wszystkie (*.*)"),
        )
        if not r:
            return {"ok": False, "cancelled": True}
        src = r[0]
        dst = os.path.join(AVATARS_DIR, f"{name}.png")
        try:
            shutil.copy2(src, dst)
            b.avatar = dst
            self._save_config()
            return {"ok": True, "avatar": dst}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def get_avatar_data(self, name):
        b = BOT_REGISTRY.get(name)
        if not b or not b.avatar:
            return {"ok": False}
        path = b.avatar
        if path.startswith("http"):
            return {"ok": True, "url": path}
        if os.path.isfile(path):
            try:
                with open(path, "rb") as f:
                    data = base64.b64encode(f.read()).decode("ascii")
                ext = os.path.splitext(path)[1].lower().lstrip(".") or "png"
                if ext == "jpg":
                    ext = "jpeg"
                return {"ok": True, "data": f"data:image/{ext};base64,{data}"}
            except Exception:
                pass
        return {"ok": False}

    def get_logs(self, name, since):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"lines": [], "seq": since}
        lines, seq = b.get_since(int(since))
        return {"lines": lines, "seq": seq}

    def get_logs_filtered(self, name, since, level="all"):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"lines": [], "seq": since}
        lines, seq = b.get_since(int(since), level)
        return {"lines": lines, "seq": seq}

    def search_logs(self, name, query, since=0):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"lines": [], "seq": since}
        lines, seq = b.search(query, int(since))
        return {"lines": lines, "seq": seq}

    def clear_logs(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        b.clear()
        return {"ok": True}

    def send_stdin(self, name, text):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        return {"ok": b.send_input(text)}

    def get_token(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return ""
        env = os.path.join(os.path.dirname(b.entry), ".env")
        if not os.path.isfile(env):
            return ""
        try:
            for line in open(env, encoding="utf-8"):
                if line.startswith("DISCORD_TOKEN="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
        except Exception:
            pass
        return ""

    def save_token(self, name, token):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        env = os.path.join(os.path.dirname(b.entry), ".env")
        old = ""
        if os.path.isfile(env):
            try:
                old = open(env, encoding="utf-8").read()
            except Exception:
                old = ""
        lines = [l for l in old.splitlines() if not l.startswith("DISCORD_TOKEN=")]
        lines.append(f"DISCORD_TOKEN={token}")
        with open(env, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        return {"ok": True}

    def get_env(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        env = os.path.join(os.path.dirname(b.entry), ".env")
        try:
            content = open(env, encoding="utf-8").read() if os.path.isfile(env) else ""
            return {"ok": True, "content": content}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def save_env(self, name, content):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        env = os.path.join(os.path.dirname(b.entry), ".env")
        try:
            with open(env, "w", encoding="utf-8") as f:
                f.write(content)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def list_files(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"env": [], "config": [], "code": [], "other": []}
        folder = os.path.dirname(b.entry)
        groups = {"env": [], "config": [], "code": [], "other": []}
        code_ext = {".py", ".js", ".ts", ".jsx", ".tsx"}
        config_ext = {".json", ".yml", ".yaml", ".toml", ".cfg", ".ini", ".xml"}
        try:
            for root, dirs, files in os.walk(folder):
                dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git", "node_modules", "venv", ".venv")]
                for f in sorted(files):
                    if f.endswith((".pyc", ".pyo", ".log")):
                        continue
                    full = os.path.join(root, f)
                    rel = os.path.relpath(full, folder).replace("\\", "/")
                    lower = f.lower()
                    if lower == ".env" or lower.endswith(".env"):
                        groups["env"].append(rel)
                    elif any(lower.endswith(e) for e in config_ext) or lower in ("requirements.txt", "pyproject.toml"):
                        groups["config"].append(rel)
                    elif any(lower.endswith(e) for e in code_ext):
                        groups["code"].append(rel)
                    else:
                        groups["other"].append(rel)
        except Exception:
            pass
        return groups

    def read_file(self, name, relpath):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        path = os.path.normpath(os.path.join(os.path.dirname(b.entry), relpath))
        if not path.startswith(os.path.dirname(b.entry)):
            return {"ok": False, "error": "Niedozwolona ścieżka"}
        if not os.path.isfile(path):
            return {"ok": False, "error": "Nie ma pliku"}
        try:
            return {"ok": True, "content": open(path, encoding="utf-8").read()}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def write_file(self, name, relpath, content):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        path = os.path.normpath(os.path.join(os.path.dirname(b.entry), relpath))
        if not path.startswith(os.path.dirname(b.entry)):
            return {"ok": False, "error": "Niedozwolona ścieżka"}
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def create_file(self, name, relpath):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        path = os.path.normpath(os.path.join(os.path.dirname(b.entry), relpath))
        if not path.startswith(os.path.dirname(b.entry)):
            return {"ok": False, "error": "Niedozwolona ścieżka"}
        if os.path.exists(path):
            return {"ok": False, "error": "Plik już istnieje"}
        try:
            os.makedirs(os.path.dirname(path) or os.path.dirname(b.entry), exist_ok=True)
            open(path, "w", encoding="utf-8").close()
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def delete_file(self, name, relpath):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        if relpath == os.path.basename(b.entry):
            return {"ok": False, "error": "Nie można usunąć głównego pliku"}
        path = os.path.normpath(os.path.join(os.path.dirname(b.entry), relpath))
        if not path.startswith(os.path.dirname(b.entry)):
            return {"ok": False, "error": "Niedozwolona ścieżka"}
        if not os.path.isfile(path):
            return {"ok": False, "error": "Nie ma pliku"}
        try:
            os.remove(path)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def install_requirements(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        folder = os.path.dirname(b.entry)
        req = os.path.join(folder, "requirements.txt")
        if not os.path.isfile(req):
            return {"ok": False, "error": "Brak requirements.txt"}
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-r", req],
                capture_output=True, text=True, timeout=240,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            b.log(f"[HOST] pip install zakończony kod={result.returncode}",
                  "info" if result.returncode == 0 else "error")
            if result.stderr:
                for line in result.stderr.splitlines()[-30:]:
                    b.log(f"[pip] {line}")
            return {"ok": result.returncode == 0, "output": (result.stdout[-3000:] + result.stderr[-3000:])}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def run_syntax_check(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        if not b.entry.endswith(".py"):
            return {"ok": True, "message": "Nie dotyczy (nie Python)"}
        try:
            with open(b.entry, encoding="utf-8") as f:
                src = f.read()
            ast.parse(src)
            return {"ok": True, "message": "Składnia poprawna"}
        except SyntaxError as e:
            return {"ok": False, "error": f"{e.msg} (linia {e.lineno})"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def open_folder(self, name):
        b = BOT_REGISTRY.get(name)
        if not b:
            return {"ok": False}
        folder = os.path.dirname(b.entry)
        try:
            if os.name == "nt":
                os.startfile(folder)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", folder])
            else:
                subprocess.Popen(["xdg-open", folder])
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def export_logs(self, name):
        b = BOT_REGISTRY.get(name)
        if not b or not self._window:
            return {"ok": False}
        path = self._window.create_file_dialog(
            webview.SAVE_DIALOG,
            save_filename=f"{name}_logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
            file_types=("Text (*.txt)", "Wszystkie (*.*)"),
        )
        if not path:
            return {"ok": False, "cancelled": True}
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(f"# VerCode Bot Manager — logi: {name}\n")
                f.write(f"# Wyeksportowano: {ts()}\n\n")
                for seq, line, level in b.logs:
                    f.write(f"[{level.upper()}] {line}\n")
            return {"ok": True, "path": path}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def backup_bot(self, name):
        b = BOT_REGISTRY.get(name)
        if not b or not self._window:
            return {"ok": False}
        path = self._window.create_file_dialog(
            webview.SAVE_DIALOG,
            save_filename=f"{name}_{datetime.now().strftime('%Y%m%d')}.tar.gz",
            file_types=("Archiwum (*.tar.gz)", "Wszystkie (*.*)"),
        )
        if not path:
            return {"ok": False, "cancelled": True}
        try:
            src = os.path.dirname(b.entry)
            with tarfile.open(path, "w:gz") as tar:
                tar.add(src, arcname=name)
            return {"ok": True, "path": path}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def restore_bot(self, name_hint=None):
        if not self._window:
            return {"ok": False}
        r = self._window.create_file_dialog(
            webview.OPEN_DIALOG, allow_multiple=False,
            file_types=("Archiwum (*.tar.gz)", "Wszystkie (*.*)"),
        )
        if not r:
            return {"ok": False, "cancelled": True}
        path = r[0]
        try:
            tmp = tempfile.mkdtemp()
            with tarfile.open(path, "r:gz") as tar:
                tar.extractall(tmp)
            entries = os.listdir(tmp)
            if not entries:
                return {"ok": False, "error": "Puste archiwum"}
            extracted = os.path.join(tmp, entries[0])
            entry = self._find_entry(extracted)
            if not entry:
                return {"ok": False, "error": "Brak pliku startowego"}
            name = name_hint or entries[0]
            if not safe_name(name):
                name = re.sub(r"[^\w\-]", "_", entries[0])
            i = 1
            base = name
            while name in BOT_REGISTRY:
                name = f"{base}_{i}"
                i += 1
            dst = os.path.join(BOTS_DIR, name)
            shutil.copytree(extracted, dst)
            entry = self._find_entry(dst)
            with REGISTRY_LOCK:
                BOT_REGISTRY[name] = BotProcess(name, entry)
            self._save_config()
            return {"ok": True, "name": name}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _save_config(self):
        with REGISTRY_LOCK:
            data = {
                "version": CONFIG_VERSION,
                "window": self._config.get("window", {}),
                "settings": self._settings,
                "bots": {
                    n: {
                        "entry": b.entry,
                        "auto_restart": b.auto_restart,
                        "auto_start": b.auto_start,
                        "priority": b.priority,
                        "tags": b.tags,
                        "avatar": b.avatar,
                        "note": b.note,
                        "webhook_url": b.webhook_url,
                        "discord_username": b.discord_username,
                        "discord_id": b.discord_id,
                    }
                    for n, b in BOT_REGISTRY.items()
                },
            }
        try:
            if os.path.isfile(CONFIG):
                shutil.copy2(CONFIG, CONFIG_BACKUP)
            tmp = CONFIG + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(tmp, CONFIG)
        except Exception as e:
            print("save_config:", e)

    def _load_config(self):
        if not os.path.isfile(CONFIG):
            return
        try:
            with open(CONFIG, encoding="utf-8") as f:
                data = json.load(f)
            ver = data.get("version", 1)
            self._config = {"window": data.get("window", {})}
            if "settings" in data:
                for k, v in data["settings"].items():
                    if k in DEFAULT_SETTINGS:
                        self._settings[k] = v
            bots_data = data.get("bots", data) if ver >= 2 else data
            for n, d in bots_data.items():
                if n in ("version", "window", "settings") or not isinstance(d, dict):
                    continue
                entry = d.get("entry")
                if entry and os.path.isfile(entry):
                    b = BotProcess(
                        n, entry,
                        d.get("priority", "normal"),
                        d.get("tags", []),
                        d.get("avatar"),
                        d.get("note", ""),
                        d.get("webhook_url", ""),
                    )
                    b.auto_restart = d.get("auto_restart", False)
                    b.auto_start = d.get("auto_start", False)
                    b.discord_username = d.get("discord_username")
                    b.discord_id = d.get("discord_id")
                    with REGISTRY_LOCK:
                        BOT_REGISTRY[n] = b
        except Exception as e:
            print("load_config:", e)

    def auto_start_bots(self):
        if not self._settings.get("auto_start_on_launch"):
            for b in list(BOT_REGISTRY.values()):
                if b.auto_start:
                    b.start(self._notify)
            return
        for b in list(BOT_REGISTRY.values()):
            b.start(self._notify)

    def check_for_updates(self, timeout=10, manual=False):
        channel = (self._settings.get("update_channel") or "stable").lower()
        urls = []
        if channel == "beta":
            urls = [UPDATE_MANIFEST_BETA_URL, UPDATE_MANIFEST_URL]
        else:
            urls = [UPDATE_MANIFEST_URL, UPDATE_MANIFEST_BETA_URL]
        last_err = None
        data = None
        used = None
        for base in urls:
            if not base:
                continue
            try:
                bust = base + ("&" if "?" in base else "?") + "t=%d" % int(time.time())
                req = urllib.request.Request(
                    bust,
                    headers={"User-Agent": "VerCode/" + APP_VERSION, "Cache-Control": "no-cache", "Pragma": "no-cache"},
                )
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                used = base
                break
            except Exception as e:
                last_err = e
                data = None
        if not data:
            return {"ok": False, "error": str(last_err or "Brak manifestu"), "current": APP_VERSION, "update": False}
        remote = str(data.get("version") or "").strip()
        if not remote:
            return {"ok": True, "update": False, "current": APP_VERSION}
        newer = self._version_gt(remote, APP_VERSION)
        skipped = (not manual) and (self._settings.get("skipped_version") == remote)
        exe_url = str(data.get("exe_url") or "").strip()
        tar_url = str(data.get("tar_url") or "").strip()
        download_url = str(data.get("download_url") or "").strip() or exe_url or tar_url
        package = exe_url or tar_url or download_url
        has = bool(newer and package and not skipped)
        try:
            self._settings["last_update_check"] = time.time()
        except Exception:
            pass
        result = {
            "ok": True,
            "update": has,
            "newer": newer,
            "current": APP_VERSION,
            "latest": remote,
            "channel": str(data.get("channel") or channel),
            "changelog": str(data.get("changelog") or ""),
            "highlights": data.get("highlights") if isinstance(data.get("highlights"), list) else [],
            "notice": str(data.get("notice") or ""),
            "mandatory": bool(data.get("mandatory", False)),
            "download_url": download_url,
            "exe_url": exe_url,
            "tar_url": tar_url,
            "sha256": str(data.get("sha256") or "").strip().lower(),
            "size": data.get("size") or 0,
            "package_ok": bool(package),
            "manifest": used or "",
            "skipped": skipped,
        }
        if has:
            self._pending_update = result
        return result

    def _version_gt(self, a, b):
        def parts(v):
            out = []
            for x in str(v).split("."):
                try:
                    out.append(int(x))
                except Exception:
                    out.append(0)
            return out
        pa, pb = parts(a), parts(b)
        n = max(len(pa), len(pb))
        pa += [0] * (n - len(pa))
        pb += [0] * (n - len(pb))
        return pa > pb

    def get_feedback_state(self):
        last = float(self._settings.get("last_feedback_at") or 0)
        now = time.time()
        due = (now - last) >= FEEDBACK_INTERVAL_HOURS * 3600
        return {
            "show": due and bool(self._settings.get("first_run_done", False)),
            "discord": DISCORD_INVITE,
            "hours": FEEDBACK_INTERVAL_HOURS,
            "last": last,
        }

    def dismiss_feedback(self, later=False):
        self._settings["last_feedback_at"] = time.time()
        if later:
            self._settings["last_feedback_at"] = time.time() - (FEEDBACK_INTERVAL_HOURS * 3600) + 12 * 3600
        self._save_config()
        return {"ok": True}

    def submit_feedback(self, text, category="general"):
        text = (text or "").strip()[:2000]
        path = os.path.join(LOG_DIR, "feedback.jsonl")
        try:
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps({
                    "ts": ts(),
                    "category": category,
                    "text": text,
                    "version": APP_VERSION,
                }, ensure_ascii=False) + "\n")
        except Exception:
            pass
        self._settings["last_feedback_at"] = time.time()
        self._save_config()
        return {"ok": True, "discord": DISCORD_INVITE}

    def get_data_dir(self):
        return {"ok": True, "path": DATA_DIR, "bots": BOTS_DIR, "logs": LOG_DIR}

    def open_data_dir(self):
        try:
            if os.name == "nt":
                os.startfile(DATA_DIR)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", DATA_DIR])
            else:
                subprocess.Popen(["xdg-open", DATA_DIR])
            return {"ok": True, "path": DATA_DIR}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def get_public_links(self):
        return {
            "discord": DISCORD_INVITE,
            "update_stable": UPDATE_MANIFEST_URL,
            "update_beta": UPDATE_MANIFEST_BETA_URL,
            "version": APP_VERSION,
        }


    # ---------- AUTO-UPDATE ----------
    def get_pending_update(self):
        return dict(getattr(self, "_pending_update", None) or {})

    def get_update_progress(self):
        return dict(getattr(self, "_upd", None) or {"stage": "idle", "pct": 0, "text": ""})

    def _upd_set(self, stage, pct, text):
        self._upd = {"stage": stage, "pct": int(pct), "text": str(text or "")}

    def _download_with_progress(self, url, dest, retries=3):
        last_err = None
        for attempt in range(max(1, int(retries))):
            try:
                if attempt:
                    self._upd_set("download", 5, "Ponawiam pobieranie (%d/%d)…" % (attempt + 1, retries))
                req = urllib.request.Request(
                    url,
                    headers={"User-Agent": "VerCode/" + APP_VERSION, "Cache-Control": "no-cache", "Accept": "*/*"},
                )
                hsh = hashlib.sha256()
                done = 0
                with urllib.request.urlopen(req, timeout=120) as resp, open(dest, "wb") as out:
                    total = int(resp.headers.get("Content-Length") or 0)
                    while True:
                        chunk = resp.read(256 * 1024)
                        if not chunk:
                            break
                        out.write(chunk)
                        hsh.update(chunk)
                        done += len(chunk)
                        if total > 0:
                            pct = min(78, int(done * 78 / total))
                            self._upd_set("download", pct, "Pobieranie %.1f / %.1f MB" % (done / 1048576, total / 1048576))
                        else:
                            self._upd_set("download", min(70, 8 + done // (512 * 1024)), "Pobieranie %.1f MB" % (done / 1048576))
                if done < 64:
                    raise ValueError("Plik za mały (%d B)" % done)
                self._upd_set("download", 80, "Pobrano %.1f MB" % (done / 1048576))
                return hsh.hexdigest()
            except Exception as e:
                last_err = e
                try:
                    if os.path.isfile(dest):
                        os.remove(dest)
                except Exception:
                    pass
                time.sleep(0.8 * (attempt + 1))
        raise last_err if last_err else RuntimeError("Pobieranie nieudane")

    def apply_update(self, download_url=None, info=None):
        try:
            self._upd_set("check", 3, "Przygotowanie…")
            info = info or getattr(self, "_pending_update", None) or self.check_for_updates(timeout=12, manual=True)
            if not isinstance(info, dict):
                info = {}
            url = (download_url or "").strip()
            if not url:
                url = (info.get("exe_url") or info.get("tar_url") or info.get("download_url") or "").strip()
            if not url.startswith("https://"):
                self._upd_set("error", 0, "Brak poprawnego URL paczki (https).")
                return {"ok": False, "error": "Brak URL paczki"}
            tmp = tempfile.mkdtemp(prefix="vercode-upd-")
            path = os.path.join(tmp, "pack.bin")
            self._upd_set("download", 5, "Pobieranie…")
            digest = self._download_with_progress(url, path, retries=3)
            want = str(info.get("sha256") or "").strip().lower()
            self._upd_set("verify", 85, "Weryfikacja…")
            if want and digest != want:
                self._upd_set("error", 0, "SHA-256 niezgodne — przerwano.")
                return {"ok": False, "error": "SHA-256 niezgodne"}
            with open(path, "rb") as f:
                head = f.read(8)
            is_exe = head[:2] == b"MZ" or url.lower().split("?")[0].endswith(".exe")
            is_gz = head[:2] == b"\x1f\x8b" or url.lower().split("?")[0].endswith(".gz")
            frozen = getattr(sys, "frozen", False)

            if is_exe:
                return self._install_exe_update(path, tmp)
            if is_gz or (not is_exe):
                return self._install_source_update(path, tmp)

            self._upd_set("error", 0, "Nieznany format paczki")
            return {"ok": False, "error": "Nieznany format"}
        except Exception as e:
            self._upd_set("error", 0, str(e))
            return {"ok": False, "error": str(e)}

    def _install_exe_update(self, path, tmp):
        if not getattr(sys, "frozen", False):
            self._upd_set("error", 0, "Paczka .exe wymaga skompilowanej aplikacji. Opublikuj tar.gz dla trybu źródłowego.")
            return {"ok": False, "error": "Wymagany build .exe"}
        if os.name != "nt":
            self._upd_set("error", 0, "Instalacja .exe tylko na Windows")
            return {"ok": False, "error": "Tylko Windows"}
        self._upd_set("install", 90, "Instalowanie…")
        dest = sys.executable
        new_path = dest + ".new"
        old_path = dest + ".old"
        shutil.copyfile(path, new_path)
        bat = os.path.join(tmp, "apply.bat")
        q = lambda x: str(x).replace('"', "")
        with open(bat, "w", encoding="utf-8") as f:
            f.write("@echo off\r\n")
            f.write("set /a n=0\r\n:retry\r\nset /a n+=1\r\n")
            f.write("if %n% gtr 45 goto fail\r\n")
            f.write("timeout /t 1 /nobreak >nul\r\n")
            f.write('del /f /q "%s" >nul 2>&1\r\n' % q(old_path))
            f.write('move /y "%s" "%s" >nul 2>&1\r\n' % (q(dest), q(old_path)))
            f.write("if errorlevel 1 goto retry\r\n")
            f.write('move /y "%s" "%s" >nul 2>&1\r\n' % (q(new_path), q(dest)))
            f.write("if errorlevel 1 (\r\n")
            f.write('  move /y "%s" "%s" >nul 2>&1\r\n' % (q(old_path), q(dest)))
            f.write("  goto fail\r\n)\r\n")
            f.write('start "" "%s"\r\n' % q(dest))
            f.write("timeout /t 4 /nobreak >nul\r\n")
            f.write('del /f /q "%s" >nul 2>&1\r\n' % q(old_path))
            f.write("exit /b 0\r\n:fail\r\n")
            f.write('if exist "%s" del /f /q "%s"\r\n' % (q(new_path), q(new_path)))
            f.write('start "" "%s"\r\nexit /b 1\r\n' % q(dest))
        self._upd_set("restart", 100, "Restart…")
        try:
            self._settings["skipped_version"] = ""
            self._save_config()
        except Exception:
            pass
        flags = 0
        if hasattr(subprocess, "CREATE_NO_WINDOW"):
            flags |= subprocess.CREATE_NO_WINDOW
        if hasattr(subprocess, "DETACHED_PROCESS"):
            flags |= subprocess.DETACHED_PROCESS
        subprocess.Popen(["cmd", "/c", bat], creationflags=flags or 0, close_fds=True)
        try:
            self.shutdown()
        except Exception:
            pass
        threading.Timer(0.7, lambda: os._exit(0)).start()
        return {"ok": True, "mode": "exe", "restarting": True}

    def _install_source_update(self, path, tmp):
        self._upd_set("install", 88, "Rozpakowywanie…")
        extract = os.path.join(tmp, "src")
        os.makedirs(extract, exist_ok=True)
        try:
            with tarfile.open(path, "r:gz") as tar:
                base = os.path.realpath(extract)
                for m in tar.getmembers():
                    target = os.path.realpath(os.path.join(extract, m.name))
                    if not target.startswith(base + os.sep) and target != base:
                        raise ValueError("Niebezpieczna ścieżka w paczce")
                tar.extractall(extract)
        except Exception as e:
            # try plain tar
            try:
                with tarfile.open(path, "r:*") as tar:
                    tar.extractall(extract)
            except Exception:
                self._upd_set("error", 0, "Nie można rozpakować: %s" % e)
                return {"ok": False, "error": str(e)}
        root = extract
        for name in os.listdir(extract):
            pth = os.path.join(extract, name)
            if os.path.isdir(pth) and name not in ("__MACOSX",):
                # if looks like project root
                if os.path.isfile(os.path.join(pth, "host.py")) or os.path.isdir(os.path.join(pth, "web")):
                    root = pth
                    break
        targets = ["host.py", "web", "requirements.txt", "admin_host.py", "run.bat", "run_admin.bat", "README.md", "bots"]
        copied = []
        for rel in targets:
            src = os.path.join(root, rel)
            if not os.path.exists(src):
                continue
            dst = os.path.join(APP_DIR, rel)
            if os.path.isdir(src):
                if os.path.isdir(dst):
                    shutil.rmtree(dst, ignore_errors=True)
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
            copied.append(rel)
        if not copied:
            self._upd_set("error", 0, "Paczka nie zawiera plików hosta")
            return {"ok": False, "error": "Pusta paczka"}
        try:
            self._settings["skipped_version"] = ""
            self._settings["last_update_check"] = time.time()
            self._save_config()
        except Exception:
            pass
        self._upd_set("restart", 100, "Restart…")
        try:
            self.shutdown()
        except Exception:
            pass
        env = dict(os.environ)
        env["VERCODE_UPDATED"] = "1"
        subprocess.Popen([sys.executable, os.path.join(APP_DIR, "host.py")], cwd=APP_DIR, env=env, close_fds=True)
        threading.Timer(0.8, lambda: os._exit(0)).start()
        return {"ok": True, "mode": "source", "copied": copied, "restarting": True}

    def start_auto_update(self):
        def run():
            info = getattr(self, "_pending_update", None) or {}
            res = self.apply_update(info=info if info else None)
            if not res.get("ok"):
                self._upd_set("error", 0, res.get("error") or "Błąd aktualizacji")
        threading.Thread(target=run, daemon=True).start()
        return {"ok": True}

    def skip_update(self):
        fn = getattr(self, "_skip_update", None)
        if callable(fn):
            try:
                fn()
                return {"ok": True}
            except Exception as e:
                return {"ok": False, "error": str(e)}
        return {"ok": True}

    def skip_version(self, version=None):
        ver = str(version or (getattr(self, "_pending_update", {}) or {}).get("latest") or "").strip()
        if ver:
            self._settings["skipped_version"] = ver
            try:
                self._save_config()
            except Exception:
                pass
        self._pending_update = None
        return {"ok": True, "skipped": ver}

    def get_update_state(self):
        return {
            "current": APP_VERSION,
            "channel": self._settings.get("update_channel", "stable"),
            "auto_update": self._settings.get("auto_update", True) is not False,
            "last_check": self._settings.get("last_update_check"),
            "skipped_version": self._settings.get("skipped_version") or "",
            "pending": bool(getattr(self, "_pending_update", None)),
        }

    def run_update_check_bg(self):
        def work():
            try:
                info = self.check_for_updates(timeout=12, manual=False)
                if info and info.get("update"):
                    self._pending_update = info
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()
        return {"ok": True}

    def _fetch_json(self, url, timeout=12):
        req = urllib.request.Request(url, headers={"User-Agent": "VerCode/" + APP_VERSION, "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def _installed_pack(self, name):
        p = os.path.join(BOTS_DIR, name, PACK_META)
        try:
            with open(p, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def store_list(self):
        try:
            cat = self._fetch_json(CATALOG_URL + "?t=" + str(int(time.time())))
        except Exception as e:
            return {"ok": False, "error": "Nie można pobrać katalogu: %s" % e, "bots": []}
        rows = []
        for e in cat.get("bots", []):
            bid = str(e.get("id", ""))
            if not safe_name(bid):
                continue
            inst = self._installed_pack(bid)
            folder = os.path.isdir(os.path.join(BOTS_DIR, bid))
            row = dict(e)
            row.update({
                "installed": bool(inst),
                "installed_version": (inst or {}).get("version", ""),
                "update": bool(inst and self._version_gt(e.get("version", "0"), (inst or {}).get("version", "0"))),
                "name_taken": folder and not inst,
            })
            rows.append(row)
        return {"ok": True, "bots": rows, "updated_at": cat.get("updated_at", "")}

    def store_install(self, bot_id, name=None):
        try:
            if not safe_name(bot_id):
                return {"ok": False, "error": "Zły identyfikator"}
            cat = self._fetch_json(CATALOG_URL + "?t=" + str(int(time.time())))
            entry = next((x for x in cat.get("bots", []) if x.get("id") == bot_id), None)
            if not entry:
                return {"ok": False, "error": "Bota nie ma już w katalogu"}
            name = (name or bot_id).strip()
            if not safe_name(name):
                return {"ok": False, "error": "Nazwa może zawierać tylko litery, cyfry, _ i -"}
            dest = os.path.join(BOTS_DIR, name)
            inst = self._installed_pack(name)
            updating = bool(inst and inst.get("id") == bot_id)
            if os.path.exists(dest) and not updating:
                return {"ok": False, "error": "Folder bota '%s' już istnieje — podaj inną nazwę" % name, "name_taken": True}
            url = str(entry.get("url", ""))
            if not url.startswith("http"):
                url = PAGES_BASE + url.lstrip("/")
            if not url.startswith("https://"):
                return {"ok": False, "error": "Adres paczki musi być https"}
            tmp = tempfile.mkdtemp(prefix="vercode-bot-")
            pack = os.path.join(tmp, "pack.tar.gz")
            req = urllib.request.Request(url, headers={"User-Agent": "VerCode/" + APP_VERSION})
            h = hashlib.sha256()
            size = 0
            with urllib.request.urlopen(req, timeout=30) as resp, open(pack, "wb") as f:
                while True:
                    chunk = resp.read(256 * 1024)
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > MAX_PACK_BYTES:
                        raise ValueError("Paczka jest za duża")
                    h.update(chunk)
                    f.write(chunk)
            want = str(entry.get("sha256", "")).lower()
            if want and h.hexdigest() != want:
                return {"ok": False, "error": "Suma kontrolna paczki nie pasuje — przerwano"}
            ex = os.path.join(tmp, "x")
            safe_extract(pack, ex)
            root = ex
            items = [i for i in os.listdir(ex) if i != "__MACOSX"]
            if len(items) == 1 and os.path.isdir(os.path.join(ex, items[0])):
                root = os.path.join(ex, items[0])
            was_running = False
            with REGISTRY_LOCK:
                existing = BOT_REGISTRY.get(name)
            if updating and existing:
                was_running = existing.is_running()
                if was_running:
                    existing.stop()
                    time.sleep(0.6)
            copied = 0
            for dp, dn, fn in os.walk(root):
                rel_dir = os.path.relpath(dp, root)
                for fname in fn:
                    rel = fname if rel_dir == "." else os.path.join(rel_dir, fname)
                    top = rel.split(os.sep)[0]
                    dst = os.path.join(dest, rel)
                    keep = (top in PRESERVE_NAMES or rel.lower().endswith(PRESERVE_EXT))
                    if keep and os.path.exists(dst):
                        continue
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.copy2(os.path.join(dp, fname), dst)
                    copied += 1
            envp = os.path.join(dest, ".env")
            ex_env = os.path.join(dest, ".env.example")
            if not os.path.exists(envp) and os.path.exists(ex_env):
                shutil.copy2(ex_env, envp)
            with open(os.path.join(dest, PACK_META), "w", encoding="utf-8") as f:
                json.dump({"id": bot_id, "version": entry.get("version", ""), "sha256": want or h.hexdigest(),
                           "installed_at": time.time()}, f)
            entry_file = self._find_entry(dest)
            if not entry_file:
                return {"ok": False, "error": "Paczka nie zawiera pliku startowego (main.py / bot.py …)"}
            if not existing:
                prio = self._settings.get("default_priority", "normal")
                with REGISTRY_LOCK:
                    b = BotProcess(name, entry_file, prio)
                    b.auto_restart = self._settings.get("default_auto_restart", False)
                    BOT_REGISTRY[name] = b
                self._notify(b, "create")
            else:
                b = existing
            self._save_config()
            if os.path.exists(os.path.join(dest, "requirements.txt")):
                threading.Thread(target=lambda: self.install_requirements(name), daemon=True).start()
            if was_running:
                threading.Timer(2.0, lambda: b.start(self._notify)).start()
            return {"ok": True, "name": name, "version": entry.get("version", ""), "updated": updating, "files": copied}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def store_update_all(self):
        lst = self.store_list()
        if not lst.get("ok"):
            return lst
        done, failed = [], []
        for e in lst["bots"]:
            if e.get("update"):
                r = self.store_install(e["id"], e["id"])
                (done if r.get("ok") else failed).append({"id": e["id"], "version": e.get("version"), "error": r.get("error")})
        return {"ok": True, "updated": done, "failed": failed}

    def download_update_info(self):
        info = self.check_for_updates()
        if not info.get("ok"):
            return info
        return {
            "ok": True,
            "update": info.get("update", False),
            "current": info.get("current"),
            "latest": info.get("latest"),
            "changelog": info.get("changelog", ""),
            "download_url": info.get("download_url", ""),
            "mandatory": info.get("mandatory", False),
            "highlights": info.get("highlights") if isinstance(info.get("highlights"), list) else [],
            "frozen": bool(getattr(sys, "frozen", False)),
        }


    def finish_installer(self, data=None):
        self.set_first_run_done(data or {})
        fn = getattr(self, "_finish_installer", None)
        if callable(fn):
            try:
                fn()
            except Exception as e:
                return {"ok": False, "error": str(e)}
        return {"ok": True}


    def get_first_run(self):
        return {"done": bool(self._settings.get("first_run_done", False))}

    def set_first_run_done(self, data=None):
        self._settings["first_run_done"] = True
        if data and isinstance(data, dict):
            if data.get("webhook_url"):
                self._settings["webhook_url"] = str(data["webhook_url"]).strip()
            if "webhook_events" in data and isinstance(data["webhook_events"], dict):
                self._settings["webhook_events"] = data["webhook_events"]
            if data.get("update_channel") in ("stable", "beta"):
                self._settings["update_channel"] = data["update_channel"]
        self._save_config()
        return {"ok": True}

    def apply_template_pack(self, url):
        if not url or not url.startswith("http"):
            return {"ok": False, "error": "Zły URL"}
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "VerCode/" + APP_VERSION})
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read()
            tmp = tempfile.mkdtemp()
            archive = os.path.join(tmp, "pack.tar.gz")
            with open(archive, "wb") as f:
                f.write(raw)
            with tarfile.open(archive, "r:gz") as tar:
                tar.extractall(tmp)
            # expect templates/ or flat
            root = tmp
            for name in os.listdir(tmp):
                p = os.path.join(tmp, name)
                if os.path.isdir(p) and name not in ("__MACOSX",):
                    root = p
                    break
            count = 0
            for item in os.listdir(root):
                src = os.path.join(root, item)
                if not os.path.isdir(src):
                    continue
                if not safe_name(item):
                    continue
                dst = os.path.join(BOTS_DIR, item)
                if os.path.exists(dst):
                    continue
                shutil.copytree(src, dst)
                entry = self._find_entry(dst)
                if entry:
                    with REGISTRY_LOCK:
                        BOT_REGISTRY[item] = BotProcess(item, entry)
                    count += 1
            self._save_config()
            return {"ok": True, "imported": count}
        except Exception as e:
            return {"ok": False, "error": str(e)}


    def shutdown(self):
        self._save_window_state()
        for b in list(BOT_REGISTRY.values()):
            try:
                b.stop()
            except Exception:
                pass


def open_main_window(api, close_win=None):
    ws = api.get_window_state() or {}
    try:
        width = int(ws.get("width") or 1400)
        height = int(ws.get("height") or 900)
    except Exception:
        width, height = 1400, 900
    width = max(720, min(width, 7680))
    height = max(520, min(height, 4320))
    kwargs = {
        "js_api": api,
        "width": width,
        "height": height,
        "min_size": (720, 520),
        "frameless": True,
        "easy_drag": False,
        "resizable": True,
        "background_color": "#05060a",
        "text_select": True,
    }
    try:
        x = ws.get("x")
        y = ws.get("y")
        if x is not None and y is not None:
            x, y = int(x), int(y)
            if -200 <= x <= 4000 and -200 <= y <= 2500:
                kwargs["x"] = x
                kwargs["y"] = y
    except Exception:
        pass
    index = resource_path("web/index.html")
    if not os.path.isfile(index):
        index = os.path.join(APP_DIR, "web", "index.html")
    win = webview.create_window(WINDOW_TITLE, index, **kwargs)
    api.set_window(win)
    try:
        win.events.closing += api.shutdown
    except Exception:
        pass

    def on_shown():
        try:
            schedule_dwm()
        except Exception:
            pass
        try:
            win.show()
        except Exception:
            pass
        threading.Timer(0.6, api.auto_start_bots).start()
        threading.Timer(2.0, api.run_update_check_bg).start()

    try:
        win.events.shown += on_shown
    except Exception:
        threading.Timer(1.0, on_shown).start()
    if close_win is not None:
        try:
            close_win.destroy()
        except Exception:
            pass
    return win


def main():
    api = Api()
    first = not api.get_first_run().get("done")

    if first:
        inst = resource_path("web/installer.html")
        if not os.path.isfile(inst):
            inst = os.path.join(APP_DIR, "web", "installer.html")
        installer = webview.create_window(
            "VerCode — instalacja",
            inst,
            js_api=api,
            width=720,
            height=560,
            min_size=(640, 480),
            frameless=True,
            easy_drag=False,
            background_color="#05060a",
            resizable=False,
        )
        api.set_window(installer)
        api._finish_installer = lambda: open_main_window(api, installer)
        webview.start(debug=False, http_server=True)
        return

    open_main_window(api)
    try:
        threading.Timer(1.5, api.run_update_check_bg).start()
    except Exception:
        pass
    webview.start(debug=False, http_server=True)


if __name__ == "__main__":
    main()
