#!/usr/bin/env python3
import json
import os
import sys
import tarfile
import hashlib
import base64
import urllib.request
import urllib.error
import subprocess
import shutil
import tempfile
import zipfile
import gzip
import re
import time
from datetime import datetime, timezone
from pathlib import Path

try:
    import webview
except ImportError:
    print("pip install pywebview")
    raise SystemExit(1)

APP_DIR = Path(__file__).resolve().parent
OUT_DIR = APP_DIR / "admin_out"
OUT_DIR.mkdir(exist_ok=True)
PAGES_DIR = APP_DIR / "pages"
PAGES_DIR.mkdir(exist_ok=True)
HISTORY = OUT_DIR / "history.json"
STABLE_URL = "https://vern0xx.github.io/vercode-bot-manager/manifest.json"
BETA_URL = "https://vern0xx.github.io/vercode-bot-manager/manifest-beta.json"
PAGES_HINT = "https://vern0xx.github.io/vercode-bot-manager/"
ADMIN_CFG = OUT_DIR / "admin_config.json"
DEFAULT_PUBLISH = {
    "github_token": "",
    "github_owner": "vern0xx",
    "github_repo": "vercode-bot-manager",
    "github_branch": "gh-pages",
    "auto_publish": True,
}

BOTS_PAGES = PAGES_DIR / "bots"
CATALOG = BOTS_PAGES / "catalog.json"
PENDING = OUT_DIR / "pending_delete.json"
ENTRY_NAMES = ("main.py", "bot.py", "index.py", "app.py", "index.js", "bot.js")
EXCLUDE_DIRS = {"__pycache__", ".git", ".venv", "venv", "node_modules", ".idea", ".vscode", "logs", "__MACOSX"}
EXCLUDE_EXT = (".pyc", ".pyo", ".log", ".db", ".sqlite", ".sqlite3", ".token")
SCAN_EXT = (".py", ".js", ".json", ".txt", ".md", ".cfg", ".ini", ".yml", ".yaml", ".toml", ".example")
SECRET_RE = re.compile(r"[MNO][A-Za-z\d_-]{23,27}\.[A-Za-z\d_-]{6}\.[A-Za-z\d_-]{27,40}")
MAX_PACK = 60 * 1024 * 1024
KEEP_EXES = 3


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def git_blob_sha(b):
    return hashlib.sha1(b"blob %d\0" % len(b) + b).hexdigest()


def ver_tuple(v):
    out = []
    for x in str(v).split("."):
        try:
            out.append(int(re.sub(r"\D", "", x) or 0))
        except Exception:
            out.append(0)
    return out


def load_json(path, default):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def load_catalog():
    c = load_json(CATALOG, {})
    if not isinstance(c, dict):
        c = {}
    c.setdefault("schema", 1)
    c.setdefault("bots", [])
    return c


def save_catalog(c):
    c["schema"] = 1
    c["updated_at"] = now_iso()
    save_json(CATALOG, c)


def load_pending():
    p = load_json(PENDING, [])
    return p if isinstance(p, list) else []


def add_pending(paths):
    cur = load_pending()
    for x in paths:
        if x not in cur:
            cur.append(x)
    save_json(PENDING, cur)


def slugify(name):
    s = re.sub(r"[^\w\-]+", "-", str(name).strip().lower()).strip("-_")
    return s[:48]


def safe_extract(path, dest):
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    base = os.path.realpath(dest)

    def check(name):
        t = os.path.realpath(os.path.join(dest, name))
        if t != base and not t.startswith(base + os.sep):
            raise ValueError("Niebezpieczna ścieżka w archiwum: " + name)

    path = str(path)
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            total = 0
            for i in z.infolist():
                check(i.filename)
                total += i.file_size
                if total > 400 * 1024 * 1024:
                    raise ValueError("Archiwum po rozpakowaniu jest za duże")
            z.extractall(dest)
    elif tarfile.is_tarfile(path):
        with tarfile.open(path, "r:*") as tar:
            for m in tar.getmembers():
                if m.issym() or m.islnk() or m.isdev():
                    raise ValueError("Linki w archiwum niedozwolone: " + m.name)
                check(m.name)
            tar.extractall(dest)
    else:
        raise ValueError("Obsługiwane formaty: .zip, .tar.gz, .tgz, .tar lub folder")


def pack_deterministic(root, arcroot, out):
    root = Path(root)
    with open(out, "wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode="w") as tar:
                for dp, dn, fn in os.walk(root):
                    dn.sort()
                    for f in sorted(fn):
                        full = Path(dp) / f
                        arc = arcroot + "/" + str(full.relative_to(root)).replace("\\", "/")
                        ti = tar.gettarinfo(str(full), arcname=arc)
                        ti.uid = ti.gid = 0
                        ti.uname = ti.gname = ""
                        ti.mtime = 0
                        ti.mode = 0o644
                        with open(full, "rb") as fh:
                            tar.addfile(ti, fh)


def host_version():
    try:
        t = (APP_DIR / "host.py").read_text(encoding="utf-8")
        m = re.search(r'APP_VERSION\s*=\s*"([^"]+)"', t)
        return m.group(1) if m else ""
    except Exception:
        return ""



def load_admin_cfg():
    cfg = dict(DEFAULT_PUBLISH)
    if ADMIN_CFG.is_file():
        try:
            data = json.loads(ADMIN_CFG.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                cfg.update({k: data[k] for k in DEFAULT_PUBLISH if k in data})
        except Exception:
            pass
    return cfg


def save_admin_cfg(cfg):
    ADMIN_CFG.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")



def load_history():
    if HISTORY.is_file():
        try:
            return json.loads(HISTORY.read_text(encoding="utf-8"))
        except Exception:
            pass
    return []


def save_history(items):
    HISTORY.write_text(json.dumps(items[-50:], indent=2, ensure_ascii=False), encoding="utf-8")


class AdminApi:
    def __init__(self):
        self._drag = None



    def test_github(self):
        try:
            cfg = load_admin_cfg()
            token = (cfg.get("github_token") or "").strip()
            owner = (cfg.get("github_owner") or "").strip()
            repo = (cfg.get("github_repo") or "").strip()
            branch = (cfg.get("github_branch") or "gh-pages").strip()
            if not token:
                return {"ok": False, "error": "Brak tokenu — wklej PAT i zapisz połączenie"}
            if not owner or not repo:
                return {"ok": False, "error": "Ustaw owner i repo"}
            user = self._gh_request("GET", "/user")
            login = user.get("login") or "?"
            repo_info = self._gh_request("GET", "/repos/%s/%s" % (owner, repo))
            perms = (repo_info.get("permissions") or {})
            can_push = bool(perms.get("push") or perms.get("admin"))
            # probe branch
            branch_ok = False
            branch_err = ""
            try:
                self._gh_request("GET", "/repos/%s/%s/branches/%s" % (owner, repo, branch))
                branch_ok = True
            except Exception as be:
                branch_err = str(be)
            return {
                "ok": True,
                "login": login,
                "repo": repo_info.get("full_name") or ("%s/%s" % (owner, repo)),
                "private": bool(repo_info.get("private")),
                "can_push": can_push,
                "branch": branch,
                "branch_ok": branch_ok,
                "branch_error": branch_err,
                "note": (
                    "Token OK, push dozwolony." if can_push and branch_ok
                    else (
                        "Token działa, ale brak push na repo — potrzebujesz Contents: write / scope repo."
                        if not can_push else
                        "Repo OK, branch '%s' nie istnieje — utwórz pusty gh-pages albo zmień branch." % branch
                    )
                ),
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def get_publish_config(self):
        cfg = load_admin_cfg()
        token = cfg.get("github_token") or ""
        masked = (token[:4] + "…" + token[-4:]) if len(token) > 10 else ("" if not token else "••••")
        return {
            "ok": True,
            "github_owner": cfg.get("github_owner", ""),
            "github_repo": cfg.get("github_repo", ""),
            "github_branch": cfg.get("github_branch", "gh-pages"),
            "auto_publish": bool(cfg.get("auto_publish", True)),
            "has_token": bool(token),
            "token_masked": masked,
            "pages": PAGES_HINT,
        }

    def save_publish_config(self, data):
        try:
            data = dict(data or {})
            cfg = load_admin_cfg()
            if "github_token" in data:
                tok = str(data.get("github_token") or "").strip()
                if tok and tok not in ("••••", cfg.get("github_token")):
                    cfg["github_token"] = tok
                elif not tok:
                    cfg["github_token"] = ""
            for k in ("github_owner", "github_repo", "github_branch"):
                if k in data and str(data.get(k) or "").strip():
                    cfg[k] = str(data[k]).strip()
            # branch nie może być nazwą repo
            br = (cfg.get("github_branch") or "").strip()
            repo = (cfg.get("github_repo") or "").strip()
            if not br or br == repo or br in ("main", "master"):
                if br in ("main", "master") or br == repo or not br:
                    cfg["github_branch"] = "gh-pages"
            if "auto_publish" in data:
                cfg["auto_publish"] = bool(data["auto_publish"])
            save_admin_cfg(cfg)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _gh_request(self, method, path, body=None, token=None):
        cfg = load_admin_cfg()
        token = token or cfg.get("github_token") or ""
        if not token:
            raise RuntimeError("Brak GitHub token (Settings → Personal access token z repo)")
        url = "https://api.github.com" + path
        data = None
        headers = {
            "Authorization": "Bearer " + token,
            "Accept": "application/vnd.github+json",
            "User-Agent": "VerCode-Admin",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                raw = resp.read().decode("utf-8")
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            err = e.read().decode("utf-8", errors="replace")
            try:
                j = json.loads(err)
                msg = j.get("message") or err
            except Exception:
                msg = err
            hint = ""
            if e.code == 401:
                hint = " — token nieprawidłowy lub wygasł. Wygeneruj nowy PAT."
            elif e.code == 403:
                hint = (
                    " — token nie ma prawa zapisu. "
                    "Classic PAT: scope 'repo' (pełne). "
                    "Fine-grained: Repository permissions → Contents: Read and write, "
                    "Metadata: Read. Dla org włącz SSO na tokenie."
                )
            elif e.code == 404:
                hint = " — nie znaleziono repo/branch albo token nie widzi repo (sprawdź owner/repo/branch)."
            raise RuntimeError("GitHub %s: %s%s" % (e.code, msg, hint))

    def _gh_put_file(self, owner, repo, branch, path, content_bytes, message):
        api_path = "/repos/%s/%s/contents/%s" % (owner, repo, path.lstrip("/"))
        b64 = base64.b64encode(content_bytes).decode("ascii")
        sha = None
        try:
            existing = self._gh_request("GET", api_path + "?ref=" + branch)
            sha = existing.get("sha")
        except Exception:
            sha = None
        body = {
            "message": message,
            "content": b64,
            "branch": branch,
        }
        if sha:
            body["sha"] = sha
        return self._gh_request("PUT", api_path, body)


    def _gh_tree(self, owner, repo, branch):
        data = self._gh_request("GET", "/repos/%s/%s/git/trees/%s?recursive=1" % (owner, repo, branch))
        return {t["path"]: t for t in data.get("tree", []) if t.get("type") == "blob"}

    def _gh_delete(self, owner, repo, branch, path, sha, message):
        return self._gh_request(
            "DELETE",
            "/repos/%s/%s/contents/%s" % (owner, repo, path.lstrip("/")),
            {"message": message, "sha": sha, "branch": branch},
        )

    def _gh_ctx(self):
        cfg = load_admin_cfg()
        owner = (cfg.get("github_owner") or "").strip()
        repo = (cfg.get("github_repo") or "").strip()
        branch = (cfg.get("github_branch") or "gh-pages").strip()
        if not owner or not repo or not cfg.get("github_token"):
            raise RuntimeError("Ustaw owner, repo i token w zakładce Publikacja")
        return owner, repo, branch

    def ensure_pages_branch(self):
        cfg = load_admin_cfg()
        owner = (cfg.get("github_owner") or "").strip()
        repo = (cfg.get("github_repo") or "").strip()
        branch = (cfg.get("github_branch") or "gh-pages").strip()
        if branch == repo:
            branch = "gh-pages"
            cfg["github_branch"] = branch
            save_admin_cfg(cfg)
        try:
            self._gh_request("GET", "/repos/%s/%s/branches/%s" % (owner, repo, branch))
            return {"ok": True, "branch": branch, "created": False}
        except Exception:
            pass
        # create from default branch SHA
        try:
            repo_info = self._gh_request("GET", "/repos/%s/%s" % (owner, repo))
            default = repo_info.get("default_branch") or "main"
            ref = self._gh_request("GET", "/repos/%s/%s/git/ref/heads/%s" % (owner, repo, default))
            sha = (ref.get("object") or {}).get("sha")
            if not sha:
                return {"ok": False, "error": "Brak SHA default branch"}
            self._gh_request("POST", "/repos/%s/%s/git/refs" % (owner, repo), {
                "ref": "refs/heads/" + branch,
                "sha": sha,
            })
            return {"ok": True, "branch": branch, "created": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def publish_to_github(self, files=None, message=None):
        try:
            cfg = load_admin_cfg()
            owner = (cfg.get("github_owner") or "").strip()
            repo = (cfg.get("github_repo") or "").strip()
            branch = (cfg.get("github_branch") or "gh-pages").strip()
            if not owner or not repo:
                return {"ok": False, "error": "Ustaw owner i repo w Publikacja"}
            if not cfg.get("github_token"):
                return {"ok": False, "error": "Ustaw GitHub token w Publikacja"}
            if branch == repo or not branch:
                branch = "gh-pages"
                cfg["github_branch"] = branch
                save_admin_cfg(cfg)
            ens = self.ensure_pages_branch()
            if not ens.get("ok"):
                return {"ok": False, "error": "Branch Pages: " + str(ens.get("error"))}
            # synchronizacja admin_out → pages (hub)
            PAGES_DIR.mkdir(exist_ok=True)
            (PAGES_DIR / "dist").mkdir(exist_ok=True)
            for name in ("manifest.json", "manifest-beta.json"):
                src = OUT_DIR / name
                if src.is_file():
                    (PAGES_DIR / name).write_bytes(src.read_bytes())
            dist_out = OUT_DIR / "dist"
            if dist_out.is_dir():
                for p in dist_out.glob("*.exe"):
                    if "-" not in p.stem:
                        continue  # nie wysyłamy niewersjonowanego duplikatu
                    dest = PAGES_DIR / "dist" / p.name
                    dest.write_bytes(p.read_bytes())
            for p in OUT_DIR.glob("*.tar.gz"):
                (PAGES_DIR / p.name).write_bytes(p.read_bytes())
            # status.json zawsze świeży
            status = {
                "service": "vercode-bot-manager",
                "ok": True,
                "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "endpoints": {
                    "stable": "manifest.json",
                    "beta": "manifest-beta.json",
                    "status": "status.json",
                    "downloads": "dist/",
                },
                "pages": "https://%s.github.io/%s/" % (owner, repo),
            }
            (PAGES_DIR / "status.json").write_text(json.dumps(status, indent=2), encoding="utf-8")

            to_upload = []
            if files:
                for f in files:
                    p = OUT_DIR / Path(f).name
                    if p.is_file():
                        to_upload.append((p.name, p))
                    p2 = PAGES_DIR / Path(f).name
                    if p2.is_file():
                        to_upload.append((p2.name, p2))
            for p in PAGES_DIR.rglob("*"):
                if not p.is_file() or p.name == "README.md":
                    continue
                rel = str(p.relative_to(PAGES_DIR)).replace(chr(92), "/")
                to_upload.append((rel, p))
            for p in OUT_DIR.glob("host-*.tar.gz"):
                to_upload.append((p.name, p))
                try:
                    (PAGES_DIR / p.name).write_bytes(p.read_bytes())
                except Exception:
                    pass
            dist_out = OUT_DIR / "dist"
            if dist_out.is_dir():
                for p in dist_out.glob("*.exe"):
                    if "-" not in p.stem:
                        continue
                    to_upload.append(("dist/" + p.name, p))
                    try:
                        dest = PAGES_DIR / "dist" / p.name
                        dest.parent.mkdir(exist_ok=True)
                        dest.write_bytes(p.read_bytes())
                    except Exception:
                        pass
            # dedupe by rel
            seen = {}
            for rel, p in to_upload:
                seen[rel] = p
            to_upload = list(seen.items())
            if not to_upload:
                return {"ok": False, "error": "Brak plików do publikacji (pages/ i admin_out)"}
            msg = message or ("VerCode hub %s" % datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M"))
            try:
                remote = self._gh_tree(owner, repo, branch)
            except Exception:
                remote = {}
            uploaded = []
            skipped = []
            for rel, p in to_upload:
                content = p.read_bytes()
                if len(content) > 90 * 1024 * 1024:
                    return {"ok": False, "error": "Plik za duży dla Contents API (>90MB): %s" % rel}
                if remote.get(rel, {}).get("sha") == git_blob_sha(content):
                    skipped.append(rel)
                    continue
                self._gh_put_file(owner, repo, branch, rel, content, msg + " — " + rel)
                uploaded.append(rel)
            deleted = []
            pend = load_pending()
            if pend:
                try:
                    remote = self._gh_tree(owner, repo, branch)
                except Exception:
                    pass
                left = []
                for path in pend:
                    t = remote.get(path)
                    if not t:
                        continue
                    try:
                        self._gh_delete(owner, repo, branch, path, t["sha"], "VerCode: usunięto " + path)
                        deleted.append(path)
                    except Exception:
                        left.append(path)
                save_json(PENDING, left)
            return {
                "ok": True,
                "uploaded": uploaded,
                "skipped": skipped,
                "deleted": deleted,
                "url": "https://%s.github.io/%s/" % (owner, repo),
                "branch": branch,
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def save_and_publish(self, data):
        res = self.save_release(data)
        if not res.get("ok"):
            return res
        cfg = load_admin_cfg()
        if not cfg.get("auto_publish", True):
            res["published"] = False
            res["note"] = "auto_publish wyłączone — tylko zapis lokalny"
            return res
        pub = self.publish_to_github(
            files=None,
            message="Release %s (%s)" % (data.get("version"), data.get("channel") or "stable"),
        )
        res["publish"] = pub
        res["published"] = bool(pub.get("ok"))
        if not pub.get("ok"):
            res["publish_error"] = pub.get("error")
        else:
            res["uploaded"] = pub.get("uploaded") or []
            res["note"] = "Opublikowano: " + ", ".join((pub.get("uploaded") or [])[:8] or ["OK"])
        if not (res.get("package_url") or "").strip():
            res["warning"] = "Manifest bez paczki — klienci nie zainstalują update"
        return res

    def get_meta(self):
        return {
            "stable_url": STABLE_URL,
            "beta_url": BETA_URL,
            "pages": PAGES_HINT,
            "out_dir": str(OUT_DIR),
            "history": load_history(),
            "host_version": host_version(),
        }

    def save_release(self, data):
        try:
            data = dict(data or {})
            channel = (data.get("channel") or "stable").lower()
            if channel not in ("stable", "beta"):
                channel = "stable"
            ver = str(data.get("version") or "").strip()
            if not ver:
                return {"ok": False, "error": "Podaj wersję"}
            cfg = load_admin_cfg()
            exe_url = str(data.get("exe_url") or "").strip()
            sha = ""
            size = 0
            dist_dir = OUT_DIR / "dist"
            exes = sorted(dist_dir.glob("*.exe"), key=lambda x: x.stat().st_mtime, reverse=True) if dist_dir.is_dir() else []
            exact = [x for x in exes if x.stem.endswith("-" + ver)]
            if exact:
                exes = exact
            elif exes and not exe_url and not str(data.get("tar_url") or "").strip():
                pass
            if exes and not exe_url:
                exe_file = exes[0]
                raw = exe_file.read_bytes()
                sha = hashlib.sha256(raw).hexdigest()
                size = len(raw)
                if not exe_url:
                    owner = (cfg.get("github_owner") or "").strip()
                    repo = (cfg.get("github_repo") or "").strip()
                    if owner and repo:
                        exe_url = "https://%s.github.io/%s/dist/%s" % (owner, repo, exe_file.name)
            if not exe_url and str(data.get("download_url") or "").lower().endswith(".exe"):
                exe_url = str(data.get("download_url")).strip()
            tar_url = str(data.get("tar_url") or "").strip()
            download_url = str(data.get("download_url") or "").strip() or exe_url
            if not tar_url:
                try:
                    pack_name = "host-%s.tar.gz" % ver
                    pack_path = OUT_DIR / pack_name
                    with tarfile.open(pack_path, "w:gz") as tar:
                        for rel in ("host.py", "web", "requirements.txt", "run.bat", "run_admin.bat", "README.md", "admin_host.py"):
                            p = APP_DIR / rel
                            if p.exists():
                                tar.add(str(p), arcname=rel)
                        bots = APP_DIR / "bots"
                        if bots.is_dir():
                            tar.add(str(bots), arcname="bots")
                    raw = pack_path.read_bytes()
                    tar_sha = hashlib.sha256(raw).hexdigest()
                    tar_size = len(raw)
                    PAGES_DIR.mkdir(exist_ok=True)
                    (PAGES_DIR / pack_name).write_bytes(raw)
                    owner = cfg.get("github_owner") or "vern0xx"
                    repo = cfg.get("github_repo") or "vercode-bot-manager"
                    tar_url = "https://%s.github.io/%s/%s" % (owner, repo, pack_name)
                    if not download_url:
                        download_url = tar_url
                    if not sha:
                        sha = tar_sha
                        size = tar_size
                except Exception as e:
                    if not exe_url and not download_url:
                        return {"ok": False, "error": "Brak paczki i nie udało się zbudować tar.gz: %s" % e}
            payload = {
                "version": ver,
                "channel": channel,
                "changelog": str(data.get("changelog") or "").strip(),
                "download_url": download_url,
                "exe_url": exe_url,
                "sha256": sha,
                "size": size,
                "tar_url": tar_url,
                "mandatory": bool(data.get("mandatory")),
                "templates": data.get("templates") if isinstance(data.get("templates"), list) else [],
                "min_host": str(data.get("min_host") or "").strip(),
                "published_at": datetime.now(timezone.utc).isoformat(),
                "highlights": [x.strip() for x in str(data.get("highlights") or "").split("\n") if x.strip()][:12],
                "rollout": max(1, min(100, int(data.get("rollout") or 100))),
                "notice": str(data.get("notice") or "").strip(),
            }
            name = "manifest-beta.json" if channel == "beta" else "manifest.json"
            path = OUT_DIR / name
            text = json.dumps(payload, indent=2, ensure_ascii=False)
            path.write_text(text, encoding="utf-8")
            hist = load_history()
            hist.append({
                "version": ver,
                "channel": channel,
                "file": name,
                "at": payload["published_at"],
                "manifest": payload,
            })
            save_history(hist)
            # sync manifest to pages hub immediately
            try:
                (PAGES_DIR / name).write_text(text, encoding="utf-8")
            except Exception:
                pass
            return {
                "ok": True,
                "path": str(path),
                "preview": text,
                "upload_to": PAGES_HINT + name,
                "package_url": payload.get("tar_url") or payload.get("exe_url") or payload.get("download_url") or "",
                "sha256": payload.get("sha256") or "",
                "size": payload.get("size") or 0,
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}


    def list_templates(self):
        root = APP_DIR / "bots"
        out = []
        if not root.is_dir():
            return {"ok": True, "templates": out}
        for p in sorted(root.iterdir()):
            if not p.is_dir() or p.name.startswith("."):
                continue
            files = 0
            try:
                for f in p.rglob("*"):
                    if f.is_file():
                        files += 1
            except Exception:
                pass
            out.append({"id": p.name, "path": str(p), "files": files})
        return {"ok": True, "templates": out}

    def tpl_list_files(self, name):
        name = slugify(str(name or ""))
        root = (APP_DIR / "bots" / name).resolve()
        base = (APP_DIR / "bots").resolve()
        if not str(root).startswith(str(base)) or not root.is_dir():
            return {"ok": False, "error": "Nieprawidłowy szablon"}
        items = []
        for f in sorted(root.rglob("*")):
            if not f.is_file():
                continue
            if any(x in f.parts for x in ("__pycache__", ".git", "venv", ".venv")):
                continue
            rel = str(f.relative_to(root)).replace("\\", "/")
            items.append({"path": rel, "size": f.stat().st_size, "ext": f.suffix.lower()})
        return {"ok": True, "name": name, "files": items}

    def tpl_read(self, name, relpath):
        name = slugify(str(name or ""))
        relpath = str(relpath or "").replace("\\", "/").lstrip("/")
        if ".." in relpath.split("/"):
            return {"ok": False, "error": "Zła ścieżka"}
        root = (APP_DIR / "bots" / name).resolve()
        path = (root / relpath).resolve()
        if not str(path).startswith(str(root)) or not path.is_file():
            return {"ok": False, "error": "Brak pliku"}
        try:
            text = path.read_text(encoding="utf-8")
        except Exception:
            return {"ok": False, "error": "Plik binarny / nie da się odczytać"}
        return {"ok": True, "name": name, "path": relpath, "content": text, "size": path.stat().st_size}

    def tpl_write(self, name, relpath, content):
        name = slugify(str(name or ""))
        relpath = str(relpath or "").replace("\\", "/").lstrip("/")
        if ".." in relpath.split("/") or not relpath:
            return {"ok": False, "error": "Zła ścieżka"}
        root = (APP_DIR / "bots" / name).resolve()
        if not root.is_dir():
            return {"ok": False, "error": "Brak szablonu"}
        path = (root / relpath).resolve()
        if not str(path).startswith(str(root)):
            return {"ok": False, "error": "Zła ścieżka"}
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(str(content if content is not None else ""), encoding="utf-8")
        return {"ok": True, "path": relpath, "size": path.stat().st_size}

    def tpl_create(self, name, relpath):
        name = slugify(str(name or ""))
        relpath = str(relpath or "").replace("\\", "/").lstrip("/")
        if not relpath or ".." in relpath.split("/"):
            return {"ok": False, "error": "Zła ścieżka"}
        root = APP_DIR / "bots" / name
        root.mkdir(parents=True, exist_ok=True)
        path = root / relpath
        if path.exists():
            return {"ok": False, "error": "Plik już istnieje"}
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("", encoding="utf-8")
        return {"ok": True, "path": relpath}

    def tpl_delete(self, name, relpath):
        name = slugify(str(name or ""))
        relpath = str(relpath or "").replace("\\", "/").lstrip("/")
        if ".." in relpath.split("/"):
            return {"ok": False, "error": "Zła ścieżka"}
        root = (APP_DIR / "bots" / name).resolve()
        path = (root / relpath).resolve()
        if not str(path).startswith(str(root)) or not path.is_file():
            return {"ok": False, "error": "Brak pliku"}
        path.unlink()
        return {"ok": True}

    def pack_templates(self, name="sentron"):
        try:
            src = APP_DIR / "bots" / name
            if not src.is_dir():
                src = APP_DIR / "bots" / "sentron"
            if not src.is_dir():
                return {"ok": False, "error": "Brak folderu bots/" + str(name)}
            path = OUT_DIR / ("templates-%s.tar.gz" % src.name)
            with tarfile.open(path, "w:gz") as tar:
                tar.add(src, arcname=src.name)
            h = hashlib.sha256(path.read_bytes()).hexdigest()[:16]
            return {"ok": True, "path": str(path), "sha256_16": h, "size": path.stat().st_size}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def pack_host_bundle(self):
        try:
            path = OUT_DIR / "host-bundle.tar.gz"
            with tarfile.open(path, "w:gz") as tar:
                for rel in ("host.py", "web", "requirements.txt", "run.bat", "README.md"):
                    p = APP_DIR / rel
                    if p.exists():
                        tar.add(p, arcname=rel)
            return {"ok": True, "path": str(path), "size": path.stat().st_size}
        except Exception as e:
            return {"ok": False, "error": str(e)}


    def build_exe(self, name="BotHost"):
        try:
            name = (name or "BotHost").strip() or "BotHost"
            dist = OUT_DIR / "dist"
            work = OUT_DIR / "build_work"
            dist.mkdir(exist_ok=True)
            web_dir = APP_DIR / "web"
            if not web_dir.is_dir():
                return {"ok": False, "error": "Brak folderu web/ obok admin_host.py"}
            # absolutna ścieżka — unikamy błędu admin_out/web ze starego .spec
            sep = ";" if os.name == "nt" else ":"
            add_data = str(web_dir.resolve()) + sep + "web"
            for old_spec in OUT_DIR.glob("*.spec"):
                try:
                    old_spec.unlink()
                except Exception:
                    pass
            cmd = [
                sys.executable, "-m", "PyInstaller",
                "--noconfirm", "--onefile", "--windowed",
                "--name", name,
                "--distpath", str(dist),
                "--workpath", str(work),
                "--specpath", str(OUT_DIR),
                "--add-data", add_data,
                "--hidden-import=webview.platforms.edgechromium",
                "--hidden-import=psutil",
                "--collect-all", "webview",
                str(APP_DIR / "host.py"),
            ]
            icon = web_dir / "static" / "logo.png"
            if icon.is_file():
                cmd[1:1]  # no-op keep list
                # insert after --name pair
                idx = cmd.index("--name")
                cmd.insert(idx + 2, "--icon")
                cmd.insert(idx + 3, str(icon))
            env = os.environ.copy()
            env["PYTHONUTF8"] = "1"
            result = subprocess.run(
                cmd,
                cwd=str(APP_DIR),
                capture_output=True,
                text=True,
                timeout=600,
                env=env,
            )
            exe = dist / (name + (".exe" if os.name == "nt" else ""))
            log_tail = ((result.stdout or "") + "\n" + (result.stderr or ""))[-4000:]
            if result.returncode != 0 or not exe.is_file():
                return {"ok": False, "error": "PyInstaller failed", "log": log_tail, "code": result.returncode}
            size = exe.stat().st_size
            ver = host_version()
            versioned = exe
            if ver:
                versioned = dist / ("%s-%s%s" % (name, ver, exe.suffix))
                shutil.copy2(exe, versioned)
                # zostaw tylko KEEP_EXES najnowszych wersjonowanych plików
                olds = sorted(
                    [x for x in dist.glob("%s-*%s" % (name, exe.suffix))],
                    key=lambda x: ver_tuple(x.stem.split("-", 1)[-1]), reverse=True,
                )
                for old in olds[KEEP_EXES:]:
                    try:
                        old.unlink()
                    except Exception:
                        pass
            return {"ok": True, "path": str(versioned), "size": size, "version": ver, "log": log_tail[-1500:]}
        except FileNotFoundError:
            return {"ok": False, "error": "Zainstaluj pyinstaller: pip install pyinstaller"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def install_build_deps(self):
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-U", "pyinstaller", "pywebview", "psutil"],
                capture_output=True, text=True, timeout=300,
            )
            return {
                "ok": result.returncode == 0,
                "log": ((result.stdout or "") + (result.stderr or ""))[-2000:],
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}


    # ================= BIBLIOTEKA BOTÓW =================
    def pick_bot_source(self, folder=False):
        try:
            w = webview.windows[0]
            if folder:
                r = w.create_file_dialog(webview.FOLDER_DIALOG)
            else:
                r = w.create_file_dialog(
                    webview.OPEN_DIALOG, allow_multiple=False,
                    file_types=("Paczki botów (*.zip;*.tar.gz;*.tgz;*.tar)", "Wszystkie (*.*)"),
                )
            return {"ok": True, "path": (r[0] if r else "")}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def bots_upload_b64(self, filename, b64):
        """Zapis przeciągniętego pliku (drag&drop) do katalogu tymczasowego."""
        try:
            raw = base64.b64decode(b64)
            if len(raw) > MAX_PACK:
                return {"ok": False, "error": "Plik większy niż 60 MB"}
            d = Path(tempfile.mkdtemp(prefix="vc-up-"))
            name = re.sub(r"[^\w.\-]+", "_", Path(filename).name) or "pack.zip"
            (d / name).write_bytes(raw)
            return {"ok": True, "path": str(d / name)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def bots_inspect(self, src_path):
        """Podgląd paczki przed dodaniem: wykryte meta, entry, ostrzeżenia."""
        tmp = None
        try:
            tmp, root, removed, secrets, meta = self._stage_bot(src_path)
            entry = next((e for e in ENTRY_NAMES if (root / e).is_file()), "")
            files = sum(1 for _ in root.rglob("*") if _.is_file())
            reqs = []
            rp = root / "requirements.txt"
            if rp.is_file():
                reqs = [l.strip() for l in rp.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip() and not l.startswith("#")][:30]
            guess = meta.get("name") or Path(src_path).stem.replace(".tar", "")
            return {
                "ok": True, "entry": entry, "files": files, "removed": removed[:40],
                "secrets": secrets, "requirements": reqs, "meta": meta,
                "suggest_id": slugify(guess), "suggest_name": guess,
                "error": "" if entry else "Brak pliku startowego (main.py / bot.py / index.py / app.py)",
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}
        finally:
            if tmp:
                shutil.rmtree(tmp, ignore_errors=True)

    def _stage_bot(self, src_path):
        src = Path(src_path)
        if not src.exists():
            raise ValueError("Nie znaleziono: %s" % src_path)
        tmp = Path(tempfile.mkdtemp(prefix="vc-bot-"))
        stage = tmp / "s"
        if src.is_dir():
            shutil.copytree(src, stage, ignore=shutil.ignore_patterns(*EXCLUDE_DIRS))
        else:
            if src.stat().st_size > MAX_PACK:
                raise ValueError("Plik większy niż 60 MB")
            safe_extract(src, stage)
        root = stage
        items = [i for i in stage.iterdir() if i.name not in EXCLUDE_DIRS]
        if not any((stage / e).is_file() for e in ENTRY_NAMES) and len(items) == 1 and items[0].is_dir():
            root = items[0]
        removed = []
        for dp, dn, fn in os.walk(root):
            for d in list(dn):
                if d in EXCLUDE_DIRS:
                    shutil.rmtree(Path(dp) / d, ignore_errors=True)
                    dn.remove(d)
                    removed.append(str((Path(dp) / d).relative_to(root)) + "/")
            for f in fn:
                low = f.lower()
                if (low.startswith(".env") and low != ".env.example") or low.endswith(EXCLUDE_EXT) or low == ".vercode_pack.json":
                    try:
                        (Path(dp) / f).unlink()
                        removed.append(str((Path(dp) / f).relative_to(root)))
                    except Exception:
                        pass
        secrets = []
        for f in root.rglob("*"):
            if f.is_file() and f.suffix.lower() in SCAN_EXT and f.stat().st_size < 2 * 1024 * 1024:
                try:
                    if SECRET_RE.search(f.read_text(encoding="utf-8", errors="ignore")):
                        secrets.append(str(f.relative_to(root)))
                except Exception:
                    pass
        meta = {}
        for mf in ("vercode.json", "bot.json"):
            if (root / mf).is_file():
                m = load_json(root / mf, {})
                if isinstance(m, dict):
                    meta = m
                break
        return tmp, root, removed, secrets, meta

    def bots_add(self, src_path, data=None, publish=False):
        tmp = None
        try:
            data = dict(data or {})
            tmp, root, removed, secrets, pmeta = self._stage_bot(src_path)
            if secrets and not data.get("allow_secrets"):
                return {"ok": False, "code": "secrets", "secrets": secrets,
                        "error": "W plikach wygląda na token Discorda: %s. Usuń go z kodu (użyj .env) albo potwierdź mimo to." % ", ".join(secrets[:4])}
            entry = next((e for e in ENTRY_NAMES if (root / e).is_file()), "")
            if not entry:
                return {"ok": False, "error": "Brak pliku startowego (main.py / bot.py / index.py / app.py)"}
            name = str(data.get("name") or pmeta.get("name") or Path(src_path).stem).strip()
            bid = slugify(data.get("id") or name)
            if not bid:
                return {"ok": False, "error": "Podaj nazwę bota"}
            ver = str(data.get("version") or pmeta.get("version") or "1.0.0").strip()
            cat = load_catalog()
            old = next((b for b in cat["bots"] if b.get("id") == bid), None)
            if old and not data.get("overwrite") and ver_tuple(ver) <= ver_tuple(old.get("version", "0")):
                nxt = ver_tuple(old.get("version", "0"))
                nxt = nxt + [0] * (3 - len(nxt))
                nxt[2] += 1
                return {"ok": False, "code": "version", "suggest": ".".join(map(str, nxt)),
                        "error": "Bot '%s' ma już wersję %s — podaj wyższą (np. %s)." % (bid, old.get("version"), ".".join(map(str, nxt)))}
            out_dir = BOTS_PAGES / bid
            out_dir.mkdir(parents=True, exist_ok=True)
            fname = "%s-%s.tar.gz" % (bid, ver)
            out = out_dir / fname
            pack_deterministic(root, bid, out)
            raw = out.read_bytes()
            if len(raw) > MAX_PACK:
                out.unlink()
                return {"ok": False, "error": "Paczka po spakowaniu >60 MB"}
            reqs = []
            rp = root / "requirements.txt"
            if rp.is_file():
                reqs = [l.strip() for l in rp.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip() and not l.startswith("#")][:30]
            entry_obj = {
                "id": bid,
                "name": name,
                "version": ver,
                "description": str(data.get("description") or pmeta.get("description") or "").strip(),
                "author": str(data.get("author") or pmeta.get("author") or "").strip(),
                "tags": [t.strip() for t in str(data.get("tags") or "").split(",") if t.strip()][:8],
                "changelog": str(data.get("changelog") or "").strip(),
                "entry": entry,
                "requirements": reqs,
                "url": "bots/%s/%s" % (bid, fname),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "size": len(raw),
                "updated_at": now_iso(),
            }
            stale = []
            for f in out_dir.glob("*.tar.gz"):
                if f.name != fname:
                    stale.append("bots/%s/%s" % (bid, f.name))
                    f.unlink()
            if stale:
                add_pending(stale)
            cat["bots"] = [b for b in cat["bots"] if b.get("id") != bid] + [entry_obj]
            cat["bots"].sort(key=lambda b: b.get("name", "").lower())
            save_catalog(cat)
            res = {"ok": True, "bot": entry_obj, "removed": removed[:40], "replaced": bool(old)}
            if publish:
                res["publish"] = self.publish_to_github()
            return res
        except Exception as e:
            return {"ok": False, "error": str(e)}
        finally:
            if tmp:
                shutil.rmtree(tmp, ignore_errors=True)

    def bots_list(self):
        cat = load_catalog()
        rows = []
        for b in cat["bots"]:
            f = PAGES_DIR / b.get("url", "")
            r = dict(b)
            r["local"] = f.is_file()
            rows.append(r)
        return {"ok": True, "bots": rows, "updated_at": cat.get("updated_at", "")}

    def bots_update_meta(self, bot_id, data):
        try:
            cat = load_catalog()
            b = next((x for x in cat["bots"] if x.get("id") == bot_id), None)
            if not b:
                return {"ok": False, "error": "Brak bota"}
            for k in ("name", "description", "author", "changelog"):
                if k in data:
                    b[k] = str(data[k]).strip()
            if "tags" in data:
                b["tags"] = [t.strip() for t in str(data["tags"]).split(",") if t.strip()][:8]
            b["updated_at"] = now_iso()
            save_catalog(cat)
            return {"ok": True, "bot": b}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def bots_delete(self, bot_id, remote=True):
        try:
            cat = load_catalog()
            b = next((x for x in cat["bots"] if x.get("id") == bot_id), None)
            if not b:
                return {"ok": False, "error": "Brak bota"}
            d = BOTS_PAGES / bot_id
            paths = ["bots/%s/%s" % (bot_id, f.name) for f in d.glob("*")] if d.is_dir() else []
            if b.get("url"):
                paths.append(b["url"])
            shutil.rmtree(d, ignore_errors=True)
            cat["bots"] = [x for x in cat["bots"] if x.get("id") != bot_id]
            save_catalog(cat)
            add_pending(sorted(set(paths)))
            res = {"ok": True, "deleted_local": True}
            if remote:
                try:
                    res["publish"] = self.publish_to_github()
                    res["remote"] = bool(res["publish"].get("ok"))
                except Exception as e:
                    res["remote"] = False
                    res["remote_error"] = str(e)
            return res
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ================= PLIKI / ZDALNE =================
    def _local_roots(self):
        return {"admin_out": OUT_DIR, "pages": PAGES_DIR}

    def fs_list(self):
        rows = []
        for scope, base in self._local_roots().items():
            for p in sorted(base.rglob("*")):
                if p.is_file() and "build_work" not in p.parts and p.name != "admin_config.json":
                    rows.append({"scope": scope, "rel": str(p.relative_to(base)).replace("\\", "/"),
                                 "size": p.stat().st_size, "mtime": int(p.stat().st_mtime)})
        return {"ok": True, "files": rows}

    def fs_delete(self, scope, rel):
        try:
            base = self._local_roots().get(scope)
            if not base:
                return {"ok": False, "error": "Zły zakres"}
            target = (base / rel).resolve()
            if not str(target).startswith(str(base.resolve()) + os.sep) or target.name == "admin_config.json":
                return {"ok": False, "error": "Niedozwolona ścieżka"}
            if not target.is_file():
                return {"ok": False, "error": "Nie ma takiego pliku"}
            target.unlink()
            if scope == "pages":
                add_pending([rel])
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def remote_list(self):
        try:
            owner, repo, branch = self._gh_ctx()
            tree = self._gh_tree(owner, repo, branch)
            keep = self._referenced_remote()
            rows = [{"path": p, "size": t.get("size", 0), "referenced": p in keep} for p, t in sorted(tree.items())]
            return {"ok": True, "files": rows, "branch": branch}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _referenced_remote(self):
        keep = {"manifest.json", "manifest-beta.json", "status.json", "index.html", "bots/catalog.json", ".nojekyll"}
        for b in load_catalog()["bots"]:
            if b.get("url"):
                keep.add(b["url"])
        for h in load_history()[-KEEP_EXES:]:
            m = h.get("manifest") or {}
            u = m.get("exe_url") or ""
            if "/dist/" in u:
                keep.add("dist/" + u.rsplit("/", 1)[-1])
        for name in ("manifest.json", "manifest-beta.json"):
            m = load_json(OUT_DIR / name, {})
            u = (m.get("exe_url") or "") if isinstance(m, dict) else ""
            if "/dist/" in u:
                keep.add("dist/" + u.rsplit("/", 1)[-1])
        return keep

    def remote_delete(self, paths):
        try:
            owner, repo, branch = self._gh_ctx()
            tree = self._gh_tree(owner, repo, branch)
            done, failed = [], []
            for path in paths or []:
                t = tree.get(path)
                if not t:
                    failed.append({"path": path, "error": "nie istnieje"})
                    continue
                try:
                    self._gh_delete(owner, repo, branch, path, t["sha"], "VerCode: usunięto " + path)
                    done.append(path)
                except Exception as e:
                    failed.append({"path": path, "error": str(e)})
            return {"ok": True, "deleted": done, "failed": failed}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def remote_purge_orphans(self):
        """Usuwa z Pages pliki dist/ i bots/, do których nic nie prowadzi."""
        r = self.remote_list()
        if not r.get("ok"):
            return r
        orphans = [f["path"] for f in r["files"]
                   if not f["referenced"] and (f["path"].startswith("dist/") or f["path"].startswith("bots/"))]
        if not orphans:
            return {"ok": True, "deleted": [], "failed": []}
        return self.remote_delete(orphans)

    # ================= HISTORIA: ROLLBACK / USUWANIE =================
    def history_delete(self, idx):
        try:
            h = load_history()
            if not (0 <= int(idx) < len(h)):
                return {"ok": False, "error": "Zły indeks"}
            h.pop(int(idx))
            save_history(h)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def rollback_release(self, idx, publish=True):
        """Wydaje starszą paczkę jako NOWĄ wyższą wersją (klienci nie robią downgrade)."""
        try:
            h = load_history()
            entry = h[int(idx)]
            m = dict(entry.get("manifest") or {})
            if not m.get("exe_url") and not m.get("tar_url") and not m.get("download_url"):
                return {"ok": False, "error": "Ten wpis nie ma paczki do przywrócenia"}
            channel = m.get("channel", "stable")
            name = "manifest-beta.json" if channel == "beta" else "manifest.json"
            cur = load_json(OUT_DIR / name, {})
            base = ver_tuple(max([cur.get("version", "0"), m.get("version", "0")], key=ver_tuple))
            base += [0] * (3 - len(base))
            base[2] += 1
            newv = ".".join(map(str, base))
            old_v = m.get("version")
            m["version"] = newv
            m["changelog"] = "Rollback do paczki z wersji %s.\n%s" % (old_v, m.get("changelog", ""))
            m["published_at"] = now_iso()
            m["mandatory"] = True
            m["rollout"] = 100
            save_json(OUT_DIR / name, m)
            h.append({"version": newv, "channel": channel, "file": name, "at": m["published_at"], "manifest": m,
                      "note": "rollback z %s" % old_v})
            save_history(h)
            res = {"ok": True, "version": newv, "from": old_v}
            if publish:
                res["publish"] = self.publish_to_github()
            return res
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def verify_published(self):
        """Pobiera manifest(y) z Pages i sprawdza, czy paczka istnieje i SHA się zgadza."""
        out = []
        for label, url in (("stable", STABLE_URL), ("beta", BETA_URL)):
            row = {"channel": label, "ok": False}
            try:
                req = urllib.request.Request(url + "?t=" + str(int(time.time())), headers={"User-Agent": "VerCode-Admin"})
                with urllib.request.urlopen(req, timeout=15) as r:
                    m = json.loads(r.read().decode("utf-8"))
                row["version"] = m.get("version")
                pk = m.get("exe_url") or m.get("download_url") or m.get("tar_url")
                if not pk:
                    row["error"] = "manifest bez adresu paczki"
                else:
                    req = urllib.request.Request(pk, headers={"User-Agent": "VerCode-Admin"})
                    h = hashlib.sha256()
                    n = 0
                    with urllib.request.urlopen(req, timeout=120) as r2:
                        while True:
                            c = r2.read(512 * 1024)
                            if not c:
                                break
                            h.update(c)
                            n += len(c)
                    row["size"] = n
                    want = (m.get("sha256") or "").lower()
                    row["sha_ok"] = (not want) or h.hexdigest() == want
                    row["ok"] = row["sha_ok"]
                    if not row["sha_ok"]:
                        row["error"] = "SHA-256 pliku na Pages różni się od manifestu (cache CDN?)"
            except Exception as e:
                row["error"] = str(e)
            out.append(row)
        return {"ok": True, "results": out}

    def list_out(self):
        files = []
        for p in sorted(OUT_DIR.iterdir()):
            if p.is_file():
                files.append({"name": p.name, "size": p.stat().st_size})
        return {"files": files, "dir": str(OUT_DIR)}

    def open_out(self):
        try:
            if os.name == "nt":
                os.startfile(str(OUT_DIR))
            elif sys.platform == "darwin":
                os.system('open "%s"' % OUT_DIR)
            else:
                os.system('xdg-open "%s"' % OUT_DIR)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def window_close(self):
        try:
            webview.windows[0].destroy()
        except Exception:
            pass

    def window_minimize(self):
        try:
            webview.windows[0].minimize()
        except Exception:
            pass

    def window_drag_start(self):
        try:
            w = webview.windows[0]
            self._drag = (int(w.x), int(w.y))
        except Exception:
            self._drag = (0, 0)
        return {"ok": True}

    def window_drag_to(self, dx, dy):
        if not self._drag:
            return {"ok": False}
        try:
            webview.windows[0].move(self._drag[0] + int(dx), self._drag[1] + int(dy))
            return {"ok": True}
        except Exception:
            return {"ok": False}


def main():
    api = AdminApi()
    html = APP_DIR / "web" / "admin.html"
    webview.create_window(
        "VerCode Admin",
        str(html),
        js_api=api,
        width=1180,
        height=760,
        min_size=(960, 640),
        frameless=True,
        easy_drag=False,
        background_color="#010102",
    )
    webview.start(debug=False)


if __name__ == "__main__":
    main()
