"""
Sentron – Discord Components V2 interactive panels
"""
import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone

# ---------- Views (Components V2 style) ----------

class HelpView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=120)
        self.bot = bot

    @discord.ui.button(label="Anti-Raid", style=discord.ButtonStyle.primary, emoji="🛡️", row=0)
    async def antiraid_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="🛡️ Anti-Raid Commands",
            description=(
                "`/antiraid` — Configure protection\n"
                "`/antiraid_status` — View current settings\n"
                "`/set_raid_log` — Set log channel\n\n"
                "Detects mass joins and automatically kicks/bans."
            ),
            color=0x9b59ff
        )
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Moderation", style=discord.ButtonStyle.primary, emoji="🔨", row=0)
    async def mod_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="🔨 Moderation Commands",
            description=(
                "`/ban` `/kick` `/timeout` `/unban`\n"
                "`/purge` `/warn`\n\n"
                "Full moderation suite with role hierarchy checks."
            ),
            color=0x9b59ff
        )
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Utility", style=discord.ButtonStyle.secondary, emoji="📊", row=0)
    async def util_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="📊 Utility Commands",
            description=(
                "`/serverinfo` `/userinfo` `/avatar`\n"
                "`/ping` `/uptime` `/help`\n\n"
                "Useful information commands."
            ),
            color=0x9b59ff
        )
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Dashboard", style=discord.ButtonStyle.success, emoji="🌐", row=1)
    async def dash_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="🌐 Web Dashboard",
            description=(
                "Login with Discord on the web panel to:\n"
                "• Manage all your servers\n"
                "• Configure anti-raid visually\n"
                "• View stats & admin tools\n\n"
                "Beautiful liquid-glass UI • Dark + Purple theme"
            ),
            color=0x9b59ff
        )
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Close", style=discord.ButtonStyle.danger, emoji="✖️", row=1)
    async def close_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.message.delete()


class AntiRaidPanel(discord.ui.View):
    def __init__(self, bot, guild_id: int):
        super().__init__(timeout=180)
        self.bot = bot
        self.guild_id = guild_id

    def _get_settings(self):
        return self.bot.raid_settings.get(self.guild_id, {
            "enabled": True,
            "join_threshold": 5,
            "time_window": 10,
            "action": "kick",
            "log_channel": None
        })

    async def _update_embed(self, interaction: discord.Interaction):
        s = self._get_settings()
        status = "🟢 Enabled" if s["enabled"] else "🔴 Disabled"
        embed = discord.Embed(
            title="🛡️ Anti-Raid Control Panel",
            color=0x9b59ff,
            timestamp=datetime.now(timezone.utc)
        )
        embed.add_field(name="Status", value=status, inline=True)
        embed.add_field(name="Action", value=s["action"].upper(), inline=True)
        embed.add_field(name="Threshold", value=f"{s['join_threshold']} joins", inline=True)
        embed.add_field(name="Window", value=f"{s['time_window']}s", inline=True)
        embed.set_footer(text="Use the buttons below • Changes apply instantly")
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Toggle", style=discord.ButtonStyle.primary, row=0)
    async def toggle(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Administrator required.", ephemeral=True)
        s = self._get_settings()
        s["enabled"] = not s.get("enabled", True)
        self.bot.raid_settings[self.guild_id] = s
        await self._update_embed(interaction)

    @discord.ui.select(
        placeholder="Select action on raid...",
        options=[
            discord.SelectOption(label="Kick", value="kick", description="Kick raiders"),
            discord.SelectOption(label="Ban", value="ban", description="Ban raiders"),
            discord.SelectOption(label="Quarantine", value="quarantine", description="Assign quarantine role"),
        ],
        row=1
    )
    async def action_select(self, interaction: discord.Interaction, select: discord.ui.Select):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Administrator required.", ephemeral=True)
        s = self._get_settings()
        s["action"] = select.values[0]
        self.bot.raid_settings[self.guild_id] = s
        await self._update_embed(interaction)

    @discord.ui.button(label="Threshold +1", style=discord.ButtonStyle.secondary, row=2)
    async def thresh_up(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Administrator required.", ephemeral=True)
        s = self._get_settings()
        s["join_threshold"] = min(50, s.get("join_threshold", 5) + 1)
        self.bot.raid_settings[self.guild_id] = s
        await self._update_embed(interaction)

    @discord.ui.button(label="Threshold -1", style=discord.ButtonStyle.secondary, row=2)
    async def thresh_down(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Administrator required.", ephemeral=True)
        s = self._get_settings()
        s["join_threshold"] = max(2, s.get("join_threshold", 5) - 1)
        self.bot.raid_settings[self.guild_id] = s
        await self._update_embed(interaction)


class ComponentsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="panel", description="Open interactive Anti-Raid control panel (Components V2)")
    @app_commands.checks.has_permissions(administrator=True)
    async def panel(self, interaction: discord.Interaction):
        s = self.bot.raid_settings.get(interaction.guild.id, {
            "enabled": True,
            "join_threshold": 5,
            "time_window": 10,
            "action": "kick",
            "log_channel": None
        })
        status = "🟢 Enabled" if s["enabled"] else "🔴 Disabled"
        embed = discord.Embed(
            title="🛡️ Anti-Raid Control Panel",
            color=0x9b59ff,
            timestamp=datetime.now(timezone.utc)
        )
        embed.add_field(name="Status", value=status, inline=True)
        embed.add_field(name="Action", value=s["action"].upper(), inline=True)
        embed.add_field(name="Threshold", value=f"{s['join_threshold']} joins", inline=True)
        embed.add_field(name="Window", value=f"{s['time_window']}s", inline=True)
        embed.set_footer(text="Sentron Components V2 • Interactive panel")
        view = AntiRaidPanel(self.bot, interaction.guild.id)
        await interaction.response.send_message(embed=embed, view=view)

    @app_commands.command(name="menu", description="Interactive help menu with buttons")
    async def menu(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="✨ Sentron Interactive Menu",
            description="Click the buttons below to explore commands.",
            color=0x9b59ff
        )
        embed.set_footer(text="Sentron • Components V2")
        view = HelpView(self.bot)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(ComponentsCog(bot))
