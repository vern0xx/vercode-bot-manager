import discord
from discord.ext import commands
from discord import app_commands
import random


BANNER_URL = "https://i.imgur.com/KgHRHNo.png"


def create_sentron_view(content: str) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    container = discord.ui.Container(
        discord.ui.TextDisplay("```                      ꜱᴇɴᴛʀᴏɴ × ᴠᴇʀɪꜰɪᴄᴀᴛɪᴏɴ```"),
        discord.ui.TextDisplay(content),
        discord.ui.Separator(),
        discord.ui.MediaGallery(
            discord.MediaGalleryItem(media=BANNER_URL)
        ),
        discord.ui.Separator(),
        discord.ui.TextDisplay("-# ꜱᴇɴᴛʀᴏɴ × ᴠᴇʀɪꜰɪᴄᴀᴛɪᴏɴ"),
        accent_colour=discord.Colour(0x9b59ff),
    )
    view.add_item(container)
    return view


class MathModal(discord.ui.Modal, title="ꜱᴇɴᴛʀᴏɴ × ᴠᴇʀɪꜰɪᴄᴀᴛɪᴏɴ"):
    def __init__(self, role_id: int, answer: int):
        super().__init__()
        self.role_id = role_id
        self.answer = answer

        self.answer_input = discord.ui.TextInput(
            label="Solve the math problem",
            placeholder="Type your answer here...",
            required=True,
            max_length=10,
            style=discord.TextStyle.short
        )
        self.add_item(self.answer_input)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            user_answer = int(self.answer_input.value.strip())
        except ValueError:
            return await interaction.response.send_message(
                view=create_sentron_view("Invalid answer. Please enter a number."),
                ephemeral=True
            )

        if user_answer != self.answer:
            return await interaction.response.send_message(
                view=create_sentron_view("Wrong answer. Please try again."),
                ephemeral=True
            )

        role = interaction.guild.get_role(self.role_id)
        if not role:
            return await interaction.response.send_message(
                view=create_sentron_view("Verification role not found."),
                ephemeral=True
            )

        if role in interaction.user.roles:
            return await interaction.response.send_message(
                view=create_sentron_view("You are already verified!"),
                ephemeral=True
            )

        try:
            await interaction.user.add_roles(role, reason="[Sentron] Math Verification")
            await interaction.response.send_message(
                view=create_sentron_view("You have been successfully verified!"),
                ephemeral=True
            )
        except discord.Forbidden:
            await interaction.response.send_message(
                view=create_sentron_view("I cannot assign that role. Check my permissions."),
                ephemeral=True
            )


class VerifyLayout(discord.ui.LayoutView):
    def __init__(self, role_id: int, message: str):
        super().__init__(timeout=None)
        self.role_id = role_id

        self.action_row = discord.ui.ActionRow()

        button = discord.ui.Button(
            label="ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤᴠᴇʀɪꜰʏ ʏᴏᴜʀ ᴀᴄᴄᴏᴜɴᴛㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ",
            style=discord.ButtonStyle.gray,
            custom_id="sentron_verify_btn"
        )
        button.callback = self.verify_callback
        self.action_row.add_item(button)

        container = discord.ui.Container(
            discord.ui.TextDisplay("```                      ꜱᴇɴᴛʀᴏɴ × ᴠᴇʀɪꜰɪᴄᴀᴛɪᴏɴ```"),
            discord.ui.TextDisplay(message),
            discord.ui.Separator(),
            self.action_row,
            discord.ui.Separator(),
            discord.ui.MediaGallery(
                discord.MediaGalleryItem(media=BANNER_URL)
            ),
            discord.ui.Separator(),
            discord.ui.TextDisplay("-# ꜱᴇɴᴛʀᴏɴ × ᴠᴇʀɪꜰɪᴄᴀᴛɪᴏɴ"),
            accent_colour=discord.Colour(0x9b59ff),
        )
        self.add_item(container)

    async def verify_callback(self, interaction: discord.Interaction):
        role = interaction.guild.get_role(self.role_id)

        if not role:
            return await interaction.response.send_message(
                view=create_sentron_view("Verification role not found."),
                ephemeral=True
            )

        if role in interaction.user.roles:
            return await interaction.response.send_message(
                view=create_sentron_view("You are already verified!"),
                ephemeral=True
            )

        a = random.randint(1, 20)
        b = random.randint(1, 20)
        answer = a + b

        modal = MathModal(self.role_id, answer)
        modal.title = f"What is {a} + {b}?"
        await interaction.response.send_modal(modal)


class Verification(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.settings = {}

    def get_settings(self, guild_id: int):
        return self.settings.get(guild_id, {
            "enabled": False,
            "channel_id": None,
            "role_id": None,
            "type": "button",
            "message": "Welcome to Sentron! To verify your account and get server access, please click the button below and solve the simple math problem to confirm you're human. It takes just a few seconds.",
        })

    @app_commands.command(name="setup_verify", description="Post verification panel in a channel")
    @app_commands.describe(channel="Channel for verification", role="Role to give on verify")
    @app_commands.checks.has_permissions(administrator=True)
    async def setup_verify(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
        role: discord.Role
    ):
        gid = interaction.guild.id
        s = self.get_settings(gid)
        s["enabled"] = True
        s["channel_id"] = channel.id
        s["role_id"] = role.id
        self.settings[gid] = s

        view = VerifyLayout(role.id, s["message"])
        await channel.send(view=view)

        await interaction.response.send_message(
            view=create_sentron_view(f"Verification panel posted in {channel.mention}"),
            ephemeral=True
        )

    @app_commands.command(name="verify_config", description="Configure verification settings")
    @app_commands.checks.has_permissions(administrator=True)
    async def verify_config(self, interaction: discord.Interaction, enabled: bool = None):
        gid = interaction.guild.id
        s = self.get_settings(gid)

        if enabled is not None:
            s["enabled"] = enabled
            self.settings[gid] = s

        enabled_text = "Yes" if s["enabled"] else "No"
        channel_text = f"<#{s['channel_id']}>" if s.get("channel_id") else "—"
        role_text = f"<@&{s['role_id']}>" if s.get("role_id") else "—"

        content = f"**Enabled:** {enabled_text}\n**Channel:** {channel_text}\n**Role:** {role_text}"

        await interaction.response.send_message(
            view=create_sentron_view(content),
            ephemeral=True
        )


async def setup(bot):
    await bot.add_cog(Verification(bot))