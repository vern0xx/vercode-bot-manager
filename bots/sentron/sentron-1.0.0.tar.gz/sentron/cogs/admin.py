import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone
import os

OWNER_IDS = [int(x) for x in os.getenv("OWNER_IDS", "").split(",") if x.strip()]

class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def is_owner(self, user_id: int) -> bool:
        return user_id in OWNER_IDS or (self.bot.owner_id and user_id == self.bot.owner_id)

    @app_commands.command(name="guilds", description="[Owner] List all guilds the bot is in")
    async def guilds(self, interaction: discord.Interaction):
        if not self.is_owner(interaction.user.id):
            return await interaction.response.send_message("❌ Owner only.", ephemeral=True)
        guilds = sorted(self.bot.guilds, key=lambda g: g.member_count or 0, reverse=True)[:20]
        desc = "\n".join([f"**{g.name}** (`{g.id}`) — {g.member_count} members" for g in guilds])
        embed = discord.Embed(title=f"🌐 Guilds ({len(self.bot.guilds)})", description=desc or "None", color=0x9b59ff)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="leave", description="[Owner] Leave a guild by ID")
    @app_commands.describe(guild_id="Guild ID to leave")
    async def leave(self, interaction: discord.Interaction, guild_id: str):
        if not self.is_owner(interaction.user.id):
            return await interaction.response.send_message("❌ Owner only.", ephemeral=True)
        guild = self.bot.get_guild(int(guild_id))
        if not guild:
            return await interaction.response.send_message("❌ Guild not found.", ephemeral=True)
        await guild.leave()
        await interaction.response.send_message(f"✅ Left **{guild.name}**", ephemeral=True)

    @app_commands.command(name="reload", description="[Owner] Reload a cog")
    @app_commands.describe(cog="Cog name (moderation, antiraid, utility, admin)")
    async def reload(self, interaction: discord.Interaction, cog: str):
        if not self.is_owner(interaction.user.id):
            return await interaction.response.send_message("❌ Owner only.", ephemeral=True)
        try:
            await self.bot.reload_extension(f"cogs.{cog}")
            await interaction.response.send_message(f"✅ Reloaded `{cog}`", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {e}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Admin(bot))
