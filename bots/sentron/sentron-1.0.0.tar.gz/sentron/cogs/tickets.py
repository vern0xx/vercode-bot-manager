import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone
import asyncio
import io
import html


BANNER_URL = "https://i.imgur.com/KgHRHNo.png"


def create_sentron_view(content: str) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    container = discord.ui.Container(
        discord.ui.TextDisplay("```                      SENTRON x TICKETS```"),
        discord.ui.TextDisplay(content),
        discord.ui.Separator(),
        discord.ui.MediaGallery(
            discord.MediaGalleryItem(media=BANNER_URL)
        ),
        discord.ui.Separator(),
        discord.ui.TextDisplay("-# SENTRON x TICKETS"),
        accent_colour=discord.Colour(0x9b59ff),
    )
    view.add_item(container)
    return view


def generate_html_transcript(channel: discord.TextChannel, messages: list[discord.Message], closer: discord.Member, category: str) -> str:
    rows = []
    for msg in messages:
        author = html.escape(str(msg.author))
        content = html.escape(msg.content or "")
        timestamp = msg.created_at.strftime("%Y-%m-%d %H:%M:%S UTC")
        attachments = ""
        if msg.attachments:
            links = [f'<a href="{a.url}" target="_blank">{html.escape(a.filename)}</a>' for a in msg.attachments]
            attachments = "<br>Attachments: " + ", ".join(links)
        rows.append(f"""
        <div class="message">
            <div class="meta">
                <span class="author">{author}</span>
                <span class="time">{timestamp}</span>
            </div>
            <div class="content">{content}{attachments}</div>
        </div>
        """)

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Ticket Transcript - {html.escape(channel.name)}</title>
<style>
    body {{
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #1e1e2e;
        color: #cdd6f4;
        margin: 0;
        padding: 20px;
    }}
    .header {{
        background: #313244;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        border-left: 4px solid #9b59ff;
    }}
    .header h1 {{
        margin: 0 0 10px 0;
        color: #cba6f7;
    }}
    .header p {{
        margin: 4px 0;
        color: #a6adc8;
    }}
    .message {{
        background: #313244;
        padding: 12px 16px;
        margin-bottom: 10px;
        border-radius: 6px;
    }}
    .meta {{
        display: flex;
        justify-content: space-between;
        margin-bottom: 6px;
        font-size: 0.9em;
    }}
    .author {{
        font-weight: 600;
        color: #cba6f7;
    }}
    .time {{
        color: #6c7086;
    }}
    .content {{
        white-space: pre-wrap;
        word-break: break-word;
    }}
    a {{
        color: #89b4fa;
    }}
</style>
</head>
<body>
    <div class="header">
        <h1>Ticket Transcript</h1>
        <p><strong>Channel:</strong> {html.escape(channel.name)}</p>
        <p><strong>Category:</strong> {html.escape(category)}</p>
        <p><strong>Closed by:</strong> {html.escape(str(closer))}</p>
        <p><strong>Closed at:</strong> {datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")}</p>
        <p><strong>Messages:</strong> {len(messages)}</p>
    </div>
    {''.join(rows)}
</body>
</html>"""
    return html_content


class CloseTicketView(discord.ui.LayoutView):
    def __init__(self, bot, opener_id: int = None, category: str = None, log_channel_id: int = None):
        super().__init__(timeout=None)
        self.bot = bot
        self.opener_id = opener_id
        self.category = category or "Unknown"
        self.log_channel_id = log_channel_id

        self.action_row = discord.ui.ActionRow()
        button = discord.ui.Button(
            label="Close Ticket",
            style=discord.ButtonStyle.danger,
            custom_id="sentron_ticket_close"
        )
        button.callback = self.close_callback
        self.action_row.add_item(button)

        container = discord.ui.Container(
            discord.ui.TextDisplay("```                      SENTRON x TICKETS```"),
            discord.ui.TextDisplay("Staff will assist you shortly.\nClick the button below when the issue is resolved."),
            discord.ui.Separator(),
            self.action_row,
            discord.ui.Separator(),
            discord.ui.MediaGallery(
                discord.MediaGalleryItem(media=BANNER_URL)
            ),
            discord.ui.Separator(),
            discord.ui.TextDisplay("-# SENTRON x TICKETS"),
            accent_colour=discord.Colour(0x9b59ff),
        )
        self.add_item(container)

    async def close_callback(self, interaction: discord.Interaction):
        if not (
            interaction.user.guild_permissions.manage_channels
            or interaction.channel.name.startswith("ticket-")
        ):
            return await interaction.response.send_message(
                view=create_sentron_view("You don't have permission to close this ticket."),
                ephemeral=True
            )

        await interaction.response.send_message(
            view=create_sentron_view("Closing ticket and generating transcript..."),
            ephemeral=False
        )

        # Collect messages
        messages = []
        async for msg in interaction.channel.history(limit=500, oldest_first=True):
            messages.append(msg)

        # Generate HTML
        html_content = generate_html_transcript(
            interaction.channel,
            messages,
            interaction.user,
            self.category
        )

        # Send log if configured
        if self.log_channel_id:
            log_channel = interaction.guild.get_channel(self.log_channel_id)
            if log_channel:
                file = discord.File(
                    io.BytesIO(html_content.encode("utf-8")),
                    filename=f"transcript-{interaction.channel.name}.html"
                )

                log_view = create_sentron_view(
                    f"**Ticket closed**\n"
                    f"**Channel:** `{interaction.channel.name}`\n"
                    f"**Category:** {self.category}\n"
                    f"**Opened by:** <@{self.opener_id}>\n"
                    f"**Closed by:** {interaction.user.mention}\n"
                    f"**Messages:** {len(messages)}"
                )
                await log_channel.send(view=log_view, file=file)

        await asyncio.sleep(2)
        try:
            await interaction.channel.delete(reason=f"[Sentron] Closed by {interaction.user}")
        except Exception:
            pass


class TicketSelect(discord.ui.Select):
    def __init__(self, bot, support_role_id: int = None, log_channel_id: int = None):
        self.bot = bot
        self.support_role_id = support_role_id
        self.log_channel_id = log_channel_id

        options = [
            discord.SelectOption(
                label="General Support",
                description="General questions and help",
                value="support"
            ),
            discord.SelectOption(
                label="Report User",
                description="Report a user or rule break",
                value="report"
            ),
            discord.SelectOption(
                label="Partnership",
                description="Partnership and collaboration requests",
                value="partnership"
            ),
            discord.SelectOption(
                label="Other",
                description="Anything else",
                value="other"
            ),
        ]

        super().__init__(
            placeholder="Select a ticket category...",
            min_values=1,
            max_values=1,
            options=options,
            custom_id="sentron_ticket_select"
        )

    async def callback(self, interaction: discord.Interaction):
        category = self.values[0]
        guild = interaction.guild

        existing = discord.utils.get(
            guild.text_channels,
            name=f"ticket-{interaction.user.name.lower()[:20]}"
        )
        if existing:
            return await interaction.response.send_message(
                view=create_sentron_view(f"You already have an open ticket: {existing.mention}"),
                ephemeral=True
            )

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, attach_files=True, embed_links=True
            ),
            guild.me: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, manage_channels=True
            ),
        }

        if self.support_role_id:
            role = guild.get_role(self.support_role_id)
            if role:
                overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True)

        category_names = {
            "support": "Support",
            "report": "Report",
            "partnership": "Partnership",
            "other": "Other"
        }
        category_display = category_names.get(category, category)

        try:
            channel = await guild.create_text_channel(
                name=f"ticket-{interaction.user.name.lower()[:20]}",
                overwrites=overwrites,
                topic=f"Category: {category_display} | User: {interaction.user.id}",
                reason=f"[Sentron] Ticket by {interaction.user} ({category})"
            )
        except discord.Forbidden:
            return await interaction.response.send_message(
                view=create_sentron_view("I don't have permission to create channels."),
                ephemeral=True
            )

        close_view = CloseTicketView(
            bot=self.bot,
            opener_id=interaction.user.id,
            category=category_display,
            log_channel_id=self.log_channel_id
        )
        await channel.send(view=close_view)

        await interaction.response.send_message(
            view=create_sentron_view(f"Ticket created successfully: {channel.mention}"),
            ephemeral=True
        )


class TicketPanel(discord.ui.LayoutView):
    def __init__(self, bot, support_role_id: int = None, log_channel_id: int = None, message: str = None):
        super().__init__(timeout=None)

        if message is None:
            message = "Need help? Select a category below to open a private ticket with our staff."

        self.action_row = discord.ui.ActionRow()
        select = TicketSelect(bot, support_role_id, log_channel_id)
        self.action_row.add_item(select)

        container = discord.ui.Container(
            discord.ui.TextDisplay("```                      SENTRON x TICKETS```"),
            discord.ui.TextDisplay(message),
            discord.ui.Separator(),
            self.action_row,
            discord.ui.Separator(),
            discord.ui.MediaGallery(
                discord.MediaGalleryItem(media=BANNER_URL)
            ),
            discord.ui.Separator(),
            discord.ui.TextDisplay("-# SENTRON x TICKETS"),
            accent_colour=discord.Colour(0x9b59ff),
        )
        self.add_item(container)


class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.settings = {}

    def get_settings(self, guild_id: int):
        return self.settings.get(guild_id, {
            "enabled": False,
            "support_role": None,
            "log_channel": None,
        })

    @app_commands.command(name="setup_tickets", description="Post ticket panel")
    @app_commands.describe(
        channel="Channel for the panel",
        support_role="Support staff role",
        log_channel="Channel where closed ticket logs will be sent"
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def setup_tickets(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel,
        support_role: discord.Role = None,
        log_channel: discord.TextChannel = None
    ):
        gid = interaction.guild.id
        s = self.get_settings(gid)
        s["enabled"] = True
        if support_role:
            s["support_role"] = support_role.id
        if log_channel:
            s["log_channel"] = log_channel.id
        self.settings[gid] = s

        view = TicketPanel(
            self.bot,
            support_role_id=s.get("support_role"),
            log_channel_id=s.get("log_channel")
        )
        await channel.send(view=view)

        await interaction.response.send_message(
            view=create_sentron_view(f"Ticket panel posted in {channel.mention}"),
            ephemeral=True
        )

    @app_commands.command(name="ticket_config", description="View ticket settings")
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_config(self, interaction: discord.Interaction):
        s = self.get_settings(interaction.guild.id)

        enabled_text = "Yes" if s["enabled"] else "No"
        role_text = f"<@&{s['support_role']}>" if s.get("support_role") else "—"
        log_text = f"<#{s['log_channel']}>" if s.get("log_channel") else "—"

        content = (
            f"**Enabled:** {enabled_text}\n"
            f"**Support Role:** {role_text}\n"
            f"**Log Channel:** {log_text}"
        )

        await interaction.response.send_message(
            view=create_sentron_view(content),
            ephemeral=True
        )


async def setup(bot):
    await bot.add_cog(Tickets(bot))