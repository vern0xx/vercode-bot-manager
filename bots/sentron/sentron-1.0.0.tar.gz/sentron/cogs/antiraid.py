import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone
from typing import Optional

class AntiRaid(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="antiraid", description="Configure anti-raid protection")
    @app_commands.describe(
        action="Action to take on raid detection",
        threshold="Number of joins to trigger (default 5)",
        window="Time window in seconds (default 10)",
        enabled="Enable or disable anti-raid"
    )
    @app_commands.choices(action=[
        app_commands.Choice(name="Kick", value="kick"),
        app_commands.Choice(name="Ban", value="ban"),
        app_commands.Choice(name="Quarantine (role)", value="quarantine"),
    ])
    @app_commands.checks.has_permissions(administrator=True)
    async def antiraid(self, interaction: discord.Interaction,
                       action: Optional[app_commands.Choice[str]] = None,
                       threshold: Optional[app_commands.Range[int, 2, 50]] = None,
                       window: Optional[app_commands.Range[int, 5, 120]] = None,
                       enabled: Optional[bool] = None):
        guild_id = interaction.guild.id
        settings = self.bot.raid_settings.get(guild_id, {
            "enabled": True,
            "join_threshold": 5,
            "time_window": 10,
            "action": "kick",
            "log_channel": None
        })

        if action is not None:
            settings["action"] = action.value
        if threshold is not None:
            settings["join_threshold"] = threshold
        if window is not None:
            settings["time_window"] = window
        if enabled is not None:
            settings["enabled"] = enabled

        self.bot.raid_settings[guild_id] = settings

        status = "🟢 Enabled" if settings["enabled"] else "🔴 Disabled"
        embed = discord.Embed(
            title="🛡️ Anti-Raid Configuration",
            color=0x9b59ff,
            timestamp=datetime.now(timezone.utc)
        )
        embed.add_field(name="Status", value=status, inline=True)
        embed.add_field(name="Action", value=settings["action"].upper(), inline=True)
        embed.add_field(name="Threshold", value=f"{settings['join_threshold']} joins", inline=True)
        embed.add_field(name="Time Window", value=f"{settings['time_window']} seconds", inline=True)
        embed.set_footer(text="Sentron Anti-Raid • Changes applied instantly")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="antiraid_status", description="View current anti-raid settings")
    async def antiraid_status(self, interaction: discord.Interaction):
        guild_id = interaction.guild.id
        settings = self.bot.raid_settings.get(guild_id, {
            "enabled": True,
            "join_threshold": 5,
            "time_window": 10,
            "action": "kick",
            "log_channel": None
        })
        status = "🟢 Enabled" if settings["enabled"] else "🔴 Disabled"
        embed = discord.Embed(title="🛡️ Anti-Raid Status", color=0x9b59ff)
        embed.add_field(name="Status", value=status, inline=True)
        embed.add_field(name="Action", value=settings["action"].upper(), inline=True)
        embed.add_field(name="Threshold", value=str(settings["join_threshold"]), inline=True)
        embed.add_field(name="Window", value=f"{settings['time_window']}s", inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="set_raid_log", description="Set the channel for anti-raid logs")
    @app_commands.describe(channel="Channel for raid alerts")
    @app_commands.checks.has_permissions(administrator=True)
    async def set_raid_log(self, interaction: discord.Interaction, channel: discord.TextChannel):
        guild_id = interaction.guild.id
        settings = self.bot.raid_settings.get(guild_id, {
            "enabled": True,
            "join_threshold": 5,
            "time_window": 10,
            "action": "kick",
            "log_channel": None
        })
        settings["log_channel"] = channel.id
        self.bot.raid_settings[guild_id] = settings
        await interaction.response.send_message(f"✅ Anti-raid logs will be sent to {channel.mention}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(AntiRaid(bot))
