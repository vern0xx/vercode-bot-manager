import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone, timedelta
from typing import Optional

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ban", description="Ban a member from the server")
    @app_commands.describe(member="Member to ban", reason="Reason for the ban", delete_days="Delete message history (0-7)")
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = "No reason provided", delete_days: app_commands.Range[int, 0, 7] = 0):
        if member.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
            return await interaction.response.send_message("❌ You cannot ban someone with equal or higher role.", ephemeral=True)
        try:
            await member.ban(reason=f"[Sentron] {reason} | by {interaction.user}", delete_message_days=delete_days)
            embed = discord.Embed(title="🔨 Member Banned", description=f"**{member}** has been banned.\n**Reason:** {reason}", color=0x9b59ff, timestamp=datetime.now(timezone.utc))
            embed.set_footer(text=f"Moderator: {interaction.user}")
            await interaction.response.send_message(embed=embed)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to ban this member.", ephemeral=True)

    @app_commands.command(name="kick", description="Kick a member from the server")
    @app_commands.describe(member="Member to kick", reason="Reason for the kick")
    @app_commands.checks.has_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = "No reason provided"):
        if member.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
            return await interaction.response.send_message("❌ You cannot kick someone with equal or higher role.", ephemeral=True)
        try:
            await member.kick(reason=f"[Sentron] {reason} | by {interaction.user}")
            embed = discord.Embed(title="👢 Member Kicked", description=f"**{member}** has been kicked.\n**Reason:** {reason}", color=0x9b59ff, timestamp=datetime.now(timezone.utc))
            embed.set_footer(text=f"Moderator: {interaction.user}")
            await interaction.response.send_message(embed=embed)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to kick this member.", ephemeral=True)

    @app_commands.command(name="timeout", description="Timeout a member")
    @app_commands.describe(member="Member to timeout", minutes="Duration in minutes", reason="Reason")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def timeout(self, interaction: discord.Interaction, member: discord.Member, minutes: app_commands.Range[int, 1, 40320], reason: Optional[str] = "No reason provided"):
        if member.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
            return await interaction.response.send_message("❌ You cannot timeout someone with equal or higher role.", ephemeral=True)
        try:
            until = datetime.now(timezone.utc) + timedelta(minutes=minutes)
            await member.timeout(until, reason=f"[Sentron] {reason} | by {interaction.user}")
            embed = discord.Embed(title="⏱️ Member Timed Out", description=f"**{member}** timed out for **{minutes}** minutes.\n**Reason:** {reason}", color=0x9b59ff, timestamp=datetime.now(timezone.utc))
            embed.set_footer(text=f"Moderator: {interaction.user}")
            await interaction.response.send_message(embed=embed)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I don't have permission to timeout this member.", ephemeral=True)

    @app_commands.command(name="unban", description="Unban a user by ID")
    @app_commands.describe(user_id="User ID to unban", reason="Reason")
    @app_commands.checks.has_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id: str, reason: Optional[str] = "No reason provided"):
        try:
            user = await self.bot.fetch_user(int(user_id))
            await interaction.guild.unban(user, reason=f"[Sentron] {reason} | by {interaction.user}")
            embed = discord.Embed(title="✅ User Unbanned", description=f"**{user}** has been unbanned.\n**Reason:** {reason}", color=0x9b59ff)
            await interaction.response.send_message(embed=embed)
        except Exception as e:
            await interaction.response.send_message(f"❌ Failed to unban: {e}", ephemeral=True)

    @app_commands.command(name="purge", description="Delete multiple messages")
    @app_commands.describe(amount="Number of messages to delete (1-100)")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def purge(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f"🗑️ Deleted **{len(deleted)}** messages.", ephemeral=True)

    @app_commands.command(name="warn", description="Warn a member")
    @app_commands.describe(member="Member to warn", reason="Reason for the warn")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: Optional[str] = "No reason provided"):
        embed = discord.Embed(title="⚠️ Warning Issued", description=f"**{member.mention}** has been warned.\n**Reason:** {reason}", color=0xf1c40f, timestamp=datetime.now(timezone.utc))
        embed.set_footer(text=f"Moderator: {interaction.user}")
        await interaction.response.send_message(embed=embed)
        try:
            await member.send(f"You received a warning in **{interaction.guild.name}**\nReason: {reason}")
        except:
            pass

async def setup(bot):
    await bot.add_cog(Moderation(bot))
