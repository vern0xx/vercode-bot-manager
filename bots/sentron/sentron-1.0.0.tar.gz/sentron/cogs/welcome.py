import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone

class Welcome(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.settings = {}

    def get_settings(self, guild_id: int):
        return self.settings.get(guild_id, {
            "enabled": False,
            "channel_id": None,
            "message": "Welcome {user} to **{server}**! You are member #{membercount}.",
            "role_id": None,
            "dm": False,
        })

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        s = self.get_settings(member.guild.id)
        if not s.get("enabled"):
            return
        msg = (s.get("message") or "Welcome {user}!")
        msg = msg.replace("{user}", member.mention)
        msg = msg.replace("{server}", member.guild.name)
        msg = msg.replace("{membercount}", str(member.guild.member_count))
        role_id = s.get("role_id")
        if role_id:
            role = member.guild.get_role(int(role_id))
            if role:
                try:
                    await member.add_roles(role, reason="[Sentron] Welcome auto-role")
                except discord.Forbidden:
                    pass
        ch_id = s.get("channel_id")
        if ch_id:
            channel = member.guild.get_channel(int(ch_id))
            if channel:
                embed = discord.Embed(description=msg, color=0x9b59ff, timestamp=datetime.now(timezone.utc))
                embed.set_thumbnail(url=member.display_avatar.url)
                embed.set_footer(text="Sentron Welcome")
                try:
                    await channel.send(embed=embed)
                except Exception:
                    pass
        if s.get("dm"):
            try:
                await member.send(f"Welcome to **{member.guild.name}**!\n{msg}")
            except Exception:
                pass

    @app_commands.command(name="welcome", description="Configure welcome messages")
    @app_commands.describe(enabled="Enable welcome", channel="Welcome channel", message="Message template")
    @app_commands.checks.has_permissions(administrator=True)
    async def welcome_cmd(self, interaction: discord.Interaction, enabled: bool=None, channel: discord.TextChannel=None, message: str=None):
        gid = interaction.guild.id
        s = self.get_settings(gid)
        if enabled is not None:
            s["enabled"] = enabled
        if channel:
            s["channel_id"] = channel.id
        if message:
            s["message"] = message
        self.settings[gid] = s
        embed = discord.Embed(title="Welcome Settings", color=0x9b59ff)
        embed.add_field(name="Enabled", value="ON" if s["enabled"] else "OFF", inline=True)
        embed.add_field(name="Channel", value=f"<#{s['channel_id']}>" if s.get("channel_id") else "-", inline=True)
        embed.add_field(name="Message", value=s.get("message", "-")[:100], inline=False)
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Welcome(bot))
