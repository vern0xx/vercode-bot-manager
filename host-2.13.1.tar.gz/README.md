# VerCode Bot Manager 2.13.0

Host wielu botów Discord (Windows, pywebview).

## Start
```
pip install -r requirements.txt
python host.py
```
lub `run.bat`. Pierwsze uruchomienie = instalator.

**Dane:** `%APPDATA%\VerCode Bot Manager\`

## Aktualizacje (ważne)
1. W `host.py` ustaw `APP_VERSION` (np. `2.13.0`).
2. Admin → Wydanie: ta sama wersja, kanał stable/beta.
3. **Zapisz i publikuj** (token GitHub, branch `gh-pages`).
4. Na Pages muszą być:
   - `manifest.json` z `version` + `tar_url` lub `exe_url`
   - plik paczki `host-2.13.0.tar.gz` albo `dist/BotHost-2.13.0.exe`

Bez URL paczki w manifeście klient **nie** zainstaluje update.

Host przy starcie sprawdza manifest, otwiera updater, pobiera (retry ×3), weryfikuje SHA-256, instaluje i restartuje.

## Admin
```
python admin_host.py
```
- Pulpit, wydania, boty (paczki), pliki, historia, kompilator, publikacja
- Bez `.exe` admin sam buduje `host-{ver}.tar.gz` i publikuje z manifestem

## Sentron
Szablon w `bots/sentron/` — Components V2 (`/panel`, `/menu`, `/webhook_panel`).

## Webhooki hosta
Alerty start/stop/crash jako Discord Components V2 (fallback: embed).
