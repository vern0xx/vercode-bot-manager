import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone

BANNER_URL = "https://i.imgur.com/KgHRHNo.png"
ACCENT = discord.Colour(0x9b59ff)


def sentron_box(title: str, body: str) -> discord.ui.LayoutView:
    view = discord.ui.LayoutView()
    view.add_item(
        discord.ui.Container(
            discord.ui.TextDisplay(f"```                      {title}```"),
            discord.ui.TextDisplay(body),
            discord.ui.Separator(),
            discord.ui.MediaGallery(discord.MediaGalleryItem(media=BANNER_URL)),
            discord.ui.Separator(),
            discord.ui.TextDisplay("-# SENTRON × COMPONENTS"),
            accent_colour=ACCENT,
        )
    )
    return view


class HelpLayout(discord.ui.LayoutView):
    def __init__(self, bot):
        super().__init__(timeout=180)
        self.bot = bot
        row = discord.ui.ActionRow()
        for label, key in (
            ("Anti-Raid", "antiraid"),
            ("Moderacja", "mod"),
            ("Utility", "util"),
            ("Webhooki", "hooks"),
        ):
            btn = discord.ui.Button(label=label, style=discord.ButtonStyle.secondary, custom_id=f"sentron_help_{key}")
            btn.callback = self._make_cb(key)
            row.add_item(btn)
        row2 = discord.ui.ActionRow()
        close = discord.ui.Button(label="Zamknij", style=discord.ButtonStyle.danger, custom_id="sentron_help_close")
        close.callback = self._close
        row2.add_item(close)
        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("```                      SENTRON × MENU```"),
                discord.ui.TextDisplay("Wybierz kategorię, aby zobaczyć komendy."),
                discord.ui.Separator(),
                row,
                row2,
                discord.ui.Separator(),
                discord.ui.MediaGallery(discord.MediaGalleryItem(media=BANNER_URL)),
                discord.ui.Separator(),
                discord.ui.TextDisplay("-# SENTRON × COMPONENTS V2"),
                accent_colour=ACCENT,
            )
        )

    def _make_cb(self, key):
        async def cb(interaction: discord.Interaction):
            texts = {
                "antiraid": (
                    "**Anti-Raid**\n"
                    "`/antiraid` — konfiguracja\n"
                    "`/antiraid_status` — status\n"
                    "`/set_raid_log` — kanał logów\n"
                    "`/panel` — panel interaktywny"
                ),
                "mod": (
                    "**Moderacja**\n"
                    "`/ban` `/kick` `/timeout` `/unban`\n"
                    "`/purge` `/warn`"
                ),
                "util": (
                    "**Utility**\n"
                    "`/serverinfo` `/userinfo` `/avatar`\n"
                    "`/ping` `/uptime` `/help` `/menu`"
                ),
                "hooks": (
                    "**Webhooki & alerty**\n"
                    "`/webhook_panel` — panel Components V2\n"
                    "`/set_webhook` — URL webhooka serwera\n"
                    "Host VerCode wysyła embedy: start · stop · crash · create"
                ),
            }
            await interaction.response.send_message(
                view=sentron_box("SENTRON × HELP", texts.get(key, "—")),
                ephemeral=True,
            )
        return cb

    async def _close(self, interaction: discord.Interaction):
        try:
            await interaction.message.delete()
        except Exception:
            await interaction.response.defer()


class AntiRaidLayout(discord.ui.LayoutView):
    def __init__(self, bot, guild_id: int):
        super().__init__(timeout=240)
        self.bot = bot
        self.guild_id = guild_id
        s = self._settings()
        status = "WŁĄCZONY" if s.get("enabled", True) else "WYŁĄCZONY"
        body = (
            f"**Status:** {status}\n"
            f"**Akcja:** `{s.get('action', 'kick').upper()}`\n"
            f"**Próg:** `{s.get('join_threshold', 5)}` joinów / `{s.get('time_window', 10)}s`"
        )
        row = discord.ui.ActionRow()
        toggle = discord.ui.Button(label="Toggle", style=discord.ButtonStyle.primary, custom_id="sentron_ar_toggle")
        toggle.callback = self._toggle
        row.add_item(toggle)
        for lab, val in (("Kick", "kick"), ("Ban", "ban"), ("Quarantine", "quarantine")):
            b = discord.ui.Button(label=lab, style=discord.ButtonStyle.secondary, custom_id=f"sentron_ar_{val}")
            b.callback = self._make_action(val)
            row.add_item(b)
        row2 = discord.ui.ActionRow()
        up = discord.ui.Button(label="Próg +1", style=discord.ButtonStyle.secondary, custom_id="sentron_ar_up")
        down = discord.ui.Button(label="Próg -1", style=discord.ButtonStyle.secondary, custom_id="sentron_ar_down")
        up.callback = self._up
        down.callback = self._down
        row2.add_item(up)
        row2.add_item(down)
        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("```                      SENTRON × ANTI-RAID```"),
                discord.ui.TextDisplay(body),
                discord.ui.Separator(),
                row,
                row2,
                discord.ui.Separator(),
                discord.ui.MediaGallery(discord.MediaGalleryItem(media=BANNER_URL)),
                discord.ui.Separator(),
                discord.ui.TextDisplay("-# SENTRON × COMPONENTS V2"),
                accent_colour=ACCENT,
            )
        )

    def _settings(self):
        return self.bot.raid_settings.get(
            self.guild_id,
            {"enabled": True, "join_threshold": 5, "time_window": 10, "action": "kick", "log_channel": None},
        )

    async def _toggle(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message(view=sentron_box("SENTRON", "Brak uprawnień."), ephemeral=True)
        s = self._settings()
        s["enabled"] = not s.get("enabled", True)
        self.bot.raid_settings[self.guild_id] = s
        await interaction.response.edit_message(view=AntiRaidLayout(self.bot, self.guild_id))

    def _make_action(self, val):
        async def cb(interaction: discord.Interaction):
            if not interaction.user.guild_permissions.administrator:
                return await interaction.response.send_message(view=sentron_box("SENTRON", "Brak uprawnień."), ephemeral=True)
            s = self._settings()
            s["action"] = val
            self.bot.raid_settings[self.guild_id] = s
            await interaction.response.edit_message(view=AntiRaidLayout(self.bot, self.guild_id))
        return cb

    async def _up(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message(view=sentron_box("SENTRON", "Brak uprawnień."), ephemeral=True)
        s = self._settings()
        s["join_threshold"] = min(50, s.get("join_threshold", 5) + 1)
        self.bot.raid_settings[self.guild_id] = s
        await interaction.response.edit_message(view=AntiRaidLayout(self.bot, self.guild_id))

    async def _down(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message(view=sentron_box("SENTRON", "Brak uprawnień."), ephemeral=True)
        s = self._settings()
        s["join_threshold"] = max(2, s.get("join_threshold", 5) - 1)
        self.bot.raid_settings[self.guild_id] = s
        await interaction.response.edit_message(view=AntiRaidLayout(self.bot, self.guild_id))


class WebhookLayout(discord.ui.LayoutView):
    def __init__(self, bot, guild_id: int):
        super().__init__(timeout=240)
        self.bot = bot
        self.guild_id = guild_id
        if not hasattr(bot, "webhook_settings"):
            bot.webhook_settings = {}
        s = bot.webhook_settings.get(guild_id, {
            "url": "",
            "start": True,
            "stop": True,
            "crash": True,
            "mod": True,
        })
        url = s.get("url") or "—"
        if len(url) > 48:
            url = url[:24] + "…" + url[-12:]
        body = (
            f"**URL:** `{url}`\n"
            f"**Start/Stop:** `{'ON' if s.get('start') else 'OFF'}` / `{'ON' if s.get('stop') else 'OFF'}`\n"
            f"**Crash:** `{'ON' if s.get('crash') else 'OFF'}` · **Mod log:** `{'ON' if s.get('mod') else 'OFF'}`\n\n"
            "Ustaw URL komendą `/set_webhook`."
        )
        row = discord.ui.ActionRow()
        for lab, key in (("Start", "start"), ("Stop", "stop"), ("Crash", "crash"), ("Mod", "mod")):
            b = discord.ui.Button(
                label=lab,
                style=discord.ButtonStyle.success if s.get(key) else discord.ButtonStyle.secondary,
                custom_id=f"sentron_wh_{key}",
            )
            b.callback = self._toggle(key)
            row.add_item(b)
        row2 = discord.ui.ActionRow()
        test = discord.ui.Button(label="Wyślij test", style=discord.ButtonStyle.primary, custom_id="sentron_wh_test")
        test.callback = self._test
        row2.add_item(test)
        self.add_item(
            discord.ui.Container(
                discord.ui.TextDisplay("```                      SENTRON × WEBHOOKS```"),
                discord.ui.TextDisplay(body),
                discord.ui.Separator(),
                row,
                row2,
                discord.ui.Separator(),
                discord.ui.MediaGallery(discord.MediaGalleryItem(media=BANNER_URL)),
                discord.ui.Separator(),
                discord.ui.TextDisplay("-# SENTRON × COMPONENTS V2"),
                accent_colour=ACCENT,
            )
        )

    def _toggle(self, key):
        async def cb(interaction: discord.Interaction):
            if not interaction.user.guild_permissions.administrator:
                return await interaction.response.send_message(view=sentron_box("SENTRON", "Brak uprawnień."), ephemeral=True)
            s = self.bot.webhook_settings.get(self.guild_id, {})
            s[key] = not s.get(key, True)
            self.bot.webhook_settings[self.guild_id] = s
            await interaction.response.edit_message(view=WebhookLayout(self.bot, self.guild_id))
        return cb

    async def _test(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message(view=sentron_box("SENTRON", "Brak uprawnień."), ephemeral=True)
        s = self.bot.webhook_settings.get(self.guild_id, {})
        url = (s.get("url") or "").strip()
        if not url.startswith("http"):
            return await interaction.response.send_message(
                view=sentron_box("SENTRON × WEBHOOKS", "Brak URL — użyj `/set_webhook`."),
                ephemeral=True,
            )
        await interaction.response.defer(ephemeral=True)
        embed = discord.Embed(
            title="Sentron · test webhooka",
            description=f"Guild: **{interaction.guild.name}**\nBy: {interaction.user.mention}",
            color=0x9b59ff,
            timestamp=datetime.now(timezone.utc),
        )
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                webhook = discord.Webhook.from_url(url, session=session)
                await webhook.send(embed=embed, username="Sentron")
            await interaction.followup.send(view=sentron_box("SENTRON × WEBHOOKS", "Test wysłany."), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(view=sentron_box("SENTRON × WEBHOOKS", f"Błąd: {e}"), ephemeral=True)


class ComponentsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        if not hasattr(bot, "webhook_settings"):
            bot.webhook_settings = {}

    @app_commands.command(name="panel", description="Panel Anti-Raid (Components V2)")
    @app_commands.checks.has_permissions(administrator=True)
    async def panel(self, interaction: discord.Interaction):
        await interaction.response.send_message(view=AntiRaidLayout(self.bot, interaction.guild.id))

    @app_commands.command(name="menu", description="Menu komend (Components V2)")
    async def menu(self, interaction: discord.Interaction):
        await interaction.response.send_message(view=HelpLayout(self.bot), ephemeral=True)

    @app_commands.command(name="webhook_panel", description="Panel webhooków serwera (Components V2)")
    @app_commands.checks.has_permissions(administrator=True)
    async def webhook_panel(self, interaction: discord.Interaction):
        await interaction.response.send_message(view=WebhookLayout(self.bot, interaction.guild.id), ephemeral=True)

    @app_commands.command(name="set_webhook", description="Ustaw URL webhooka alertów serwera")
    @app_commands.describe(url="Discord webhook URL")
    @app_commands.checks.has_permissions(administrator=True)
    async def set_webhook(self, interaction: discord.Interaction, url: str):
        url = url.strip()
        if not url.startswith("https://discord.com/api/webhooks/") and not url.startswith("https://discordapp.com/api/webhooks/"):
            return await interaction.response.send_message(
                view=sentron_box("SENTRON × WEBHOOKS", "Podaj poprawny URL webhooka Discord."),
                ephemeral=True,
            )
        s = self.bot.webhook_settings.get(interaction.guild.id, {
            "url": "", "start": True, "stop": True, "crash": True, "mod": True,
        })
        s["url"] = url
        self.bot.webhook_settings[interaction.guild.id] = s
        await interaction.response.send_message(
            view=sentron_box("SENTRON × WEBHOOKS", "Webhook zapisany. Otwórz `/webhook_panel`."),
            ephemeral=True,
        )


async def setup(bot):
    await bot.add_cog(ComponentsCog(bot))
