"""
Sentron Discord Bot
Anti-raid • moderation • verification • tickets • welcome • utility
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import logging
from datetime import datetime, timezone
from collections import defaultdict

import discord
from discord.ext import commands, tasks
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("sentron")

TOKEN = os.getenv("DISCORD_TOKEN")
OWNER_IDS = [int(x) for x in os.getenv("OWNER_IDS", "").split(",") if x.strip()]

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True
intents.moderation = True


class SentronBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix="!",
            intents=intents,
            help_command=None,
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="your servers ✨",
            ),
        )
        self.start_time = datetime.now(timezone.utc)
        self.raid_tracker = defaultdict(list)
        self.raid_settings = {}
        self.whitelist = set()
        self.owner_ids = set(OWNER_IDS)

    async def setup_hook(self):
        cogs = [
            "moderation",
            "antiraid",
            "utility",
            "admin",
            "components",
            "welcome",
            "verification",
            "tickets",
        ]
        for cog in cogs:
            try:
                await self.load_extension(f"cogs.{cog}")
                logger.info("Loaded cog: %s", cog)
            except Exception as e:
                logger.error("Failed to load %s: %s", cog, e)

        try:
            synced = await self.tree.sync()
            logger.info("Synced %d slash commands", len(synced))
        except Exception as e:
            logger.error("Failed to sync commands: %s", e)

    async def on_ready(self):
        logger.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        logger.info("Connected to %d guilds", len(self.guilds))
        if not self.status_loop.is_running():
            self.status_loop.start()

    @tasks.loop(minutes=5)
    async def status_loop(self):
        statuses = [
            discord.Activity(type=discord.ActivityType.watching, name="Dashboard"),
            discord.Activity(type=discord.ActivityType.watching, name="Our Servers"),
            discord.Activity(
                type=discord.ActivityType.watching,
                name=f"{len(self.guilds)} servers",
            ),
        ]
        idx = int(datetime.now().timestamp()) % len(statuses)
        await self.change_presence(activity=statuses[idx])


bot = SentronBot()


@bot.event
async def on_member_join(member: discord.Member):
    """Anti-raid join tracking (main logic)."""
    guild = member.guild
    settings = bot.raid_settings.get(
        guild.id,
        {
            "enabled": True,
            "join_threshold": 5,
            "time_window": 10,
            "action": "kick",
            "log_channel": None,
        },
    )

    if not settings.get("enabled", True):
        return

    now = datetime.now(timezone.utc).timestamp()
    bot.raid_tracker[guild.id].append(now)

    window = settings.get("time_window", 10)
    bot.raid_tracker[guild.id] = [
        t for t in bot.raid_tracker[guild.id] if now - t < window
    ]

    if len(bot.raid_tracker[guild.id]) >= settings.get("join_threshold", 5):
        action = settings.get("action", "kick")
        log_ch_id = settings.get("log_channel")
        log_channel = guild.get_channel(log_ch_id) if log_ch_id else None

        try:
            if action == "ban":
                await member.ban(reason="[Sentron] Anti-Raid: Mass join detected")
            elif action == "kick":
                await member.kick(reason="[Sentron] Anti-Raid: Mass join detected")
            # quarantine handled in cog if role is set
        except discord.Forbidden:
            pass

        if log_channel:
            embed = discord.Embed(
                title="🛡️ Raid Detected",
                description=(
                    f"**Member:** {member.mention} (`{member.id}`)\n"
                    f"**Action:** {action.upper()}\n"
                    f"**Joins in window:** {len(bot.raid_tracker[guild.id])}"
                ),
                color=0x9B59FF,
                timestamp=datetime.now(timezone.utc),
            )
            embed.set_footer(text="Sentron Anti-Raid")
            try:
                await log_channel.send(embed=embed)
            except Exception:
                pass


@bot.tree.command(name="ping", description="Check bot latency")
async def ping(interaction: discord.Interaction):
    latency = round(bot.latency * 1000)
    embed = discord.Embed(
        title="🏓 Pong!",
        description=f"Latency: **{latency}ms**",
        color=0x9B59FF,
    )
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="help", description="Show all available commands")
async def help_cmd(interaction: discord.Interaction):
    embed = discord.Embed(
        title="✨ Sentron Commands",
        description="Modern moderation & anti-raid bot.",
        color=0x9B59FF,
    )
    embed.add_field(
        name="🛡️ Anti-Raid",
        value="`/antiraid` `/antiraid_status` `/set_raid_log` `/panel`",
        inline=False,
    )
    embed.add_field(
        name="✅ Verification",
        value="`/setup_verify` `/verify_config`",
        inline=False,
    )
    embed.add_field(
        name="🎫 Tickets",
        value="`/setup_tickets` `/ticket_config`",
        inline=False,
    )
    embed.add_field(name="👋 Welcome", value="`/welcome`", inline=False)
    embed.add_field(
        name="🔨 Moderation",
        value="`/ban` `/kick` `/timeout` `/unban` `/purge` `/warn`",
        inline=False,
    )
    embed.add_field(
        name="⚙️ Utility",
        value="`/serverinfo` `/userinfo` `/avatar` `/ping` `/uptime`",
        inline=False,
    )
    embed.add_field(
        name="🧩 Components",
        value="`/menu` `/panel` `/webhook_panel` `/set_webhook`",
        inline=False,
    )
    embed.set_footer(text="Sentron • Liquid Glass UI")
    await interaction.response.send_message(embed=embed, ephemeral=True)


if __name__ == "__main__":
    if not TOKEN:
        logger.error("DISCORD_TOKEN not set in .env")
        raise SystemExit(1)
    bot.run(TOKEN)
