@echo off
chcp 65001 >nul
title VerCode Bot Manager
python host.py
if errorlevel 1 pause
