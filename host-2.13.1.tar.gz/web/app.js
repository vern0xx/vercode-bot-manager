const state = {
  bots: [], selected: null, logSeq: 0, pollTimer: null, dirty: false, editing: null,
  filter: 'all', search: '', logSearch: '', showTimestamps: true, allLogLines: [],
  avatars: {}, settings: {},
};

const $ = (id) => document.getElementById(id);
const api = () => (window.pywebview ? window.pywebview.api : null);

let initialized = false;

const ICONS = {
  spin: '<svg class="spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.22-8.56"/></svg>',
  file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>',
  python: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2c-3.3 0-6 1.5-6 5v3h12V7c0-3.5-2.7-5-6-5z"/></svg>',
  config: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/></svg>',
  env: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777z"/></svg>',
  ok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg>',
  err: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>',
};

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function toast(message, type = 'info') {
  const container = $('toasts');
  if (!container) return;
  if (container.children.length >= 4) container.firstChild.remove();
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `${ICONS[type === 'success' ? 'ok' : type === 'error' ? 'err' : 'info']}<span>${escapeHtml(message)}</span>`;
  container.appendChild(el);
  setTimeout(() => { el.classList.add('leaving'); setTimeout(() => el.remove(), 200); }, 2600);
}

function pushEvent(title, detail, kind = 'info') {
  const feed = $('event-feed');
  if (!feed) return;
  const card = document.createElement('div');
  card.className = `event-card ${kind}`;
  card.innerHTML = `<div class="ec-title">${escapeHtml(title)}</div>${detail ? `<div class="ec-detail">${escapeHtml(detail)}</div>` : ''}`;
  feed.appendChild(card);
  setTimeout(() => { card.classList.add('leaving'); setTimeout(() => card.remove(), 250); }, 4500);
  if (feed.children.length > 4) feed.firstChild.remove();
}

function setStatus(msg, type = '') {
  const dot = $('status-dot');
  const text = $('status');
  if (!dot || !text) return;
  text.textContent = msg;
  dot.className = 'status-dot' + (type ? ' ' + type : '');
  if (!type) setTimeout(() => { text.textContent = 'Gotowe'; dot.className = 'status-dot'; }, 1800);
}

async function withLoading(btn, fn) {
  if (!btn) return fn();
  const original = btn.innerHTML;
  btn.classList.add('loading');
  btn.innerHTML = ICONS.spin;
  try { return await fn(); } finally { btn.classList.remove('loading'); btn.innerHTML = original; }
}

function formatUptime(sec) {
  if (sec == null) return '—';
  if (sec < 60) return `${sec}s`;
  const m = Math.floor(sec / 60);
  if (m < 60) return `${m}m ${sec % 60}s`;
  return `${Math.floor(m / 60)}h ${m % 60}m`;
}

function formatBytes(n) {
  if (n == null || n === 0) return '—';
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}

async function loadAvatar(name) {
  if (state.avatars[name]) return state.avatars[name];
  try {
    const res = await api()?.get_avatar_data(name);
    if (res?.ok) {
      const src = res.data || res.url;
      state.avatars[name] = src;
      return src;
    }
  } catch (e) {}
  return null;
}


function updateKpis() {
  const bots = Array.isArray(state.bots) ? state.bots : [];
  const run = bots.filter((b) => b.running).length;
  if ($('kpi-bots')) $('kpi-bots').textContent = bots.length;
  if ($('kpi-run')) $('kpi-run').textContent = run;
  if ($('kpi-stop')) $('kpi-stop').textContent = Math.max(0, bots.length - run);
  if ($('bot-count')) $('bot-count').textContent = bots.length;
}

async function refreshBots(showSkeleton = false) {
  if (showSkeleton) renderSkeleton();
  try {
    if (!api()) {
      state.bots = [];
      renderSidebar();
      return;
    }
    const result = await api().list_bots();
    state.bots = Array.isArray(result) ? result : [];
    for (const b of state.bots) {
      if (b.avatar && !state.avatars[b.name]) loadAvatar(b.name).then(() => renderSidebar());
    }
    renderSidebar();
    updateHeader();
    if ($('bot-count')) $('bot-count').textContent = state.bots.length;
    updateKpis();
  } catch (e) {
    console.error(e);
    renderSidebar();
  }
}

function renderSkeleton() {
  const list = $('bots-list');
  if (!list) return;
  list.innerHTML = '';
  for (let i = 0; i < 3; i++) {
    const s = document.createElement('div');
    s.className = 'skeleton';
    s.style.cssText = 'height:64px;border-radius:14px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.06);margin-bottom:6px;';
    list.appendChild(s);
  }
}

function renderSidebar() {
  const list = $('bots-list');
  if (!list) return;
  list.innerHTML = '';
  if (!Array.isArray(state.bots)) state.bots = [];
  const filtered = state.search
    ? state.bots.filter((b) => b.name.toLowerCase().includes(state.search.toLowerCase()) || (b.discord_username || '').toLowerCase().includes(state.search.toLowerCase()))
    : state.bots;
  if (!filtered.length) {
    list.innerHTML = `<div style="padding:16px 10px;text-align:center;color:var(--text-4);font-size:12px;">${state.search ? 'Brak wyników' : 'Brak botów'}</div>`;
    return;
  }
  filtered.forEach((b) => {
    const el = document.createElement('div');
    el.className = 'bot-item' + (state.selected === b.name ? ' active' : '');
    el.dataset.bot = b.name;
    const av = state.avatars[b.name];
    const initial = (b.discord_username || b.name).slice(0, 2).toUpperCase();
    const dotClass = b.running ? 'on' : 'off';
    const avHtml = av
      ? `<div class="avatar-wrap"><img class="avatar" src="${av}" alt=""><span class="dot ${dotClass}"></span></div>`
      : `<div class="avatar-wrap"><span class="avatar" style="display:flex;align-items:center;justify-content:center;background:var(--surface-3);color:var(--text-1);font-weight:900;font-size:14px;">${escapeHtml(initial)}</span><span class="dot ${dotClass}"></span></div>`;
    el.innerHTML = `${avHtml}<span class="name" title="${escapeHtml(b.name)}">${escapeHtml(b.name)}</span>`;
    el.onclick = () => selectBot(b.name);
    el.oncontextmenu = (e) => { e.preventDefault(); showContextMenu(e.clientX, e.clientY, b.name); };
    list.appendChild(el);
  });
}

async function updateHeader() {
  if (!state.selected) return;
  const b = state.bots.find((x) => x.name === state.selected);
  if (!b) return;
  if ($('bot-title')) $('bot-title').textContent = b.name;
  if ($('bot-dot')) $('bot-dot').className = 'bot-dot ' + (b.running ? 'on' : 'off');
  if ($('chk-auto')) $('chk-auto').checked = b.auto_restart;
  if ($('bot-status-tag')) {
    $('bot-status-tag').textContent = b.running ? 'Aktywny' : 'Zatrzymany';
    $('bot-status-tag').style.color = b.running ? 'var(--success)' : 'var(--text-4)';
  }
  if ($('bot-discord-name')) {
    $('bot-discord-name').textContent = b.discord_username ? `@${b.discord_username}` : '';
  }
  const av = state.avatars[b.name] || (b.avatar ? await loadAvatar(b.name) : null);
  const img = $('bot-avatar-img');
  const fb = $('bot-avatar-fb');
  if (av && img) {
    img.src = av;
    img.hidden = false;
    if (fb) fb.hidden = true;
  } else {
    if (img) img.hidden = true;
    if (fb) {
      fb.hidden = false;
      fb.textContent = (b.discord_username || b.name).slice(0, 2).toUpperCase();
    }
  }
}

async function updateStats() {
  if (!state.selected) return;
  try {
    if (!api()) return;
    const info = await api().get_bot_info(state.selected);
    if ($('stat-pid')) $('stat-pid').textContent = info.pid || '—';
    if ($('stat-uptime')) $('stat-uptime').textContent = formatUptime(info.uptime);
    if ($('stat-restarts')) $('stat-restarts').textContent = info.restarts || 0;
    if ($('stat-cpu')) $('stat-cpu').textContent = info.stats?.cpu != null ? info.stats.cpu + '%' : '—';
    if ($('stat-mem')) $('stat-mem').textContent = formatBytes(info.stats?.memory);
    if ($('stat-errors')) $('stat-errors').textContent = info.level_counts?.error || 0;
    if (info.discord_username && $('bot-discord-name')) {
      $('bot-discord-name').textContent = `@${info.discord_username}`;
    }
  } catch (e) {}
}

async function selectBot(name) {
  state.selected = name;
  state.logSeq = 0;
  state.allLogLines = [];
  if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
  $('empty').hidden = true;
  $('panel').hidden = false;
  $('console').innerHTML = '';
  $('stdin').disabled = false;
  $('btn-send').disabled = false;
  renderSidebar();
  await updateHeader();
  try {
    if (!api()) return;
    const logs = await api().get_logs(name, 0);
    state.logSeq = logs.seq;
    state.allLogLines = logs.lines || [];
    renderLogs();
    await loadFiles(name);
    startPolling();
    updateStats();
  } catch (e) {
    toast('Nie udało się załadować bota', 'error');
  }
}

async function loadFiles(name) {
  try {
    if (!api()) return;
    const files = await api().list_files(name);
    const tree = $('files-tree');
    tree.innerHTML = '';
    const sections = [
      { key: 'env', label: 'Środowisko', icon: ICONS.env },
      { key: 'config', label: 'Konfiguracja', icon: ICONS.config },
      { key: 'code', label: 'Kod', icon: ICONS.python },
      { key: 'other', label: 'Inne', icon: ICONS.file },
    ];
    let has = false;
    for (const sec of sections) {
      const list = files[sec.key] || [];
      if (!list.length) continue;
      has = true;
      const header = document.createElement('div');
      header.className = 'file-item folder';
      header.innerHTML = `${sec.icon}<span>${escapeHtml(sec.label)}</span>`;
      tree.appendChild(header);
      list.forEach((f) => {
        const item = document.createElement('div');
        item.className = 'file-item indent';
        item.innerHTML = `${ICONS.file}<span title="${escapeHtml(f)}">${escapeHtml(f)}</span>`;
        item.onclick = () => openEditor(name, f);
        tree.appendChild(item);
      });
    }
    if (!has) {
      const empty = document.createElement('div');
      empty.className = 'file-item';
      empty.style.color = 'var(--text-4)';
      empty.textContent = 'Brak plików';
      tree.appendChild(empty);
    }
  } catch (e) {}
}

function startPolling() {
  if (state.pollTimer) clearInterval(state.pollTimer);
  state.pollTimer = setInterval(pollTick, 450);
}

async function pollTick() {
  if (!state.selected) return;
  try {
    if (!api()) return;
    const res = await api().get_logs(state.selected, state.logSeq);
    if (res.lines && res.lines.length) {
      state.logSeq = res.seq;
      state.allLogLines = state.allLogLines.concat(res.lines);
      if (state.allLogLines.length > 4000) state.allLogLines = state.allLogLines.slice(-3000);
      renderLogs(true);
      const hasErr = res.lines.some(([_, line, lv]) => (lv || classifyLine(line)) === 'error');
      if (hasErr) {
        const last = res.lines.filter(([_, l, lv]) => (lv || classifyLine(l)) === 'error').pop();
        if (last) pushEvent(`Błąd · ${state.selected}`, last[1].slice(0, 120), 'error');
      }
    }
    const bots = await api().list_bots();
    const safeBots = Array.isArray(bots) ? bots : [];
    const key = (arr) => JSON.stringify(arr.map((b) => [b.name, b.running, b.auto_restart]));
    if (key(safeBots) !== key(state.bots)) {
      const prev = Object.fromEntries(state.bots.map((b) => [b.name, b.running]));
      state.bots = safeBots;
      safeBots.forEach((b) => {
        if (prev[b.name] === true && !b.running) pushEvent(`${b.name} zatrzymany`, '', 'stop');
        if (prev[b.name] === false && b.running) pushEvent(`${b.name} uruchomiony`, '', 'start');
      });
      renderSidebar();
      updateHeader();
      updateKpis();
    }
    updateStats();
    if (state.settings.show_system_stats !== false) {
      const sys = await api().get_system_info();
      if ($('sys-stats')) {
        $('sys-stats').hidden = false;
        if ($('sys-cpu')) $('sys-cpu').textContent = sys.cpu != null ? `CPU ${sys.cpu}%` : 'CPU —';
        if ($('sys-mem')) $('sys-mem').textContent = sys.memory != null ? `RAM ${sys.memory}%` : 'RAM —';
      }
    }
  } catch (e) {}
}

function classifyLine(line, level) {
  if (level && level !== 'info') return level;
  const s = line || '';
  const l = s.toLowerCase();
  if (s.startsWith('>>>') || s.startsWith('[stdin]')) return 'cmd';
  if (s.includes('[HOST]')) {
    if (l.includes('uruchom') || l.includes('pid=')) return 'success';
    return 'host';
  }
  if (s.includes('[WATCHDOG]')) return 'warn';
  if (level === 'error' || l.includes('error') || l.includes('traceback') || l.includes('exception') || l.includes('fatal')) return 'error';
  if (level === 'warn' || l.includes('warn')) return 'warn';
  if (level === 'debug' || l.includes('debug') || l.includes('trace')) return 'debug';
  if (level === 'success' || l.includes('success') || l.includes('ready') || l.includes('zalogowano') || l.includes('logged in') || l.includes('synced')) return 'success';
  if (level) return level;
  return 'info';
}


function buildLogLine(seq, line, lv) {
  const kind = classifyLine(line, lv);
  const div = document.createElement('div');
  div.className = 'console-line ' + kind;
  div.dataset.seq = seq;
  const badge = document.createElement('span');
  badge.className = 'cl-badge';
  badge.textContent = ({ error:'ERR', warn:'WRN', debug:'DBG', success:'OK', host:'HOST', cmd:'IN', info:'INF', trace:'TRC' })[kind] || 'INF';
  div.appendChild(badge);
  if (state.showTimestamps) {
    const ts = document.createElement('span');
    ts.className = 'cl-ts';
    ts.textContent = new Date().toLocaleTimeString();
    div.appendChild(ts);
  }
  const msg = document.createElement('span');
  msg.className = 'cl-msg';
  msg.textContent = line;
  div.appendChild(msg);
  return div;
}

function renderLogs(appendOnly = false) {
  const el = $('console');
  if (!el) return;
  let lines = state.allLogLines;
  if (state.filter !== 'all') lines = lines.filter(([_, line, lv]) => classifyLine(line, lv) === state.filter);
  if (state.logSearch) {
    const q = state.logSearch.toLowerCase();
    lines = lines.filter(([_, line]) => (line || '').toLowerCase().includes(q));
  }
  lines = lines.slice(-2000);
  if (!appendOnly) {
    el.innerHTML = '';
    lines.forEach(([seq, line, lv]) => {
      el.appendChild(buildLogLine(seq, line, lv));
    });
  } else {
    const lastSeq = el.lastChild ? +el.lastChild.dataset.seq : 0;
    lines.filter(([s]) => s > lastSeq).forEach(([seq, line, lv]) => {
      el.appendChild(buildLogLine(seq, line, lv));
    });
  }
  el.scrollTop = el.scrollHeight;
}

async function startBot() {
  if (!state.selected) return;
  await withLoading($('btn-start'), async () => {
    await api()?.start_bot(state.selected);
    toast('Uruchomiono', 'success');
    pushEvent(`${state.selected} uruchomiony`, '', 'start');
    setTimeout(refreshBots, 200);
  });
}
async function stopBot() {
  if (!state.selected) return;
  await withLoading($('btn-stop'), async () => {
    await api()?.stop_bot(state.selected);
    toast('Zatrzymano', 'info');
    pushEvent(`${state.selected} zatrzymany`, '', 'stop');
    setTimeout(refreshBots, 200);
  });
}
async function restartBot() {
  if (!state.selected) return;
  await withLoading($('btn-restart'), async () => {
    await api()?.restart_bot(state.selected);
    toast('Restart…', 'info');
    setTimeout(refreshBots, 600);
  });
}
async function toggleAuto() {
  if (!state.selected) return;
  await api()?.set_auto_restart(state.selected, $('chk-auto').checked);
}

async function sendStdin() {
  if (!state.selected) return;
  const inp = $('stdin');
  const text = inp.value.trim();
  if (!text) return;
  await api()?.send_stdin(state.selected, text);
  inp.value = '';
}

async function newBot() {
  const templates = (await api()?.get_templates()) || [
    { id: 'basic', name: 'Podstawowy' }, { id: 'slash', name: 'Slash' },
    { id: 'mod', name: 'Moderacja' }, { id: 'empty', name: 'Pusty' }, { id: 'sentron', name: 'Sentron' },
  ];
  const tpl = await pickTemplate(templates);
  if (!tpl) return;
  const name = await promptModal('Nazwa nowego bota:');
  if (!name) return;
  await withLoading($('btn-new'), async () => {
    const res = await api()?.create_from_template(name, tpl);
    if (!res || !res.ok) return toast(res?.error || 'Błąd', 'error');
    toast(`Utworzono ${name}`, 'success');
    pushEvent(`Nowy bot: ${name}`, 'Szablon: ' + tpl, 'start');
    await refreshBots();
    selectBot(name);
  });
}

function pickTemplate(templates) {
  return new Promise((resolve) => {
    const m = $('template-modal');
    const list = $('template-list');
    list.innerHTML = '';
    templates.forEach((t) => {
      const btn = document.createElement('button');
      btn.className = 'btn';
      btn.style.width = '100%';
      btn.textContent = t.name;
      btn.onclick = () => { m.hidden = true; resolve(t.id); };
      list.appendChild(btn);
    });
    m.hidden = false;
    $('template-cancel').onclick = () => { m.hidden = true; resolve(null); };
  });
}

async function uploadFolder() {
  if (!api()) return;
  const path = await api().pick_folder();
  if (!path) return;
  const suggested = path.split(/[\\/]/).pop();
  const name = await promptModal('Nazwa bota:', suggested);
  if (!name) return;
  await withLoading($('btn-upload-folder'), async () => {
    const res = await api().import_folder(path, name);
    if (!res.ok) return toast(res.error || 'Błąd', 'error');
    toast(`Zaimportowano ${name}`, 'success');
    await refreshBots();
    selectBot(name);
  });
}

async function deleteBot() {
  if (!state.selected) return;
  const needConfirm = state.settings.confirm_delete !== false;
  if (needConfirm && !(await confirmModal('Usuń bota', `Na pewno usunąć „${state.selected}”? Folder zostanie skasowany.`))) return;
  await api()?.delete_bot(state.selected);
  toast('Usunięto', 'info');
  delete state.avatars[state.selected];
  state.selected = null;
  $('empty').hidden = false;
  $('panel').hidden = true;
  if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
  await refreshBots();
}

async function openEditor(botName, filename) {
  if (!api()) return;
  const res = await api().read_file(botName, filename);
  if (!res.ok) return toast(res.error || 'Nie można odczytać', 'error');
  state.editing = { bot: botName, file: filename };
  state.dirty = false;
  $('modal-title').textContent = `${botName} / ${filename}`;
  $('modal-text').value = res.content;
  $('dirty-dot').classList.remove('active');
  $('modal').hidden = false;
  setTimeout(() => $('modal-text').focus(), 30);
}

async function saveEditor() {
  if (!state.editing) return;
  await withLoading($('modal-save'), async () => {
    const res = await api()?.write_file(state.editing.bot, state.editing.file, $('modal-text').value);
    if (res && res.ok === false) return toast(res.error || 'Błąd zapisu', 'error');
    toast('Zapisano', 'success');
    state.dirty = false;
    $('dirty-dot').classList.remove('active');
  });
}

function closeEditor(force = false) {
  if (!force && state.dirty) {
    confirmModal('Niezapisane zmiany', 'Zamknąć bez zapisywania?').then((ok) => { if (ok) closeEditor(true); });
    return;
  }
  $('modal').hidden = true;
  state.editing = null;
  state.dirty = false;
}

function promptModal(title, defaultValue = '') {
  return new Promise((resolve) => {
    const m = $('prompt');
    $('prompt-title').textContent = title;
    const inp = $('prompt-input');
    inp.value = defaultValue || '';
    m.hidden = false;
    setTimeout(() => { inp.focus(); inp.select(); }, 30);
    const finish = (val) => {
      m.hidden = true;
      $('prompt-ok').onclick = null;
      $('prompt-cancel').onclick = null;
      inp.onkeydown = null;
      resolve(val);
    };
    $('prompt-ok').onclick = () => finish(inp.value.trim());
    $('prompt-cancel').onclick = () => finish(null);
    inp.onkeydown = (e) => {
      if (e.key === 'Enter') finish(inp.value.trim());
      if (e.key === 'Escape') finish(null);
    };
  });
}

function confirmModal(title, message) {
  return new Promise((resolve) => {
    const m = $('confirm');
    $('confirm-title').textContent = title;
    $('confirm-message').textContent = message;
    m.hidden = false;
    const finish = (val) => {
      m.hidden = true;
      $('confirm-ok').onclick = null;
      $('confirm-cancel').onclick = null;
      resolve(val);
    };
    $('confirm-ok').onclick = () => finish(true);
    $('confirm-cancel').onclick = () => finish(false);
  });
}

function showContextMenu(x, y, botName) {
  const menu = $('context-menu');
  menu.hidden = false;
  menu.style.left = Math.min(x, window.innerWidth - 200) + 'px';
  menu.style.top = Math.min(y, window.innerHeight - 320) + 'px';
  const close = () => { menu.hidden = true; document.removeEventListener('click', close); };
  setTimeout(() => document.addEventListener('click', close), 8);

  menu.querySelectorAll('button').forEach((btn) => {
    btn.onclick = async (e) => {
      e.stopPropagation();
      menu.hidden = true;
      const action = btn.dataset.action;
      if (action === 'rename') {
        const newName = await promptModal('Nowa nazwa:', botName);
        if (!newName || newName === botName) return;
        const res = await api()?.rename_bot(botName, newName);
        if (res?.ok) {
          toast('Zmieniono nazwę', 'success');
          if (state.selected === botName) state.selected = newName;
          if (state.avatars[botName]) { state.avatars[newName] = state.avatars[botName]; delete state.avatars[botName]; }
          await refreshBots();
          if (state.selected) selectBot(state.selected);
        } else toast(res?.error || 'Błąd', 'error');
      } else if (action === 'duplicate') {
        const res = await api()?.duplicate_bot(botName);
        if (res?.ok) { toast(`Zduplikowano: ${res.name}`, 'success'); await refreshBots(); }
        else toast('Błąd', 'error');
      } else if (action === 'backup') {
        const res = await api()?.backup_bot(botName);
        if (res?.ok) toast('Backup zapisany', 'success');
        else if (!res?.cancelled) toast(res?.error || 'Błąd', 'error');
      } else if (action === 'priority') {
        const p = await promptModal('Priorytet (idle/below/normal/above/high):', 'normal');
        if (!p) return;
        const res = await api()?.set_priority(botName, p);
        if (res?.ok) toast('Priorytet ustawiony', 'success');
        else toast(res?.error || 'Błąd', 'error');
      } else if (action === 'note') {
        const note = await promptModal('Notatka:', '');
        if (note === null) return;
        await api()?.set_note(botName, note);
        toast('Notatka zapisana', 'success');
      } else if (action === 'botwebhook') {
        const url = await promptModal('Webhook URL (pusty = globalny):', '');
        if (url === null) return;
        await api()?.set_bot_webhook(botName, url);
        toast('Webhook bota zapisany', 'success');
      } else if (action === 'avatar') {
        const res = await api()?.refresh_avatar(botName);
        if (res?.ok) {
          delete state.avatars[botName];
          await loadAvatar(botName);
          renderSidebar();
          if (state.selected === botName) updateHeader();
          toast(res.username ? `Awatar: @${res.username}` : 'Awatar pobrany', 'success');
        } else toast(res?.error || 'Błąd', 'error');
      } else if (action === 'autostart') {
        const b = state.bots.find((x) => x.name === botName);
        const val = !(b && b.auto_start);
        await api()?.set_auto_start(botName, val);
        toast(val ? 'Auto-start włączony' : 'Auto-start wyłączony', 'success');
        await refreshBots();
      } else if (action === 'openfolder') {
        await api()?.open_folder(botName);
      } else if (action === 'delete') {
        state.selected = botName;
        await deleteBot();
      }
    };
  });
}

async function openSettings() {
  try {
    const s = await api()?.get_settings() || {};
    state.settings = s;
    $('set-webhook').value = s.webhook_url || '';
    const ev = s.webhook_events || {};
    $('wh-start').checked = ev.start !== false;
    $('wh-stop').checked = ev.stop !== false;
    $('wh-crash').checked = ev.crash !== false;
    $('wh-error').checked = !!ev.error;
    $('wh-create').checked = !!ev.create;
    $('set-autostart-all').checked = !!s.auto_start_on_launch;
    $('set-confirm-delete').checked = s.confirm_delete !== false;
    $('set-sys-stats').checked = s.show_system_stats !== false;
    $('set-priority').value = s.default_priority || 'normal';
    $('set-default-ar').checked = !!s.default_auto_restart;
    if ($('set-channel')) $('set-channel').value = s.update_channel === 'beta' ? 'beta' : 'stable';
    if ($('set-auto-update')) $('set-auto-update').checked = s.auto_update !== false;
    refreshUpdateState();
    $('settings-modal').hidden = false;
  } catch (e) {
    toast('Nie udało się otworzyć ustawień', 'error');
  }
}

async function saveSettings() {
  const data = {
    webhook_url: $('set-webhook').value.trim(),
    webhook_events: {
      start: $('wh-start').checked,
      stop: $('wh-stop').checked,
      crash: $('wh-crash').checked,
      error: $('wh-error').checked,
      create: $('wh-create').checked,
    },
    auto_start_on_launch: $('set-autostart-all').checked,
    confirm_delete: $('set-confirm-delete').checked,
    show_system_stats: $('set-sys-stats').checked,
    default_priority: $('set-priority').value,
    default_auto_restart: $('set-default-ar').checked,
    update_channel: $('set-channel') ? $('set-channel').value : 'stable',
    auto_update: $('set-auto-update') ? $('set-auto-update').checked : true,
  };
  const res = await api()?.save_settings(data);
  if (res?.ok) {
    state.settings = { ...state.settings, ...data };
    toast('Ustawienia zapisane', 'success');
    $('settings-modal').hidden = true;
    if ($('sys-stats')) $('sys-stats').hidden = !data.show_system_stats;
    document.body.classList.toggle('sidebar-collapsed', !!data.compact_sidebar);
    const st = $('sidebar-toggle');
    if (st) st.setAttribute('aria-expanded', data.compact_sidebar ? 'false' : 'true');
  } else toast(res?.error || 'Błąd', 'error');
}


function runParticles() {
  const canvas = document.getElementById('particles');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let w, h, parts = [];
  function resize() {
    w = canvas.width = canvas.offsetWidth;
    h = canvas.height = canvas.offsetHeight;
  }
  resize();
  window.addEventListener('resize', resize);
  for (let i = 0; i < 48; i++) {
    parts.push({
      x: Math.random() * w, y: Math.random() * h,
      r: Math.random() * 2 + 0.5,
      vx: (Math.random() - 0.5) * 0.4,
      vy: -Math.random() * 0.6 - 0.2,
      a: Math.random() * 0.5 + 0.2,
    });
  }
  function tick() {
    if (!document.getElementById('connecting') || document.getElementById('connecting').classList.contains('hidden')) return;
    ctx.clearRect(0, 0, w, h);
    for (const p of parts) {
      p.x += p.vx; p.y += p.vy;
      if (p.y < -10) { p.y = h + 10; p.x = Math.random() * w; }
      if (p.x < 0) p.x = w; if (p.x > w) p.x = 0;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(56,189,248,${p.a})`;
      ctx.fill();
    }
    requestAnimationFrame(tick);
  }
  tick();
}

async function bootLoader() {
  const fill = document.getElementById('load-fill');
  const pct = document.getElementById('load-pct');
  const status = document.getElementById('load-status');
  const connecting = document.getElementById('connecting');
  runParticles();
  const steps = [
    { p: 12, t: 'Ładowanie UI…' },
    { p: 28, t: 'Połączenie z hostem…' },
    { p: 45, t: 'Odczyt konfiguracji…' },
    { p: 62, t: 'Lista botów…' },
    { p: 78, t: 'Sprawdzanie aktualizacji…' },
    { p: 92, t: 'Prawie gotowe…' },
    { p: 100, t: 'Gotowe' },
  ];
  for (const s of steps) {
    if (fill) fill.style.width = s.p + '%';
    if (pct) pct.textContent = s.p + '%';
    if (status) status.textContent = s.t;
    await new Promise(r => setTimeout(r, s.p === 78 ? 180 : 40));
    if (s.p === 78) {
      try {
        const u = await api()?.check_for_updates?.();
        if (u && u.update) {
          if (status) status.textContent = `Dostępna ${u.latest}`;
          setTimeout(() => showUpdateBanner(u), 200);
        }
      } catch (e) {}
    }
  }
  hideConnecting();
}

function hideConnecting() {
  const el = document.getElementById('connecting');
  if (!el) return;
  el.classList.add('hidden');
  el.setAttribute('hidden', '');
  el.style.cssText = 'display:none!important;visibility:hidden!important;pointer-events:none!important;opacity:0!important;z-index:-9999!important';
}


function showUpdateBanner(u) {
  if (document.getElementById('update-banner')) return;
  const el = document.createElement('div');
  el.id = 'update-banner';
  el.className = 'update-banner';
  const canAuto = !!(u.download_url || u.exe_url || u.tar_url);
  el.innerHTML = `<span id="upd-text">Aktualizacja ${escapeHtml(u.latest || '')} dostępna</span>
    ${canAuto ? '<button type="button" id="upd-apply">Zainstaluj</button>' : ''}
    <button type="button" id="upd-open">Szczegóły</button>
    ${u.mandatory ? '' : '<button type="button" id="upd-skip">Pomiń wersję</button><button type="button" id="upd-dismiss">Później</button>'}`;
  document.body.appendChild(el);
  const dis = document.getElementById('upd-dismiss');
  if (dis) dis.onclick = () => el.remove();
  const skp = document.getElementById('upd-skip');
  if (skp) skp.onclick = async () => { await api()?.skip_version?.(u.latest); el.remove(); toast('Pominięto ' + u.latest, 'info'); };
  document.getElementById('upd-open').onclick = () => {
    alert((u.notice ? u.notice + '\n\n' : '') + (u.changelog || 'Nowa wersja hosta.') + (canAuto ? '' : '\n\nWydanie nie ma jeszcze paczki do pobrania.'));
  };
  const run = async () => {
    const btn = document.getElementById('upd-apply');
    if (btn) btn.disabled = true;
    const txt = document.getElementById('upd-text');
    let alive = true;
    (async function poll() {
      while (alive) {
        try {
          const p = await api()?.get_update_progress?.();
          if (p && txt && p.stage !== 'idle') txt.textContent = `${p.text || ''} ${p.pct ? p.pct + '%' : ''}`;
        } catch (e) {}
        await new Promise(r => setTimeout(r, 300));
      }
    })();
    try {
      const res = await api()?.apply_update?.(null);
      if (res?.ok) {
        pushEvent('Aktualizacja', res.mode === 'exe' ? 'Wymiana .exe' : 'Pliki źródłowe', 'start');
      } else {
        alive = false;
        toast(res?.error || 'Nie udało się zaktualizować', 'error');
        if (txt) txt.textContent = `Aktualizacja ${u.latest || ''} dostępna`;
        if (btn) btn.disabled = false;
      }
    } catch (e) {
      alive = false;
      toast('Błąd aktualizacji', 'error');
      if (btn) btn.disabled = false;
    }
  };
  const ap = document.getElementById('upd-apply');
  if (ap) ap.onclick = run;
  if (canAuto && (u.mandatory || state.settings?.auto_update !== false)) setTimeout(run, 400);
}

setInterval(async () => {
  try {
    const u = await api()?.check_for_updates?.();
    if (u && u.update) showUpdateBanner(u);
  } catch (e) {}
}, 30 * 60 * 1000);


async function maybeShowFeedback() {
  try {
    const st = await api()?.get_feedback_state?.();
    if (!st || !st.show) return;
    const m = $('feedback-modal');
    if (!m) return;
    const link = $('feedback-discord');
    if (link && st.discord) {
      link.href = st.discord;
      link.onclick = (e) => { e.preventDefault(); try { window.open(st.discord, '_blank'); } catch {} };
    }
    m.hidden = false;
  } catch (e) {}
}

function wireFeedback() {
  const m = $('feedback-modal');
  if (!m) return;
  $('feedback-close')?.addEventListener('click', async () => {
    m.hidden = true;
    await api()?.dismiss_feedback?.(false);
  });
  $('feedback-later')?.addEventListener('click', async () => {
    m.hidden = true;
    await api()?.dismiss_feedback?.(true);
    toast('Przypomnimy później', 'info');
  });
  $('feedback-send')?.addEventListener('click', async () => {
    const text = $('feedback-text')?.value || '';
    const cat = $('feedback-cat')?.value || 'general';
    if (!text.trim()) return toast('Napisz krótką wiadomość', 'error');
    const res = await api()?.submit_feedback?.(text, cat);
    m.hidden = true;
    toast('Dzięki za opinię!', 'success');
    if (res?.discord) {
      pushEvent('Feedback zapisany', 'Możesz też napisać na Discordzie', 'start');
    }
  });
}

function init() {
  if (initialized) return;
  initialized = true;

  bootLoader();
  // Failsafe: never leave the overlay blocking clicks
  setTimeout(hideConnecting, 2500);
  setTimeout(hideConnecting, 5000);
  wireFeedback();
  setTimeout(maybeShowFeedback, 4500);

  Promise.resolve(api()?.get_version?.()).then((v) => {
    if ($('app-ver') && v) $('app-ver').textContent = 'v' + v.version;
  }).catch(() => {});

  Promise.resolve(api()?.get_settings?.()).then((s) => { state.settings = s || {}; }).catch(() => {});

  $('btn-new')?.addEventListener('click', newBot);
  $('btn-empty-new')?.addEventListener('click', newBot);
  $('btn-empty-folder')?.addEventListener('click', uploadFolder);
  $('btn-empty-settings')?.addEventListener('click', openSettings);
  $('btn-upload-folder')?.addEventListener('click', uploadFolder);
  $('btn-refresh')?.addEventListener('click', () => withLoading($('btn-refresh'), () => refreshBots(true)));
  $('btn-start-all')?.addEventListener('click', async () => {
    await api()?.start_all();
    toast('Start wszystkich', 'success');
    setTimeout(refreshBots, 300);
  });
  $('btn-stop-all')?.addEventListener('click', async () => {
    await api()?.stop_all();
    toast('Stop wszystkich', 'info');
    setTimeout(refreshBots, 300);
  });
  $('btn-settings')?.addEventListener('click', openSettings);
  $('settings-close')?.addEventListener('click', () => { $('settings-modal').hidden = true; });
  $('settings-cancel')?.addEventListener('click', () => { $('settings-modal').hidden = true; });
  $('settings-save')?.addEventListener('click', saveSettings);
  $('btn-open-data')?.addEventListener('click', async () => {
    const res = await api()?.open_data_dir?.();
    if (res?.ok) toast('Folder danych: ' + (res.path || ''), 'success');
    else toast(res?.error || 'Nie otwarto', 'error');
  });
  $('btn-test-webhook')?.addEventListener('click', async () => {
    const res = await api()?.test_webhook($('set-webhook').value.trim() || null);
    if (res?.ok) toast('Test wysłany', 'success');
    else toast(res?.error || 'Błąd webhooka', 'error');
  });

  $('btn-start')?.addEventListener('click', startBot);
  $('btn-stop')?.addEventListener('click', stopBot);
  $('btn-restart')?.addEventListener('click', restartBot);
  $('btn-delete')?.addEventListener('click', deleteBot);
  $('chk-auto')?.addEventListener('change', toggleAuto);
  $('btn-send')?.addEventListener('click', sendStdin);
  $('stdin')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendStdin(); });

  $('btn-new-file')?.addEventListener('click', () => {
    if (!state.selected) return;
    promptModal('Nazwa pliku (np. config.json):').then(async (name) => {
      if (!name) return;
      const res = await api()?.create_file(state.selected, name);
      if (res?.ok === false) return toast(res.error || 'Błąd', 'error');
      await loadFiles(state.selected);
      openEditor(state.selected, name);
    });
  });
  $('btn-refresh-files')?.addEventListener('click', () => state.selected && loadFiles(state.selected));
  $('btn-open-folder')?.addEventListener('click', () => state.selected && api()?.open_folder(state.selected));
  $('btn-export-logs')?.addEventListener('click', async () => {
    if (!state.selected) return;
    const res = await api()?.export_logs(state.selected);
    if (res?.ok) toast('Wyeksportowano', 'success');
    else if (!res?.cancelled) toast(res?.error || 'Błąd', 'error');
  });
  $('btn-clear')?.addEventListener('click', () => {
    $('console').innerHTML = '';
    state.allLogLines = [];
    api()?.clear_logs(state.selected);
  });
  $('filter-level')?.addEventListener('change', (e) => { state.filter = e.target.value; renderLogs(); });
  $('log-search')?.addEventListener('input', (e) => { state.logSearch = e.target.value; renderLogs(); });
  $('chk-timestamps')?.addEventListener('change', (e) => { state.showTimestamps = e.target.checked; renderLogs(); });
  $('btn-install-req')?.addEventListener('click', async () => {
    if (!state.selected) return;
    toast('Instaluję zależności…', 'info');
    const res = await api()?.install_requirements(state.selected);
    if (res?.ok) toast('pip install OK', 'success');
    else toast(res?.error || 'Błąd pip', 'error');
  });
  $('btn-syntax')?.addEventListener('click', async () => {
    if (!state.selected) return;
    const res = await api()?.run_syntax_check(state.selected);
    if (res?.ok) toast(res.message || 'Składnia OK', 'success');
    else toast(res?.error || 'Błąd składni', 'error');
  });
  $('btn-fetch-avatar')?.addEventListener('click', async () => {
    if (!state.selected) return;
    toast('Pobieram awatar…', 'info');
    const res = await api()?.refresh_avatar(state.selected);
    if (res?.ok) {
      delete state.avatars[state.selected];
      await loadAvatar(state.selected);
      renderSidebar();
      updateHeader();
      toast(res.username ? `Awatar @${res.username}` : 'Awatar pobrany', 'success');
    } else toast(res?.error || 'Ustaw token w .env', 'error');
  });
  $('btn-set-avatar')?.addEventListener('click', async () => {
    if (!state.selected) return;
    const res = await api()?.set_avatar_file(state.selected);
    if (res?.ok) {
      delete state.avatars[state.selected];
      await loadAvatar(state.selected);
      renderSidebar();
      updateHeader();
      toast('Awatar ustawiony', 'success');
    } else if (!res?.cancelled) toast(res?.error || 'Błąd', 'error');
  });

  $('btn-more')?.addEventListener('click', (e) => {
    if (!state.selected) return;
    const r = e.currentTarget.getBoundingClientRect();
    showContextMenu(r.left, r.bottom + 4, state.selected);
  });

  $('modal-close')?.addEventListener('click', () => closeEditor());
  $('modal-save')?.addEventListener('click', saveEditor);
  $('modal-text')?.addEventListener('input', () => { state.dirty = true; $('dirty-dot')?.classList.add('active'); });
  $('search')?.addEventListener('input', (e) => { state.search = e.target.value; renderSidebar(); });

  const sidebarToggle = $('sidebar-toggle');
  if (sidebarToggle) {
    sidebarToggle.addEventListener('click', () => {
      const exp = sidebarToggle.getAttribute('aria-expanded') === 'true';
      sidebarToggle.setAttribute('aria-expanded', exp ? 'false' : 'true');
      document.body.classList.toggle('sidebar-collapsed', exp);
    });
  }

  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's' && $('modal') && !$('modal').hidden) { e.preventDefault(); saveEditor(); }
    if ((e.ctrlKey || e.metaKey) && (e.key === 'n' || e.key === 'N') && !e.altKey) {
      const tag = (e.target && e.target.tagName) || '';
      if (tag !== 'INPUT' && tag !== 'TEXTAREA' && tag !== 'SELECT') { e.preventDefault(); newBot(); }
    }
    if (e.key === 'F5') {
      e.preventDefault();
      refreshBots(true);
    }
    if (e.key === 'Escape') {
      if ($('modal') && !$('modal').hidden) closeEditor();
      if ($('prompt') && !$('prompt').hidden) $('prompt-cancel')?.click();
      if ($('confirm') && !$('confirm').hidden) $('confirm-cancel')?.click();
      if ($('template-modal') && !$('template-modal').hidden) $('template-cancel')?.click();
      if ($('settings-modal') && !$('settings-modal').hidden) $('settings-modal').hidden = true;
    }
  });

  $('win-min')?.addEventListener('click', () => api()?.window_minimize());
  $('win-max')?.addEventListener('click', () => api()?.window_toggle_maximize());
  $('win-close')?.addEventListener('click', () => api()?.window_close());

  const titlebar = $('titlebar');
  let drag = null, lastMove = 0;
  if (titlebar) {
    titlebar.addEventListener('mousedown', async (e) => {
      if (e.target.closest('.titlebar-controls') || e.button !== 0) return;
      e.preventDefault();
      drag = { startX: e.screenX, startY: e.screenY };
      try { await api()?.window_drag_start(); } catch {}
    });
  }
  document.addEventListener('mousemove', (e) => {
    if (!drag) return;
    const now = performance.now();
    if (now - lastMove < 8) return;
    lastMove = now;
    try { api()?.window_drag_to(e.screenX - drag.startX, e.screenY - drag.startY); } catch {}
  });
  document.addEventListener('mouseup', () => { drag = null; });

  refreshBots(true);
}

window.addEventListener('pywebviewready', init);
if (window.pywebview && window.pywebview.api) init();
// Fallback if pywebviewready is late/missed
window.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => { try { if (!initialized) init(); else hideConnecting(); } catch (e) { try { hideConnecting(); } catch (_) {} } }, 200);
});
setTimeout(() => { try { if (!initialized) init(); } catch (e) {} }, 1200);



async function refreshUpdateState() {
  try {
    const st = await api()?.get_update_state?.();
    if (!st) return;
    const last = st.last_check ? new Date(st.last_check * 1000).toLocaleString('pl-PL') : 'nigdy';
    if ($('upd-state')) $('upd-state').textContent = `Wersja ${st.current} · kanał ${st.channel} · ostatnie sprawdzenie: ${last}` + (st.skipped_version ? ` · pominięto ${st.skipped_version}` : '');
    if ($('btn-unskip')) $('btn-unskip').hidden = !st.skipped_version;
  } catch (e) {}
}

async function checkUpdateNow() {
  const btn = $('btn-check-update');
  if (btn) { btn.disabled = true; btn.textContent = 'Sprawdzanie…'; }
  try {
    const u = await api()?.check_for_updates?.(12, true);
    if (!u || u.ok === false) toast(u?.error || 'Nie udało się sprawdzić', 'error');
    else if (u.update) {
      const hasPkg = !!(u.exe_url || u.tar_url || u.download_url);
      if (!hasPkg) toast('Wersja ' + u.latest + ' jest, ale w manifeście brak paczki. Opublikuj z admina.', 'error');
      else { toast('Dostępna wersja ' + u.latest, 'success'); $('settings-modal').hidden = true; showUpdateBanner(u); }
    } else toast('Masz najnowszą wersję (' + (u.current || '?') + ')', 'success');
  } catch (e) { toast('Błąd sprawdzania', 'error'); }
  if (btn) { btn.disabled = false; btn.textContent = 'Sprawdź aktualizacje teraz'; }
  refreshUpdateState();
}


// Extra boot paths so UI never stays blocked
window.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => { try { hideConnecting(); } catch (e) {} }, 3000);
});
window.addEventListener('load', () => {
  setTimeout(() => { try { hideConnecting(); } catch (e) {} }, 1500);
});
