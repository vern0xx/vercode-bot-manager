@echo off
chcp 65001 >nul
title VerCode Admin
python admin_host.py
if errorlevel 1 pause
